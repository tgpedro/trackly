/* Trackly · contas, sincronização e páginas de usuário (Supabase)
   Carrega DEPOIS do app.js. Se o Supabase não estiver configurado, não faz nada
   e o site continua funcionando só com os dados do navegador. */
(function(){
"use strict";
var SB=window.sb,ON=!!SB,C=window.TRACKLY||{};
var USER=null,applying=false,pushT=null,pushing=false,again=false,started=false,readyRes,sigProf="",sigRev="";
var ready=new Promise(function(r){readyRes=function(){known=true;r()}});
var SYNC={state:"idle",at:0};
window.tkOn=ON;
var known=false;
(function(){var has=false;try{for(var i=0;i<localStorage.length;i++){if(/^sb-.*-auth-token$/.test(localStorage.key(i)))has=true}}catch(e){}
  if(ON&&!has)document.body.classList.add("tk-guest")})();
Object.defineProperty(window,"__tkUser",{get:function(){return USER}});

function LS(k,v){try{if(v===undefined)return localStorage.getItem(k);if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v)}catch(e){}return null}
var tm=function(ms){return new Promise(function(r){setTimeout(function(){r({data:null,error:{message:"timeout"}})},ms)})};
function route(){return decodeURIComponent(NAV.hash.slice(1))}
function isEmpty(s){
  if(!s)return true;
  var p=s.perfil,def=!p||(p.handle==="your.handle"&&(!p.nome||p.nome==="Your name")&&!p.bio&&!p.avatar&&!(p.fav||[]).length&&!(p.musicas||[]).length);
  return def&&!Object.keys(s.u||{}).length&&!(s.listas||[]).length&&!(s.seguindo||[]).length&&!((s.soc&&s.soc.rev)||[]).length;
}
function friendly(e){
  var m=(e&&e.message)||"Something went wrong";
  if(/invalid login/i.test(m))return "Wrong email or password.";
  if(/not confirmed/i.test(m))return "Confirm your email first (check your inbox).";
  if(/rate limit|too many/i.test(m))return "Too many attempts. Wait a minute and try again.";
  if(/password.*(short|least|characters)/i.test(m))return "Password is too short (use 8+ characters).";
  if(/already registered|already been registered/i.test(m))return "This email already has an account. Log in instead.";
  return m;
}

/* ---------- header / menu ---------- */
function headerSync(){
  var guest=ON&&!USER;
  document.body.classList.toggle("tk-guest",guest);
  var r=document.querySelector(".hright"),hd=document.querySelector("header");
  [["tkLogin",r,function(b){r.insertBefore(b,r.querySelector(".hmw")||null)}],["tkLoginM",hd,function(b){hd.appendChild(b)}]].forEach(function(x){
    var b=document.getElementById(x[0]);
    if(!ON||!x[1]){if(b)b.remove();return}
    if(!b){
      b=document.createElement("a");b.id=x[0];b.className="tk-hlogin"+(x[0]==="tkLoginM"?" tk-m":" tk-d");b.href="/login";b.dataset.h="#login";b.textContent=x[0]==="tkLoginM"?"Log in / Sign up":"Log in";
      x[2](b);
    }
    b.hidden=!guest;
  });
}
window.tkMenuHTML=function(i){
  if(!ON)return "";
  return USER?"<hr>"+i("tkaccount","info","Account")+i("tklogout","external","Log out"):"<hr>"+i("tklogin","user","Log in / Sign up");
};
window.tkMenuAct=function(a){
  if(a==="tklogin")NAV.go("login");
  else if(a==="tkaccount")NAV.go("settings-account");
  else if(a==="tklogout")logout();
};

/* ---------- páginas de login ---------- */
function card(t,sub,body,foot){
  return '<div class="tk-auth"><div class="tk-brand">Trackly<b>.</b></div><h1>'+t+'</h1><p class="tk-sub">'+sub+'</p>'+body+'<div class="tk-foot">'+foot+'</div></div>';
}
var lnk=function(h,t){return '<a class="lnk" href="'+NAV.toPath(h)+'" data-h="'+h+'">'+t+'</a>'};
var inp=function(l,n,t,ac,ph,x){return '<label class="tk-l">'+l+'<input class="field" name="'+n+'" type="'+t+'" autocomplete="'+ac+'"'+(ph?' placeholder="'+ph+'"':"")+' required'+(x||"")+'></label>'};
var google=function(){return C.GOOGLE_LOGIN?'<div class="tk-or"><span>or</span></div><button class="btn tk-wide" type="button" data-tk="google">Continue with Google</button>':""};
function loginView(){
  return card("Welcome back","Log in to sync your ratings, lists and profile.",
   '<form data-tkform="login" novalidate>'+inp("Email","email","email","email")+inp("Password","password","password","current-password")+
   '<div class="tk-err" role="alert"></div><button class="fab tk-wide" type="submit">Log in</button></form>'+google(),
   lnk("#forgot","Forgot your password?")+'<br>New here? '+lnk("#signup","Create an account"));
}
function signupView(){
  return card("Create your account","Pick a username. Your public page will be "+esc(location.host)+"/user/<b>username</b>.",
   '<form data-tkform="signup" novalidate>'+inp("Username","handle","text","username","e.g. marina.sol",' pattern="[a-z0-9._]{3,30}" autocapitalize="none" spellcheck="false"')+
   inp("Email","email","email","email")+inp("Password (8+ characters)","password","password","new-password","",' minlength="8"')+
   '<div class="tk-err" role="alert"></div><button class="fab tk-wide" type="submit">Create account</button></form>'+google(),
   'Already have an account? '+lnk("#login","Log in"));
}
function forgotView(){
  return card("Reset password","We will email you a link to choose a new password.",
   '<form data-tkform="forgot" novalidate>'+inp("Email","email","email","email")+'<div class="tk-err" role="alert"></div><button class="fab tk-wide" type="submit">Send link</button></form>',
   lnk("#login","Back to log in"));
}
function resetView(){
  return card("Choose a new password","Use at least 8 characters.",
   '<form data-tkform="reset" novalidate>'+inp("New password","password","password","new-password","",' minlength="8"')+'<div class="tk-err" role="alert"></div><button class="fab tk-wide" type="submit">Save password</button></form>',
   lnk("#home","Skip"));
}
var AUTHV={login:loginView,signup:signupView,forgot:forgotView,reset:resetView};
function msgView(t,sub){return card(t,sub,"",lnk("#home","Go to Trackly"))}

document.addEventListener("submit",async function(e){
  var f=e.target.closest&&e.target.closest("form[data-tkform]");if(!f)return;
  e.preventDefault();
  if(!ON)return;
  var kind=f.dataset.tkform,v={};new FormData(f).forEach(function(x,k){v[k]=String(x).trim()});
  var btn=f.querySelector("button[type=submit]"),err=f.querySelector(".tk-err"),txt=btn.textContent;
  var fail=function(m){err.textContent=m;btn.disabled=false;btn.textContent=txt};
  btn.disabled=true;btn.textContent="Please wait…";err.textContent="";
  try{
    var r;
    if(kind==="login"){
      r=await SB.auth.signInWithPassword({email:v.email,password:v.password});
      if(r.error)return fail(friendly(r.error));
      NAV.go("home");
    }else if(kind==="signup"){
      var h=v.handle.toLowerCase().replace(/^@/,"");
      if(!/^[a-z0-9._]{3,30}$/.test(h))return fail("Username: 3 to 30 letters, numbers, dots or underscores.");
      if(v.password.length<8)return fail("Password must have at least 8 characters.");
      var ex=await SB.from("profiles").select("id").eq("handle",h).maybeSingle();
      if(ex.data)return fail("That username is taken.");
      r=await SB.auth.signUp({email:v.email,password:v.password,options:{data:{handle:h},emailRedirectTo:location.origin+"/"}});
      if(r.error)return fail(friendly(r.error));
      if(r.data&&r.data.user&&r.data.user.identities&&r.data.user.identities.length===0)return fail("This email already has an account. Log in instead.");
      if(r.data&&r.data.session)NAV.go("home");
      else document.getElementById("app").innerHTML=msgView("Check your email","We sent a confirmation link to <b>"+esc(v.email)+"</b>. Open it to finish creating your account.");
    }else if(kind==="forgot"){
      r=await SB.auth.resetPasswordForEmail(v.email,{redirectTo:location.origin+"/reset"});
      if(r.error)return fail(friendly(r.error));
      document.getElementById("app").innerHTML=msgView("Check your email","If <b>"+esc(v.email)+"</b> has an account, a reset link is on its way.");
    }else if(kind==="reset"){
      if(v.password.length<8)return fail("Password must have at least 8 characters.");
      r=await SB.auth.updateUser({password:v.password});
      if(r.error)return fail(friendly(r.error));
      flash("Password updated");NAV.go("home");
    }
  }catch(ex){fail(friendly(ex))}
});

/* ---------- ações [data-tk] ---------- */
document.addEventListener("click",function(e){
  var b=e.target.closest&&e.target.closest("[data-tk]");if(!b)return;
  var a=b.dataset.tk;
  if(a==="google"&&ON)SB.auth.signInWithOAuth({provider:"google",options:{redirectTo:location.origin+"/"}});
  else if(a==="logout")logout();
  else if(a==="sync"){flash("Syncing…");push(true).then(function(){flash(SYNC.state==="ok"?"Synced":"Sync failed")})}
  else if(a==="follow")toggleFollow(b);
});

async function logout(){
  if(!USER||!confirm("Log out? Your data stays safe in your account."))return;
  try{await push(true)}catch(e){}
  if(LS("tk-dirty")==="1"&&!confirm("Some recent changes could not be synced and will be lost on this device. Log out anyway?"))return;
  try{await SB.auth.signOut()}catch(e){}
  ["tk-last-uid","tk-last-sync","tk-dirty"].forEach(function(k){LS(k,null)});
  try{localStorage.removeItem(KEY)}catch(e){}
  location.href="/";
}

/* ---------- sincronização ---------- */
function snapshot(){
  var p=P(),o={},small=function(v){return typeof v==="string"&&v.length<=250000?v:""};
  ["nome","handle","bio","local","pron","links","custom","criador"].forEach(function(k){if(p[k]!==undefined)o[k]=p[k]});
  o.avatar=small(p.avatar);o.banner=small(p.banner);
  o.fav=(p.fav||[]).slice(0,10);o.musicas=(p.musicas||[]).slice(0,10);
  var rated=Object.entries(S.u||{}).filter(function(x){return x[1]&&x[1].r&&S.meta[x[0]]}).sort(function(a,b){return String(b[1].d||"").localeCompare(String(a[1].d||""))});
  o.rated=rated.length;
  o.ratings=rated.slice(0,48).map(function(x){return {k:x[0],r:x[1].r,d:x[1].d||""}});
  o.reviews=((S.soc&&S.soc.rev)||[]).filter(function(r){return r.u===p.handle&&r.txt}).slice(-12).map(function(r){return {k:r.k,r:r.r,txt:r.txt,d:r.d}});
  var need={};o.fav.concat(o.ratings.map(function(x){return x.k}),o.reviews.map(function(x){return x.k})).forEach(function(k){need[k]=1});
  o.meta={};Object.keys(need).forEach(function(k){var m=S.meta[k];if(m)o.meta[k]={t:m.t,a:m.a,y:m.y,tipo:m.tipo,cover:m.cover,genre:m.genre,ids:m.ids||{},fontes:m.fontes||[]}});
  o.v=1;return o;
}
function setStatus(s){
  SYNC.state=s;SYNC.at=Date.now();
  var el=document.getElementById("tkStatus");if(el)el.textContent=statusText();
}
function statusText(){
  if(SYNC.state==="ok")return "Synced at "+new Date(SYNC.at).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})+".";
  if(SYNC.state==="error")return "Last sync failed. It will retry on your next change.";
  if(SYNC.state==="busy")return "Syncing…";
  return "Changes sync automatically.";
}
function schedule(){clearTimeout(pushT);pushT=setTimeout(function(){push()},2500)}
window.__onSave=function(){
  if(!USER||applying)return;
  LS("tk-dirty","1");schedule();
};
async function handleTaken(){
  var r=await SB.from("profiles").select("handle").eq("id",USER.id).maybeSingle();
  var old=r.data&&r.data.handle;
  if(old){
    var mine=P().handle;P().handle=old;applying=true;salvar();applying=false;
    flash("@"+mine+" is already taken. Your username is still @"+old);
    if(window.hdrSync)hdrSync();
    try{rota()}catch(e){}
  }
}
async function push(force){
  if(!USER||!ON)return;
  if(pushing){again=true;return}
  if(!force&&LS("tk-dirty")!=="1")return;
  pushing=true;setStatus("busy");
  try{
    var uid=USER.id,p=P(),snap=snapshot(),ps=JSON.stringify(snap),tries=0,er;
    if(ps!==sigProf||force){
      for(;tries<2;tries++){
        er=(await SB.from("profiles").upsert({id:uid,handle:P().handle,nome:P().nome||P().handle,public:snapshot()},{onConflict:"id"})).error;
        if(er&&er.code==="23505"&&tries===0){await handleTaken();continue}
        break;
      }
      if(er&&er.code!=="23505")throw er;
      if(!er)sigProf=ps;
    }
    var d=await SB.from("user_data").upsert({user_id:uid,data:S},{onConflict:"user_id"}).select("updated_at").single();
    if(d.error)throw d.error;
    LS("tk-last-sync",d.data.updated_at);LS("tk-dirty",null);LS("tk-last-uid",uid);
    await syncReviews(uid);
    setStatus("ok");
  }catch(e){console.warn("[trackly] sync",e);setStatus("error")}
  finally{pushing=false;if(again){again=false;schedule()}}
}
async function syncReviews(uid){
  var h=P().handle;
  var rows=((S.soc&&S.soc.rev)||[]).filter(function(r){return r.u===h}).map(function(r){
    var m=S.meta[r.k]||{};
    return {user_id:uid,rid:String(r.id),album_key:r.k,rating:r.r||0,txt:r.txt||"",d:r.d||"",album:{t:m.t||"",a:m.a||"",y:m.y||"",cover:m.cover||""}};
  });
  var sg=JSON.stringify(rows);if(sg===sigRev)return;
  if(rows.length){var u=await SB.from("reviews").upsert(rows,{onConflict:"user_id,rid"});if(u.error)throw u.error}
  var q=SB.from("reviews").delete().eq("user_id",uid);
  if(rows.length)q=q.not("rid","in","("+rows.map(function(r){return '"'+r.rid.replace(/"/g,"")+'"'}).join(",")+")");
  var dl=await q;if(dl.error)throw dl.error;
  sigRev=sg;
}
function choose(){
  return new Promise(function(res){
    var d=document.createElement("div");d.className="tk-modal";
    d.innerHTML='<div class="tk-md"><h2>Which data do you want to keep?</h2><p>This device has data that differs from your Trackly account.</p><button class="fab tk-wide" data-c="cloud">Use my account data</button><button class="btn tk-wide" data-c="local">Replace my account with this device</button></div>';
    d.addEventListener("click",function(e){var b=e.target.closest("[data-c]");if(b){d.remove();res(b.dataset.c)}});
    document.body.appendChild(d);
  });
}
function applyCloud(row,uid){
  applying=true;
  try{localStorage.setItem(KEY,JSON.stringify(row.data));LS("tk-last-uid",uid);LS("tk-last-sync",row.updated_at);LS("tk-dirty",null)}catch(e){flash("Could not save locally")}
  location.reload();
}
function reconcile(prof){
  if(!prof)return false;
  var p=P(),ch=false;
  if(prof.handle&&p.handle!==prof.handle){p.handle=prof.handle;ch=true}
  if((!p.nome||p.nome==="Your name")&&prof.nome){p.nome=prof.nome;ch=true}
  if(ch){applying=true;salvar();applying=false;if(window.hdrSync)hdrSync()}
  return ch;
}
async function afterLogin(){
  var uid=USER.id;
  var rs=await Promise.all([SB.from("profiles").select("handle,nome").eq("id",uid).maybeSingle(),SB.from("user_data").select("data,updated_at").eq("user_id",uid).maybeSingle()]);
  var prof=rs[0].data,row=rs[1].data;
  if(rs[1].error){flash("Could not reach your account data");return}
  var lastUid=LS("tk-last-uid"),lastSync=Date.parse(LS("tk-last-sync")||"")||0,dirty=LS("tk-dirty")==="1",act="none";
  var cloudT=row?Date.parse(row.updated_at):0;
  if(!row)act="push";
  else if(lastUid!==uid)act=isEmpty(S)?"pull":"ask";
  else if(dirty&&cloudT>lastSync)act="ask";
  else if(cloudT>lastSync)act="pull";
  else if(dirty)act="push";
  if(act==="ask")act=(await choose())==="cloud"?"pull":"push";
  if(act==="pull"&&row){applyCloud(row,uid);return}
  LS("tk-last-uid",uid);
  var ch=reconcile(prof);
  if(act==="push"||ch||!row)await push(true);
  headerSync();
}

/* ---------- avaliações da comunidade (aparecem na página do álbum) ---------- */
window.__remRev=window.__remRev||{};
async function loadRemote(k){
  if(!ON)return;
  try{
    var r=await Promise.race([SB.from("reviews").select("rid,album_key,rating,txt,d,profiles(handle,nome)").eq("album_key",k).order("d",{ascending:false}).limit(30),tm(1500)]);
    if(!r||!r.data)return;
    window.__remRev[k]=r.data.map(function(x){var pr=x.profiles||{};return {id:"r"+x.rid+"-"+(pr.handle||""),k:x.album_key,u:pr.handle||"user",n:pr.nome||pr.handle||"User",av:"",r:Number(x.rating)||0,txt:x.txt||"",d:x.d||"",remote:1}});
  }catch(e){}
}
var _list=SOC.list;
SOC.list=function(k){
  var me=this.me().h;
  return _list.call(this,k).concat((window.__remRev[k]||[]).filter(function(r){return r.u!==me}));
};
var _av=albumView;
albumView=async function(k){await loadRemote(k);return _av(k)};

/* ---------- perfil público: /user/handle ---------- */
function fmtN(n){try{return new Intl.NumberFormat("en",{notation:"compact"}).format(n||0)}catch(e){return String(n||0)}}
async function followInfo(row){
  var cnt=function(col){return SB.from("follows").select("*",{count:"exact",head:true}).eq(col,row.id)};
  var q=[cnt("following_id"),cnt("follower_id")];
  if(USER&&USER.id!==row.id)q.push(SB.from("follows").select("follower_id").eq("follower_id",USER.id).eq("following_id",row.id).maybeSingle());
  var r=await Promise.all(q);
  return {followers:r[0].count||0,following:r[1].count||0,is:!!(r[2]&&r[2].data)};
}
function pubHTML(row,fi){
  var s=row.public||{},me=USER&&USER.id===row.id,name=s.nome||row.nome||row.handle,h=row.handle;
  Object.keys(s.meta||{}).forEach(function(k){if(!S.meta[k])S.meta[k]=s.meta[k]});
  var [c1,c2]=cores(h);
  var av=s.avatar?'<img src="'+esc(s.avatar)+'" alt="">':esc(ini(name));
  var ban=s.banner?'<div class="tkpf-ban" style="background-image:url(\''+esc(s.banner)+'\')"></div>':"";
  var act=me?'<a class="btn" href="/settings" data-h="#settings">Edit profile</a>':
    USER?'<button class="btn'+(fi.is?"":" on")+'" data-tk="follow" data-id="'+row.id+'" data-on="'+(fi.is?1:0)+'">'+(fi.is?"Following":"Follow")+'</button>':
    '<a class="btn on" href="/login" data-h="#login">Log in to follow</a>';
  var favs=(s.fav||[]).filter(function(k){return S.meta[k]});
  var songs=(s.musicas||[]);
  var rat=(s.ratings||[]).filter(function(x){return S.meta[x.k]}).slice(0,24);
  var rev=(s.reviews||[]).filter(function(x){return S.meta[x.k]});
  var out='<div class="tkpf">'+ban+'<div class="tkpf-head"><div class="tkpf-av" style="background:'+(s.avatar?"#222":"linear-gradient(145deg,"+c1+","+c2+")")+'">'+av+'</div>'+
    '<div class="tkpf-id"><h1>'+esc(name)+(window.isCreator&&s.criador!==false&&isCreator(h)?cbadge(1):"")+'</h1><div class="tkpf-h">@'+esc(h)+(s.local?" · "+esc(s.local):"")+'</div></div><div class="tkpf-act">'+act+'</div></div>';
  if(s.bio)out+='<p class="tkpf-bio">'+esc(s.bio)+'</p>';
  if(window.linkChips)out+=linkChips(s);
  out+='<div class="tkpf-stats"><div><b>'+fmtN(s.rated)+'</b><span>Rated</span></div><div><b id="tkFo">'+fmtN(fi.followers)+'</b><span>Followers</span></div><div><b>'+fmtN(fi.following)+'</b><span>Following</span></div></div>';
  if(favs.length)out+='<div class="sec-h"><h2>Favorite albums</h2></div><div class="carrossel">'+favs.map(cardMeta).join("")+'</div>';
  if(songs.length)out+='<div class="sec-h"><h2>Favorite songs</h2></div><div class="mlist">'+songs.map(function(t,i){return '<div class="row"><span class="num">'+(i+1)+'</span><div class="grow"><div class="ttl">'+esc(t)+'</div></div></div>'}).join("")+'</div>';
  if(rat.length)out+='<div class="sec-h"><h2>Recent ratings</h2></div><div class="grid tkpf-grid">'+rat.map(function(x){var m=S.meta[x.k];return '<a class="card gc" href="/album/'+x.k+'" data-h="#album-'+x.k+'" style="--c:'+cores(x.k)[0]+'">'+capaAlbum(x.k,m.t,null)+'<div class="t">'+esc(m.t)+'</div><div class="s">'+estrelas(x.r)+'</div></a>'}).join("")+'</div>';
  if(rev.length)out+='<div class="sec-h"><h2>Reviews</h2></div>'+rev.map(function(x){var m=S.meta[x.k];return '<a class="tkpf-rv" href="/album/'+x.k+'" data-h="#album-'+x.k+'">'+capaAlbum(x.k,m.t,56)+'<div><b>'+esc(m.t)+'</b> <span class="mut sm">'+esc(m.a)+'</span><div>'+(x.r?estrelas(x.r):"")+'</div><p>'+esc(x.txt)+'</p></div></a>'}).join("");
  if(!favs.length&&!rat.length&&!rev.length&&!songs.length)out+='<div class="empty">Nothing to show here yet.</div>';
  return out+'</div>';
}
async function publicProfile(handle){
  var app=document.getElementById("app"),tok=++rotaTok;
  app.innerHTML='<div class="load">Loading…</div>';
  if(!ON){app.innerHTML='<div class="empty">User not found.</div>';return}
  await Promise.race([ready,tm(2500)]);
  var r=await SB.from("profiles").select("id,handle,nome,public").eq("handle",handle).maybeSingle();
  if(tok!==rotaTok)return;
  if(!r.data){app.innerHTML='<div class="empty">User @'+esc(handle)+' not found.</div>';return}
  var fi;try{fi=await followInfo(r.data)}catch(e){fi={followers:0,following:0,is:false}}
  if(tok!==rotaTok)return;
  document.title="@"+r.data.handle+" — Trackly";
  app.innerHTML=pubHTML(r.data,fi);
  window.scrollTo(0,0);
}
async function toggleFollow(b){
  if(!USER)return NAV.go("login");
  var id=b.dataset.id,on=b.dataset.on==="1";b.disabled=true;
  var r=on?await SB.from("follows").delete().eq("follower_id",USER.id).eq("following_id",id):await SB.from("follows").insert({follower_id:USER.id,following_id:id});
  b.disabled=false;
  if(r.error){flash("Could not update follow");return}
  b.dataset.on=on?"0":"1";b.textContent=on?"Follow":"Following";b.classList.toggle("on",on);
  var fo=document.getElementById("tkFo");if(fo){var n=parseInt(String(fo.textContent).replace(/\D/g,""))||0;fo.textContent=fmtN(Math.max(0,n+(on?-1:1)))}
}

/* ---------- conta nas configurações ---------- */
window.tkAccountHTML=function(){
  if(!ON)return '<section><h2>Trackly account</h2><p class="stg-sub">Accounts are not configured on this site yet.</p></section>';
  if(!USER)return '<section><h2>Trackly account</h2><p class="stg-sub">Log in to sync your ratings, lists and profile across all your devices and get a public page.</p><div class="gr"><div class="sx-btns"><a class="btn on" href="/login" data-h="#login">Log in</a><a class="btn" href="/signup" data-h="#signup">Create account</a></div></div></section>';
  var h=encodeURIComponent(P().handle);
  return '<section><h2>Trackly account</h2><p class="stg-sub">Signed in as <b>'+esc(USER.email||"")+'</b>.<br>Your public page: <a class="lnk" href="/user/'+h+'" data-h="#@'+h+'">'+esc(location.host)+'/user/'+esc(P().handle)+'</a></p><p class="stg-sub" id="tkStatus">'+statusText()+'</p><div class="gr"><div class="sx-btns"><button class="btn" data-tk="sync">Sync now</button><button class="btn" data-tk="logout">Log out</button></div></div></section>';
};
var _acc=stAccount;
stAccount=function(){
  return tkAccountHTML()+_acc().replace("Everything is saved only in this browser. Back up from time to time.",USER?"Synced to your Trackly account and cached in this browser. A backup file never hurts.":"Saved only in this browser until you log in. Back up from time to time.");
};

/* ---------- roteamento extra ---------- */
function chrome(){
  rotaTok++;resetAmb();SETD=null;
  document.documentElement.style.removeProperty("--bg");
  document.body.classList.remove("perfil","settings");
  document.querySelectorAll(".nav a").forEach(function(a){a.classList.remove("on")});
  var g=document.querySelector(".gear");if(g)g.classList.remove("on");
}
function title(){
  var h=route(),t="Trackly";
  if(h.indexOf("album-")===0){var m=S.meta[h.slice(6)];if(m)t=m.t+" · "+m.a+" — Trackly"}
  else if(h.indexOf("artist-")===0){var id=h.slice(7),k=S.artists[id]?id:Object.keys(S.artists).find(function(x){return (slug(S.artists[x].n)||x)===id});if(k)t=S.artists[k].n+" — Trackly"}
  else if(h.charAt(0)==="@")t="@"+h.slice(1)+" — Trackly";
  else{var L={feed:"Feed",search:"Search",diary:"Diary",profile:"Profile",login:"Log in",signup:"Create account",forgot:"Reset password",reset:"New password"};if(L[h])t=L[h]+" — Trackly";else if(h.indexOf("settings")===0)t="Settings — Trackly"}
  document.title=t;
}
function guarded(h){
  return h==="profile"||h.indexOf("settings")===0||h.indexOf("following-")===0||h.indexOf("lista-")===0||(h.charAt(0)==="@"&&h.slice(1).toLowerCase()===String(P().handle).toLowerCase());
}
var _rota=rota;
rota=function(){
  var h=route();
  if(ON&&!USER&&guarded(h)){
    chrome();
    if(!known){document.getElementById("app").innerHTML='<div class="load">Loading…</div>';Promise.race([ready,tm(2500)]).then(function(){known=true;rota()});return}
    NAV.replace("login");h="login";
  }
  if(AUTHV[h]){
    chrome();title();
    if(USER&&h!=="reset"){NAV.replace("home");return _rota()}
    if(!ON){document.getElementById("app").innerHTML=msgView("Accounts are off","This site is not connected to Supabase yet. Fill in js/config.js.");return}
    document.getElementById("app").innerHTML=AUTHV[h]();window.scrollTo(0,0);
    var i=document.querySelector("#app input");if(i&&innerWidth>700)i.focus();
    return;
  }
  if(h.charAt(0)==="@"&&h.slice(1).toLowerCase()!==String(P().handle).toLowerCase()){
    chrome();title();publicProfile(h.slice(1).toLowerCase());return;
  }
  title();
  return _rota();
};

/* ---------- inicialização ---------- */
function setUser(sess,ev){
  var was=USER&&USER.id;
  USER=sess?sess.user:null;
  if(ev==="PASSWORD_RECOVERY")NAV.go("reset");
  if(USER&&!started){started=true;afterLogin().catch(function(e){console.warn("[trackly]",e)})}
  if(!USER)started=false;
  headerSync();
  readyRes();
  var h=route();
  if((USER&&USER.id)!==was&&(AUTHV[h]||h.indexOf("settings")===0||h.charAt(0)==="@")){try{rota()}catch(e){}}
}
if(ON){
  SB.auth.onAuthStateChange(function(ev,sess){setTimeout(function(){setUser(sess,ev)},0)});
  SB.auth.getSession().then(function(r){if(!USER&&r.data&&r.data.session)setUser(r.data.session,"INITIAL_SESSION");else readyRes()}).catch(function(){readyRes()});
  document.addEventListener("visibilitychange",function(){if(document.visibilityState==="hidden"&&USER&&LS("tk-dirty")==="1")push()});
  window.addEventListener("online",function(){if(USER&&LS("tk-dirty")==="1")push()});
}else readyRes();
headerSync();
})();