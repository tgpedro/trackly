/* ============================================================
   Trackly · configuração
   Edite só este arquivo. A "anon key" do Supabase PODE ficar
   pública (quem protege os dados é o RLS do schema.sql).
   ============================================================ */
window.TRACKLY={
  SITE_URL:"https://trackly.fwh.is",

  /* Supabase → Project Settings → API */
  SUPABASE_URL:"https://uhjftilgtebjrbwozoro.supabase.co",
  SUPABASE_ANON_KEY:"sb_publishable_2cf_SU3wqUzULGJ2emE2pQ_hq9HapaK",

  /* Mostrar botão "Continuar com Google" (precisa ativar o provider no Supabase) */
  GOOGLE_LOGIN:false,

  /* Seus Workers da Cloudflare (Deezer / Spotify). Deixe como estão se já funcionam. */
  PROXY:"https://acetato-proxy.tgpedro.workers.dev",
  SPOTIFY_PROXY:"https://acetato-spotify.tgpedro.workers.dev"
};
