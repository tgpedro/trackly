/* Trackly · roteador com URLs limpas (History API)
   /artist/radiohead · /album/abc123 · /user/pedro · /settings/profile ...
   O app antigo usava "#artist-xxx". Aqui o código continua falando "hash virtual" (NAV.hash),
   mas o endereço real do navegador é sempre um caminho limpo. */
(function(){
  "use strict";
  var SIMPLE={home:1,feed:1,search:1,diary:1,profile:1,login:1,signup:1,forgot:1,reset:1};

  /* caminho real -> rota interna ("#artist-xxx") */
  function pathToHash(p){
    p=(p||"/").replace(/\/+$/,"")||"/";
    if(p==="/"||p==="/index.html")return "#home";
    var s=p.split("/").filter(Boolean),a=s[0].toLowerCase(),b=s.slice(1).join("/");
    if(SIMPLE[a]&&!b)return a==="home"?"#home":"#"+a;
    switch(a){
      case "artist":return b?"#artist-"+b:"#search";
      case "album":return b?"#album-"+b:"#search";
      case "user":case "u":return b?"#@"+b:"#profile";
      case "list":return b?"#lista-"+b:"#profile";
      case "settings":return b?"#settings-"+b:"#settings";
      case "following":return "#following-"+(b||"artists");
    }
    return null;
  }

  /* rota interna -> caminho real (null = não é rota do app) */
  function hashToPath(h){
    h=String(h==null?"":h);if(h.charAt(0)==="#")h=h.slice(1);
    if(!h)return null;
    if(h==="home")return "/";
    if(h.charAt(0)==="@")return "/user/"+h.slice(1);
    var m;
    if((m=/^(album|artist)-(.+)$/.exec(h)))return "/"+m[1]+"/"+m[2];
    if((m=/^lista-(.+)$/.exec(h)))return "/list/"+m[1];
    if((m=/^settings(?:-(.+))?$/.exec(h)))return "/settings"+(m[1]?"/"+m[1]:"");
    if((m=/^following-(.+)$/.exec(h)))return "/following/"+m[1];
    if(SIMPLE[h])return "/"+h;
    return null;
  }

  function fire(sync){
    var f=function(){window.dispatchEvent(new Event("navchange"))};
    sync?f():setTimeout(f,0);
  }

  var NAV={
    get hash(){return pathToHash(location.pathname)||"#home"},
    toPath:hashToPath,
    go:function(h){
      var p=hashToPath(h);if(p==null)return;
      if(p===location.pathname)return;
      history.pushState(null,"",p);
      window.scrollTo(0,0);
      fire(0);
    },
    replace:function(h){
      var p=hashToPath(h);if(p==null)return;
      history.replaceState(null,"",p+location.search);
    },
    hrefOf:function(a){return (a.dataset&&a.dataset.h)||a.getAttribute("href")||""}
  };
  window.NAV=NAV;

  window.addEventListener("popstate",function(){fire(1)});

  /* links antigos (/#artist-xxx) viram URL limpa; ignora #access_token etc. do Supabase */
  if(location.hash.length>1&&(location.pathname==="/"||/\/index\.html$/.test(location.pathname))){
    var lp=hashToPath(location.hash);
    if(lp)history.replaceState(null,"",lp+location.search);
  }
  /* caminho desconhecido (ex.: /qualquer-coisa) volta pra home */
  if(pathToHash(location.pathname)===null)history.replaceState(null,"","/"+location.search);

  /* troca href="#album-x" por href="/album/x" assim que o ponteiro chega (clique direito / nova aba funcionam) */
  function fix(a){
    var h=a.getAttribute("href");
    if(h&&h.charAt(0)==="#"&&h.length>1){
      var p=hashToPath(h);
      if(p){a.dataset.h=h;a.setAttribute("href",p)}
    }
  }
  ["pointerover","focusin","touchstart","mousedown"].forEach(function(ev){
    document.addEventListener(ev,function(e){
      var a=e.target&&e.target.closest&&e.target.closest('a[href^="#"]');
      if(a)fix(a);
    },true);
  });

  /* clique em link interno = navegação sem recarregar a página */
  window.addEventListener("click",function(e){
    if(e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;
    var a=e.target&&e.target.closest&&e.target.closest("a[href]");
    if(!a||(a.target&&a.target!=="_self")||a.hasAttribute("download"))return;
    var h=(a.dataset&&a.dataset.h)||a.getAttribute("href");
    if(h&&h.charAt(0)==="#"&&hashToPath(h)!=null){e.preventDefault();NAV.go(h)}
  });
})();
