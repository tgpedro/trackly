/* Trackly · cria o cliente Supabase o mais cedo possível (antes do app),
   para ele conseguir ler o ?code= dos links de e-mail / login social. */
(function(){
  var C=window.TRACKLY||{};
  var ok=C.SUPABASE_URL&&C.SUPABASE_ANON_KEY&&!/COLE_AQUI/.test(C.SUPABASE_URL+C.SUPABASE_ANON_KEY)&&window.supabase&&window.supabase.createClient;
  window.sb=null;
  if(!ok){console.info("[trackly] Supabase não configurado: rodando só com dados locais.");return}
  try{
    window.sb=window.supabase.createClient(C.SUPABASE_URL,C.SUPABASE_ANON_KEY,{
      auth:{flowType:"pkce",persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}
    });
  }catch(e){console.warn("[trackly] falha ao iniciar o Supabase",e)}
})();
