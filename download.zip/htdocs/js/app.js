/* Trackly · app principal (gerado a partir do Acetato). Blocos na ordem original. */

;/* ---------- bloco 01 ---------- */
/* ===== Configuração e dados locais ===== */
const PROXY=TRACKLY.PROXY,DZ="https://api.deezer.com",IT="https://itunes.apple.com",MB="https://musicbrainz.org/ws/2",CAA="https://coverartarchive.org";
/* Spotify: cole aqui o endereço do Worker do Spotify (ex.: https://trackly-spotify.seuusuario.workers.dev). Vazio = Spotify desligado. */
const SPOTIFY_PROXY=TRACKLY.SPOTIFY_PROXY||"";
const KEY="trackly-v1";
let S=null;
try{S=JSON.parse(localStorage.getItem(KEY)||localStorage.getItem("trackly-multi-v1"))}catch(e){}
if(!S)S={u:{},meta:{},artists:{},listas:[],perfil:null};
S.meta=S.meta||{};S.artists=S.artists||{};S.covers=S.covers||{};
/* Capa personalizada (se existir) tem prioridade sobre a capa vinda das fontes */
const coverDe=k=>(S.covers&&S.covers[k])||(S.meta[k]||{}).cover||"";
const salvar=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){flash("Could not save to the browser")}try{window.__onSave&&window.__onSave()}catch(e){}};
const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const ini=t=>String(t||"?").split(/\s+/).filter(Boolean).map(w=>w[0]).slice(0,2).join("").toUpperCase()||"?";
function cores(s){let h=0;for(const ch of String(s))h=(h*31+ch.charCodeAt(0))%360;return [`hsl(${h} 70% 55%)`,`hsl(${(h+50)%360} 65% 22%)`]}
function flash(m){const f=document.createElement("div");f.className="flash";f.textContent=m;document.body.appendChild(f);setTimeout(()=>f.remove(),2400)}
const P=()=>{if(!S.perfil)S.perfil={nome:"Your name",handle:"your.handle",bio:"",local:"",avatar:"",banner:"",fav:[],musicas:[]};return S.perfil};
const dd=k=>S.u[k]||(S.u[k]={});
const hoje=()=>new Date().toISOString().slice(0,10);
const tempo=ms=>{const s=Math.round((ms||0)/1000);return s?`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`:""};
function setAmb(c){$("#amb").style.background=`radial-gradient(80% 60% at 50% 0%,${c}88,transparent 80%)`}
function resetAmb(){$("#amb").style.background="none"}
let rotaTok=0,aba="perfil",EDIT=null,busca={q:"",f:"tudo"},buscaTok=0,hqT=null,listaDel=null;

/* ===== Normalização e chaves de união ===== */
const norm=s=>String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/\(.*?\)|\[.*?\]/g,"").replace(/[^a-z0-9]+/g,"");
function hash(s){let h=5381;for(const c of s)h=((h<<5)+h)^c.charCodeAt(0);return (h>>>0).toString(36)}
function baseTitulo(t){
  let s=String(t||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");
  s=s.replace(/\(.*?\)|\[.*?\]/g," ").replace(/\s[-–—:]\s.*$/," ");
  s=s.replace(/\b(super deluxe|deluxe|remaster(ed)?|edition|edicao|versao|version|expanded|bonus|anniversary|reissue|complete|collector'?s|mono|stereo)\b/g," ");
  return s.replace(/[^a-z0-9]+/g,"");
}
const albumKey=(t,a)=>"a"+hash(baseTitulo(t)+"|"+norm(a));
const artistKey=n=>"r"+hash(norm(n));
const temCapa=u=>!!u.cover&&!/\/cover\/\//.test(u.cover)&&!/\/artist\/\//.test(u.cover);
const slug=s=>String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
async function artistRoute(id){
  let k=id;
  if(!S.artists[k]){
    k=Object.keys(S.artists).find(x=>(slug(S.artists[x].n)||x)===id);
    if(!k){
      const j=await dz(`/search/artist?q=${encodeURIComponent(id.replace(/-/g," "))}&limit=5`).catch(()=>({data:[]}));
      const h=(j.data||[]).find(x=>slug(x.name)===id)||(j.data||[])[0];
      if(!h)return `<div class="empty">Artist not found.</div>`;
      k=artistKey(h.name);
      if(!S.artists[k]){guardarArtista({key:k,n:h.name,foto:h.picture_xl||"",fas:h.nb_fan||0,ids:{dz:h.id},fontes:["dz"]});salvar()}
    }
  }
  NAV.replace("#artist-"+(slug(S.artists[k].n)||k));
  return artistView(k);
}
const RANK={dz:0,it:1,sp:1.5,mb:2};
const nomeFonte=f=>f==="dz"?"Deezer":f==="it"?"Apple Music":f==="sp"?"Spotify":"MusicBrainz";

/* ===== Chamadas às fontes ===== */
async function getJSON(url){const r=await fetch(url);if(!r.ok)throw new Error(r.status);return r.json()}
function jsonp(url){return new Promise((ok,err)=>{const cb="dz"+Math.random().toString(36).slice(2,9);const s=document.createElement("script");const t=setTimeout(()=>{limpa();err(new Error("tempo"))},9000);function limpa(){clearTimeout(t);delete window[cb];s.remove()}window[cb]=j=>{limpa();ok(j)};s.onerror=()=>{limpa();err(new Error("falha"))};s.src=url+(url.includes("?")?"&":"?")+`output=jsonp&callback=${cb}`;document.head.appendChild(s)})}
async function dz(p){const url=DZ+p;let j;if(PROXY){try{j=await getJSON(PROXY+"/deezer?u="+encodeURIComponent(url))}catch(e){j=await jsonp(url)}}else{j=await jsonp(url)}if(j.error)throw new Error(j.error.message);return j}
let mbFila=Promise.resolve();
function mb(c){const p=mbFila.then(async()=>{await new Promise(r=>setTimeout(r,1100));const j=await getJSON(`${MB}${c}${c.includes("?")?"&":"?"}fmt=json`);return j});mbFila=p.catch(()=>{});return p}
const acMB=x=>(x["artist-credit"]||[]).map(c=>c.name).join(", ")||"Desconhecido";
const capaIT=u=>(u||"").replace(/\d+x\d+bb/,"600x600bb");

/* ===== Spotify (catálogo, via Worker) ===== */
const spOn=()=>!!SPOTIFY_PROXY;
function spGet(path){
  if(!spOn())return Promise.reject(new Error("spotify desligado"));
  return getJSON(`${SPOTIFY_PROXY.replace(/\/spotify\/?$/,"").replace(/\/$/,"")}/spotify?path=${encodeURIComponent(path)}`);
}
const spMemo=new Map();
function spSearch(q){
  if(!spMemo.has(q)){
    const pr=spGet(`/v1/search?q=${q}&type=album,artist,track&limit=10`);
    pr.catch(()=>spMemo.delete(q));
    spMemo.set(q,pr);
    if(spMemo.size>30)spMemo.delete(spMemo.keys().next().value);
  }
  return spMemo.get(q);
}
const spImg=x=>(x&&x.images&&x.images[0]&&x.images[0].url)||"";
const spTipo=a=>a.album_type==="compilation"?"compile":a.album_type==="single"?((a.total_tracks||1)<=3?"single":"ep"):"album";
const spNome=x=>((x.artists||[])[0]||{}).name||"";

/* Cada fonte devolve itens no mesmo formato: {src,id,t,a,y,tipo,cover,genre,n} */
const fontes={
  albunsDZ:q=>dz(`/search/album?q=${q}&limit=25`).then(j=>(j.data||[]).map(x=>({src:"dz",id:x.id,t:x.title,a:x.artist?.name||"",y:(x.release_date||"").slice(0,4),tipo:x.record_type||"album",cover:x.cover_xl||x.cover_big||"",n:x.nb_tracks}))),
  albunsIT:q=>getJSON(`${IT}/search?term=${q}&entity=album&limit=25`).then(j=>j.results.map(x=>({src:"it",id:x.collectionId,t:x.collectionName,a:x.artistName,y:(x.releaseDate||"").slice(0,4),tipo:x.trackCount<=6?"ep":"album",cover:capaIT(x.artworkUrl100),genre:x.primaryGenreName,n:x.trackCount}))),
  albunsMB:q=>mb(`/release-group?query=${q}&limit=25`).then(j=>(j["release-groups"]||[]).map(r=>({src:"mb",id:r.id,t:r.title,a:acMB(r),y:(r["first-release-date"]||"").slice(0,4),tipo:(r["primary-type"]||"album").toLowerCase(),cover:`${CAA}/release-group/${r.id}/front-500`}))),
  musicasDZ:q=>dz(`/search/track?q=${q}&limit=20`).then(j=>(j.data||[]).map(t=>({src:"dz",titulo:t.title,artista:t.artist.name,ms:t.duration*1000,album:{src:"dz",id:t.album.id,t:t.album.title,a:t.artist.name,y:"",tipo:"album",cover:t.album.cover_big||t.album.cover_medium||""}}))),
  musicasIT:q=>getJSON(`${IT}/search?term=${q}&entity=song&limit=20`).then(j=>j.results.map(t=>({src:"it",titulo:t.trackName,artista:t.artistName,ms:t.trackTimeMillis,album:{src:"it",id:t.collectionId,t:t.collectionName,a:t.artistName,y:(t.releaseDate||"").slice(0,4),tipo:"album",cover:capaIT(t.artworkUrl100),genre:t.primaryGenreName}}))),
  artistasDZ:q=>dz(`/search/artist?q=${q}&limit=20`).then(j=>(j.data||[]).map(x=>({src:"dz",id:x.id,n:x.name,foto:x.picture_xl||x.picture_big||"",fas:x.nb_fan||0}))),
  artistasIT:q=>getJSON(`${IT}/search?term=${q}&entity=musicArtist&limit=10`).then(j=>j.results.map(x=>({src:"it",id:x.artistId,n:x.artistName,genre:x.primaryGenreName}))),
  albunsSP:q=>spSearch(q).then(j=>((j.albums||{}).items||[]).filter(Boolean).map(x=>({src:"sp",id:x.id,t:x.name,a:spNome(x),y:(x.release_date||"").slice(0,4),tipo:spTipo(x),cover:spImg(x),n:x.total_tracks}))),
  musicasSP:q=>spSearch(q).then(j=>((j.tracks||{}).items||[]).filter(Boolean).map(t=>({src:"sp",titulo:t.name,artista:spNome(t),ms:t.duration_ms,album:{src:"sp",id:t.album.id,t:t.album.name,a:spNome(t.album),y:(t.album.release_date||"").slice(0,4),tipo:spTipo(t.album),cover:spImg(t.album)}}))),
  artistasSP:q=>spSearch(q).then(j=>((j.artists||{}).items||[]).filter(Boolean).map(x=>({src:"sp",id:x.id,n:x.name,foto:spImg(x),genre:(x.genres||[])[0]||""}))),
  artistasMB:q=>mb(`/artist?query=${q}&limit=12`).then(j=>(j.artists||[]).map(x=>({src:"mb",id:x.id,n:x.name,info:x.disambiguation||x.type||""})))
};

/* ===== Unificação ===== */
function unirAlbuns(itens){
  const mapa=new Map();
  for(const it of itens){
    if(!it.t)continue;
    const k=albumKey(it.t,it.a);
    let u=mapa.get(k);
    if(!u){u={key:k,t:it.t,a:it.a,y:it.y,tipo:"",cover:"",coverRank:9,genre:"",ids:{},fontes:[]};mapa.set(k,u)}
    if(it.y&&(!u.y||it.y<u.y))u.y=it.y;
    if(!u.tipo||it.src==="dz")u.tipo=it.tipo||u.tipo;
    if(it.cover&&RANK[it.src]<u.coverRank){u.cover=it.cover;u.coverRank=RANK[it.src]}
    if(!u.genre&&it.genre)u.genre=it.genre;
    if(it.n&&!u.n)u.n=it.n;
    if(!u.ids[it.src])u.ids[it.src]=it.id;
    if(!u.fontes.includes(it.src))u.fontes.push(it.src);
  }
  return [...mapa.values()].sort((a,b)=>b.fontes.length-a.fontes.length);
}
function unirArtistas(itens){
  const mapa=new Map();
  for(const it of itens){
    if(!it.n)continue;
    const k=artistKey(it.n);
    let u=mapa.get(k);
    if(!u){u={key:k,n:it.n,foto:"",fas:0,genre:"",ids:{},fontes:[]};mapa.set(k,u)}
    if(it.foto&&!u.foto)u.foto=it.foto;
    if(it.fas>u.fas)u.fas=it.fas;
    if(it.genre&&!u.genre)u.genre=it.genre;
    if(it.info&&!u.info)u.info=it.info;
    u._f=u._f||{};const fn=it.fas||0;
    if(!u.ids[it.src]||fn>(u._f[it.src]||0)){u.ids[it.src]=it.id;u._f[it.src]=fn}
    if(!u.fontes.includes(it.src))u.fontes.push(it.src);
  }
  return [...mapa.values()].sort((a,b)=>b.fontes.length-a.fontes.length);
}
function guardarAlbum(u){S.meta[u.key]={t:u.t,a:u.a,y:u.y||"",tipo:u.tipo||"album",cover:u.cover||"",genre:u.genre||"",ids:u.ids,fontes:u.fontes}}
function guardarArtista(u){S.artists[u.key]={n:u.n,foto:u.foto||"",fas:u.fas||0,genre:u.genre||"",info:u.info||"",ids:u.ids,fontes:u.fontes}}

/* ===== Componentes visuais ===== */
function capaAlbum(k,t,px){
  const m=S.meta[k]||{};
  const cv=coverDe(k);
  const [a,b]=cores(k);
  const sz=px?`width:${px}px;height:${px}px;font-size:${Math.round(px*.34)}px`:`width:100%;aspect-ratio:1;font-size:40px`;
  const img=cv?`<img src="${cv}" alt="" loading="lazy" onerror="this.remove()">`:"";
  return `<div class="cover" style="${sz};background:linear-gradient(145deg,${a},${b})">${img}<span>${esc(ini(t))}</span></div>`;
}
function capaFoto(url,t,px,redonda){
  const [a,b]=cores(t);
  const img=url?`<img src="${url}" alt="" loading="lazy" onerror="this.remove()">`:"";
  return `<div class="cover" style="width:${px}px;height:${px}px;font-size:${Math.round(px*.34)}px;background:linear-gradient(145deg,${a},${b})${redonda?";border-radius:50%":""}">${img}<span>${esc(ini(t))}</span></div>`;
}
function cardAlbum(u){return `<a class="card" href="#album-${u.key}" style="--c:${cores(u.key)[0]}">${capaAlbum(u.key,u.t,null)}<div class="info"><div class="ta">${esc(u.t)}</div><div class="sa">${u.solo?esc(u.y||""):`${esc(u.a)}${u.y?` · ${u.y}`:""}`}</div></div></a>`}
function cardArtista(u){return `<a class="card gc" href="#artist-${u.key}" style="--c:${cores(u.n)[0]}">${capaFoto(u.foto,u.n,150,true)}<div class="t">${esc(u.n)}</div><div class="s">${esc(u.genre||u.info||"Artist")}</div></a>`}
function cardMeta(k){const m=S.meta[k]||{t:"Album",a:""};return cardAlbum({key:k,t:m.t,a:m.a,y:m.y,fontes:m.fontes||[]})}
function rateHTML(r=0){let h="";for(let i=1;i<=5;i++){const c=r>=i?"on":r>=i-.5?"half":"";h+=`<span class="rbtn"><i class="${c}">★</i><b class="l" data-v="${i-.5}"></b><b class="r" data-v="${i}"></b></span>`}return h}
function estrelas(r){let h="";for(let i=1;i<=5;i++){const c=r>=i?"on":r>=i-.5?"half":"";h+=`<span class="st ${c}">★</span>`}return `<span class="stars">${h}</span>`}
const erroHTML=()=>`<div class="empty">Could not load right now. Try again in a few seconds.</div>`;

async function tendencias(){
  const paises=["us","gb","de","fr","jp","mx","kr","au","ca","it","es"];
  const apUmPais=p=>getJSON(`https://itunes.apple.com/${p}/rss/topalbums/limit=30/json`).then(j=>(j.feed?.entry||[]).map(e=>({id:e.id.attributes["im:id"],name:e["im:name"].label,artistName:e["im:artist"].label,artworkUrl100:e["im:image"][2].label}))).then(r=>{if(!r.length)throw 0;return r}).catch(()=>getJSON(`${PROXY}/feed/${p}`).then(j=>j.results||[]));
  const ap=await Promise.allSettled(paises.map(apUmPais));
  const generos=[];
  const dzc=await Promise.allSettled(generos.map(g=>dz(`/chart/${g}/albums?limit=25`).then(j=>j.data||[])));
  const okAp=ap.filter(x=>x.status==="fulfilled").length;
  const apStatus=`Apple ${okAp}/${paises.length} countries`;
  const okDz=dzc.filter(x=>x.status==="fulfilled").length;
  const itens=[];
  ap.forEach(x=>{if(x.status==="fulfilled")x.value.forEach(r=>itens.push({src:"it",id:r.id,t:r.name,a:r.artistName,y:"",tipo:"album",cover:capaIT(r.artworkUrl100)}))});
  dzc.forEach(x=>{if(x.status==="fulfilled")x.value.forEach(r=>itens.push({src:"dz",id:r.id,t:r.title,a:r.artist?.name||"",y:(r.release_date||"").slice(0,4),tipo:"album",cover:r.cover_xl||r.cover_big||""}))});
  window.__ap=paises.map((p,i)=>[p,ap[i]||{}]);return {lista:unirAlbuns(itens),status:`Sources: ${apStatus}`};
}
let homeGenero=0;
const GENEROS_HOME=[[0,"Worldwide"],[132,"Pop"],[116,"Hip-hop"],[85,"Alternative"],[106,"Electronic"],[165,"R&B"]];
async function homeView(){
  const cardsDe=lista=>unirAlbuns(lista.map(x=>({src:"dz",id:x.id,t:x.title,a:x.artist?.name||"",y:(x.release_date||"").slice(0,4),tipo:x.record_type||"album",cover:x.cover_xl||x.cover_big||x.cover_medium||""}))).filter(temCapa).map(u=>{guardarAlbum(u);return cardAlbum(u)}).join("");
  let lista=[],status="";
  if(homeGenero===0){const r=await tendencias();lista=r.lista;status=r.status}
  else{
    window.__ap=[];
    const GA={132:14,116:18,85:20,106:7,165:15};
    const fd=await Promise.allSettled(["us","gb","ca","au","de","jp"].map(p=>getJSON(`https://itunes.apple.com/${p}/rss/topalbums/genre=${GA[homeGenero]}/limit=20/json`).then(j=>(j.feed?.entry||[]).map(e=>({src:"it",id:e.id.attributes["im:id"],t:e["im:name"].label,a:e["im:artist"].label,y:"",tipo:"album",cover:capaIT(e["im:image"][2].label)})))));
    lista=unirAlbuns(fd.flatMap(x=>x.status==="fulfilled"?x.value:[]));
    status="Apple Music · global";
  }
  lista=lista.filter(temCapa);lista.forEach(guardarAlbum);
  const top=lista.slice(0,24);
  window.__chart=top.map(u=>({title:u.t,artist:{name:u.a},cover_xl:u.cover}));
  const emAlta=top.map(u=>cardAlbum(u)).join("");
  const t0=top[0];
  const heroi=top.length?`<div class="atv" id="atv"><div class="atv-track">${top.slice(0,6).map((u,i)=>{const cv=coverDe(u.key)||u.cover;return `<div class="atv-s${i?"":" on"}"><div class="atv-bg" style="background-image:url('${cv}')"></div><div class="atv-shade"></div><div class="atv-body"><img class="atv-art" src="${cv}" alt=""><div class="atv-info"><span class="atv-tag">${i===0?"#1 Right Now":"Trending #"+(i+1)}</span><h2 class="atv-t">${esc(u.t)}</h2><div class="atv-a">${esc(u.a)}${u.y?" · "+u.y:""}</div><div class="atv-b"><a class="gl pri" href="#album-${u.key}">Open Album</a><button class="gl" data-rnd>Surprise Me</button></div></div></div></div>`}).join("")}</div><div class="atv-dots">${top.slice(0,6).map((u,i)=>`<button class="${i?"":"on"}" data-atv="${i}" aria-label="Slide ${i+1}"></button>`).join("")}</div></div>`:"";
  let popRec="",rec="";
  const ult=S.ultimoArtista;
  if(ult&&ult.id){
    try{
      const rel=((await dz(`/artist/${ult.id}/related?limit=12`)).data||[]).sort((a,b)=>(b.nb_fan||0)-(a.nb_fan||0)).slice(0,8);
      const alb=await Promise.all(rel.map(o=>dz(`/artist/${o.id}/albums?limit=1`).then(j=>(j.data||[]).map(x=>({...x,artist:{name:o.name}}))).catch(()=>[])));
      const c=cardsDe(alb.flat());
      if(c)popRec=`<div class="sec-h"><h2>Because you searched ${esc(ult.n)}</h2></div><div class="carrossel">${c}</div>`;
    }catch(e){}
  }
  const avaliados=Object.entries(S.u).filter(([k,v])=>v.r&&S.meta[k]).sort((a,b)=>b[1].r-a[1].r);
  const jaAvaliados=new Set(Object.keys(S.u));
  const conhecidos=new Set(avaliados.map(([k])=>norm(S.meta[k].a)));
  const sementes=avaliados.slice(0,3).map(([k])=>S.artists[artistKey(S.meta[k].a)]?.ids?.dz).filter(Boolean);
  if(sementes.length){
    try{
      const rels=await Promise.all(sementes.map(id=>dz(`/artist/${id}/related?limit=8`).then(j=>j.data||[]).catch(()=>[])));
      const cont=new Map();
      rels.flat().forEach(a=>{if(conhecidos.has(norm(a.name)))return;const c=cont.get(a.id)||{a,n:0};c.n++;cont.set(a.id,c)});
      const topA=[...cont.values()].sort((x,y)=>y.n-x.n).slice(0,6);
      const listas=await Promise.all(topA.map(c=>dz(`/artist/${c.a.id}/albums?limit=2`).then(j=>(j.data||[]).map(x=>({...x,artist:{name:c.a.name}}))).catch(()=>[])));
      const c=cardsDe(listas.flat().filter(x=>!jaAvaliados.has(albumKey(x.title,x.artist.name))).slice(0,12));
      if(c)rec=`<div class="sec-h"><h2>Recommended for you</h2></div><div class="carrossel">${c}</div>`;
    }catch(e){}
  }
  let novidades="";
  const seguidos=(S.seguindo||[]).filter(s=>s.dz).slice(0,8);
  if(seguidos.length){
    try{
      const listas=await Promise.all(seguidos.map(s=>dz(`/artist/${s.dz}/albums?limit=3`).then(j=>(j.data||[]).map(x=>({...x,artist:{name:s.n}}))).catch(()=>[])));
      const recentes=listas.flat().sort((a,b)=>(b.release_date||"").localeCompare(a.release_date||"")).slice(0,12);
      const c=cardsDe(recentes);
      if(c)novidades=`<div class="sec-h"><h2>New from artists you follow</h2></div><div class="carrossel">${c}</div>`;
    }catch(e){}
  }
  const NP={us:"United States",gb:"United Kingdom",jp:"Japan",kr:"South Korea",de:"Germany",fr:"France",mx:"Mexico"};
  let regioes="";
  (window.__ap||[]).forEach(([p,r])=>{
    if(!NP[p]||r.status!=="fulfilled")return;
    const l=unirAlbuns(r.value.slice(0,30).map(x=>({src:"it",id:x.id,t:x.name,a:x.artistName,y:"",tipo:"album",cover:capaIT(x.artworkUrl100)})));
    l.forEach(guardarAlbum);
    const lf=l.filter(temCapa).slice(0,12);if(lf.length)regioes+=`<div class="sec-h"><h2>Top in ${NP[p]}</h2></div><div class="carrossel">${lf.map(u=>cardAlbum(u)).join("")}</div>`;
  });
  const diario=Object.entries(S.u).filter(([,v])=>v.d).sort((a,b)=>b[1].d.localeCompare(a[1].d)).slice(0,10);
  return `${heroi}
  <input class="search" id="hq" placeholder="Artists, albums, songs" autocomplete="off" style="margin-top:4px">
  <div class="chips" style="padding-top:14px">${GENEROS_HOME.map(([id,l])=>`<button class="chip ${homeGenero===id?"on":""}" data-hg="${id}">${l}</button>`).join("")}</div>
  <div class="sec-h"><h2>Trending</h2><span class="mut sm">${esc(status)}</span></div>
  ${emAlta?`<div class="carrossel">${emAlta}</div>`:`<div class="empty">Could not load trends right now.</div>`}
  ${regioes}${novidades}
  ${rec}
  ${popRec}
  ${diario.length?`<div class="sec-h"><h2>Recently in your diary</h2></div><div class="carrossel">${diario.map(([k])=>cardMeta(k)).join("")}</div>`:""}`;
}

/* ===== Buscar: três fontes em paralelo, resultados aparecem conforme chegam ===== */
function searchView(){
  return `<h1>Search</h1><input class="search" id="q" placeholder="Albums, EPs, songs or artists" autocomplete="off" value="${esc(busca.q)}">
  <div class="chips">${[["tudo","All"],["albuns","Albums & EPs"],["musicas","Songs"],["artistas","Artists"]].map(([k,l])=>`<button class="chip ${busca.f===k?"on":""}" data-fl="${k}">${l}</button>`).join("")}</div>
  <div id="res" style="margin-top:18px"></div>`;
}
function tipoLabel(t){t=(t||"").toLowerCase();if(t==="ep")return"EP";if(t==="single")return"Single";if(t==="compile")return"Compilation";return"Album"}
function dedupMusicas(lista){const v=new Set();return lista.filter(m=>{const c=norm(m.titulo)+"|"+norm(m.artista);if(v.has(c))return false;v.add(c);return true})}
function linhaMista(it){
  if(it.tipo==="artista"){const a=it.a;return `<a class="row" href="#artist-${a.key}">${capaFoto(a.foto,a.n,52,true)}<div class="grow"><div class="ttl">${esc(a.n)}</div><div class="sm mut" style="font-weight:700">Artist</div></div><span class="pill">Artist</span></a>`}
  if(it.tipo==="album"){const u=it.u;return `<a class="row" href="#album-${u.key}">${capaAlbum(u.key,u.t,52)}<div class="grow"><div class="ttl">${esc(u.t)}</div><div class="sm mut" style="font-weight:700">${esc(u.a)}${u.y?" · "+u.y:""}</div></div><span class="pill">${tipoLabel(u.tipo)}</span></a>`}
  const m=it.m,k=albumKey(m.album.t,m.album.a);
  return `<a class="row" href="#album-${k}">${capaAlbum(k,m.album.t,52)}<div class="grow"><div class="ttl">${esc(m.titulo)}</div><div class="sm mut" style="font-weight:700">${esc(m.artista)} · ${esc(m.album.t)}</div></div><span class="pill">Song</span></a>`;
}
function destaqueBusca(it){
  if(it.tipo==="artista"){const a=it.a;return `<a class="card" href="#artist-${a.key}" style="display:flex;gap:20px;align-items:center;padding:20px;--c:${cores(a.key)[0]}">${capaFoto(a.foto,a.n,120,true)}<div class="grow"><span class="pill">Artist</span><div style="font-size:30px;font-weight:900;letter-spacing:-.8px;margin-top:8px">${esc(a.n)}</div></div></a>`}
  if(it.tipo==="album"){const u=it.u;return `<a class="card" href="#album-${u.key}" style="display:flex;gap:20px;align-items:center;padding:20px;--c:${cores(u.key)[0]}">${capaAlbum(u.key,u.t,120)}<div class="grow"><span class="pill">${tipoLabel(u.tipo)}</span><div style="font-size:30px;font-weight:900;letter-spacing:-.8px;margin-top:8px">${esc(u.t)}</div><div class="mut" style="font-weight:700;margin-top:4px">${esc(u.a)}${u.y?" · "+u.y:""}</div></div></a>`}
  const m=it.m,k=albumKey(m.album.t,m.album.a);
  return `<a class="card" href="#album-${k}" style="display:flex;gap:20px;align-items:center;padding:20px;--c:${cores(k)[0]}">${capaAlbum(k,m.album.t,120)}<div class="grow"><span class="pill">Song</span><div style="font-size:30px;font-weight:900;letter-spacing:-.8px;margin-top:8px">${esc(m.titulo)}</div><div class="mut" style="font-weight:700;margin-top:4px">${esc(m.artista)} · ${esc(m.album.t)}</div></div></a>`;
}
function montarBusca(q,coleta,f){
  const albuns=unirAlbuns(coleta.alb);albuns.forEach(guardarAlbum);
  const artistas=unirArtistas(coleta.art);artistas.forEach(guardarArtista);
  const musicas=dedupMusicas(coleta.mus).slice(0,20);
  const nq=norm(q);const itens=[];
  if(f==="tudo"||f==="albuns")albuns.forEach(u=>itens.push({tipo:"album",u,score:u.fontes.length*10+(norm(u.t)===nq?50:0)+(norm(u.t).startsWith(nq)?15:0)}));
  if(f==="tudo"||f==="artistas")artistas.forEach(a=>itens.push({tipo:"artista",a,score:a.fontes.length*10+(norm(a.n)===nq?60:0)+(norm(a.n).startsWith(nq)?20:0)}));
  if(f==="tudo"||f==="musicas")musicas.forEach(m=>itens.push({tipo:"musica",m,score:(norm(m.titulo)===nq?50:0)+(norm(m.titulo).startsWith(nq)?15:0)+5}));
  itens.sort((x,y)=>y.score-x.score);
  if(!itens.length)return `<div class="empty">Nothing found for "${esc(q)}".</div>`;
  return `<div class="sec-h"><h2>Top result</h2></div>${destaqueBusca(itens[0])}<div class="sec-h"><h2>Results</h2></div><div class="mlist">${itens.slice(1,40).map(linhaMista).join("")}</div>`;
}
async function runSearch(){
  const q=busca.q.trim(),res=$("#res");
  if(!res)return;
  if(q.length<2){res.innerHTML=`<div class="empty">Type at least 2 letters to search.</div>`;return}
  const tok=++buscaTok,f=busca.f,e=encodeURIComponent(q);
  const coleta={alb:[],mus:[],art:[]};
  const desenhar=()=>{if(tok===buscaTok)res.innerHTML=montarBusca(q,coleta,f)};
  res.innerHTML=`<div class="load">Searching…</div>`;
  const rapido=await Promise.allSettled([fontes.albunsDZ(e),fontes.albunsIT(e),fontes.musicasDZ(e),fontes.musicasIT(e),fontes.artistasDZ(e),fontes.artistasIT(e),fontes.albunsSP(e),fontes.musicasSP(e),fontes.artistasSP(e)]);
  if(tok!==buscaTok)return;
  const ok=i=>rapido[i].status==="fulfilled"?rapido[i].value:[];
  coleta.alb.push(...ok(0),...ok(1),...ok(6));
  coleta.mus.push(...ok(2),...ok(3),...ok(7));
  coleta.mus.forEach(m=>coleta.alb.push(m.album));
  coleta.art.push(...ok(4),...ok(5),...ok(8));
  desenhar();
  Promise.allSettled([fontes.albunsMB(e),fontes.artistasMB(e)]).then(r=>{
    if(tok!==buscaTok)return;
    if(r[0].status==="fulfilled")coleta.alb.push(...r[0].value);
    if(r[1].status==="fulfilled")coleta.art.push(...r[1].value);
    desenhar();
  });
}

/* ===== Página do álbum ===== */
async function faixasDe(m){
  try{
    if(m.ids.dz){const d=await dz(`/album/${m.ids.dz}`);return (d.tracks?.data||[]).map(t=>({t:t.title,ms:t.duration*1000}))}
    if(m.ids.it){const j=await getJSON(`${IT}/lookup?id=${m.ids.it}&entity=song`);return j.results.filter(r=>r.wrapperType==="track").map(r=>({t:r.trackName,ms:r.trackTimeMillis}))}
    if(m.ids.sp){const d=await spGet(`/v1/albums/${m.ids.sp}`);return ((d.tracks||{}).items||[]).map(t=>({t:t.name,ms:t.duration_ms}))}
    if(m.ids.mb){const rel=(await mb(`/release?release-group=${m.ids.mb}&limit=1`)).releases||[];if(!rel[0])return[];const x=await mb(`/release/${rel[0].id}?inc=recordings`);return (x.media||[]).flatMap(md=>(md.tracks||[]).map(t=>({t:t.title,ms:t.length})))}
  }catch(e){}
  return [];
}
async function albumView(k){
  const m=S.meta[k];
  if(!m)return `<div class="empty">Open this album from search to load its data.</div>`;
  setAmb(cores(k)[0]);
  const ak=artistKey(m.a);
  if(!S.artists[ak]){S.artists[ak]={n:m.a,foto:"",fas:0,genre:"",info:"",ids:{},fontes:[]};salvar()}
  const x=dd(k);
  const faixas=await faixasDe(m);
  const listas=S.listas.map((l,i)=>`<option value="${i}">${esc(l.nome)}</option>`).join("");
  const fav=(P().fav||[]).includes(k);
  const fontesTxt=(m.fontes||[]).map(nomeFonte).join(" · ");
  const cv=coverDe(k),capaCustom=!!S.covers[k];
  return `${cv?`<div class="abg" aria-hidden="true"><div style="background-image:url(${cv})"></div></div>`:""}<div class="hero">${capaAlbum(k,m.t,230)}<div class="info">
    <span class="pill">${esc([(m.tipo||"álbum").toUpperCase(),m.genre].filter(Boolean).join(" · "))}</span>
    <h1>${esc(m.t)}</h1>
    <div style="font-size:18px;font-weight:700" class="mut"><a href="#artist-${ak}" style="border-bottom:2px solid currentColor">${esc(m.a)}</a>${m.y?` · ${m.y}`:""}${faixas.length?` · ${faixas.length} tracks`:""}</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin:20px 0">
      <button class="btn ${x.d?"on":""}" data-act="ouvi">${x.d?"✓ Listened":"Mark as listened"}</button>
      <button class="btn ${x.w?"on":""}" data-act="quero">${x.w?"✓ In queue":"+ Want to listen"}</button>
      <button class="btn ${x.l?"on":""}" data-act="curtir">${x.l?"♥ Liked":"♡ Like"}</button>
      <button class="btn ${fav?"on":""}" data-act="fav">${fav?"★ Favorite":"☆ Favorite"}</button>
    </div>
    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;justify-content:inherit"><div style="display:flex" id="rate" data-id="${k}">${rateHTML(x.r)}</div><span class="mut" style="font-weight:700" id="rlab">${x.r?String(x.r)+" of 5":"Your rating"}</span></div>
    ${faixas.length?mediaBloco(faixas,m,x):""}
    ${m.ids.sp?`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px"><a class="btn" href="https://open.spotify.com/album/${m.ids.sp}" target="_blank" rel="noopener">Open on Spotify</a></div>`:""}
  </div></div>
  ${faixas.length?`<h2>Tracks</h2>${faixas.length>1?`<div class="tbar"><div class="tsearch"><input class="search" id="tsearch" type="search" placeholder="Search tracks in this album" autocomplete="off"></div>${xsel("tsort",[["n","Album order"],["az","Title A–Z"],["za","Title Z–A"],["long","Longest first"],["short","Shortest first"]],"n")}</div>`:""}<div class="mlist" id="tlist">${faixas.map((t,i)=>`<div class="row" data-tn="${esc(t.t.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase())}" data-i="${i}" data-ms="${t.ms||0}"><span class="num">${String(i+1).padStart(2,"0")}</span><div class="ttl grow">${esc(t.t)}</div><div class="tact">${trateHTML(t.t,m.a)}<button class="shbtn" data-play data-tt="${esc(t.t)}" data-ta="${esc(m.a)}" aria-label="Preview, video and links" title="Preview, video and links" style="width:30px;height:30px;font-size:11px;padding-left:2px">▶</button><button class="shbtn" data-story="musica" data-tt="${esc(t.t)}" data-ms="${t.ms||0}" aria-label="Share song" title="Share song" style="width:30px;height:30px"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M8 7l4-4 4 4"/><path d="M8 11H6.5A1.5 1.5 0 0 0 5 12.5v7A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5v-7A1.5 1.5 0 0 0 17.5 11H16"/></svg></button></div><span class="mut sm tdur">${tempo(t.ms)}</span></div>`).join("")}<div class="tnone" id="tnone">No tracks found</div></div>`:`<div class="empty" style="margin-top:30px">No tracks available for this album.</div>`}
  <h2>Review</h2>
  <div class="lbx">
    <div class="lbx-h">${capaAlbum(k,m.t,64)}<div style="min-width:0"><div class="lbx-t">${esc(m.t)}</div><div class="lbx-s">${esc(m.a)}${m.y?` · ${m.y}`:""}</div></div></div>
    <label class="lbx-d"><span>Listened on</span><input type="date" id="revd" value="${esc(x.d||hoje())}" max="${hoje()}"></label>
    <textarea class="field" id="rev" placeholder="Add a review…">${esc(x.rev||"")}</textarea>
    <div class="lbx-f">
      <div class="lbx-r"><span class="mut sm" style="font-weight:700">Rating</span><div style="display:flex" id="rate2">${rateHTML(x.r)}</div></div>
      <button class="btn ${x.l?"on":""}" data-act="revlike">${x.l?"♥ Liked":"♡ Like"}</button>
    </div>
    <div class="lbx-b"><button class="fab" data-act="rev">Save</button><button class="btn" data-story="album">Share to Story</button></div>
  </div>
  ${S.listas.length?`<h2>Add to a list</h2><div style="display:flex;gap:10px;flex-wrap:wrap">${xsel("lsel",S.listas.map((l,i)=>[String(i),l.nome]),"0")}<button class="btn" data-act="addLista">Add</button></div>`:`<h2>Lists</h2><div class="empty">Create a list in the Lists tab of your Profile to add albums.</div>`}`;
}
function albumAct(a){
  const k=NAV.hash.slice(7);
  const d=dd(k);
  if(a==="revlike"){d.l=!d.l;salvar();document.querySelectorAll('[data-act="revlike"],[data-act="curtir"]').forEach(b=>{b.classList.toggle("on",!!d.l);b.innerHTML=a==="revlike"&&b.dataset.act==="revlike"?(d.l?"♥ Liked":"♡ Like"):(d.l?"♥ Liked":"♡ Like")});flash(d.l?"Liked":"Unliked");return}
  if(a==="ouvi"){if(d.d){delete d.d;flash("Removed from diary")}else{d.d=hoje();flash("Logged in diary")}}
  if(a==="quero"){d.w=!d.w;flash(d.w?"Added to queue":"Removed from queue")}
  if(a==="curtir"){d.l=!d.l;flash(d.l?"Liked":"Unliked")}
  if(a==="fav"){const p=P();const i=p.fav.indexOf(k);if(i>=0)p.fav.splice(i,1);else if(p.fav.length<10)p.fav.push(k);else{flash("Up to 10 favorite albums");return}}
  if(a==="rev"){d.rev=($("#rev").value||"").trim();const dv=($("#revd")||{}).value;d.d=dv||d.d||hoje();flash("Saved to your diary")}
  if(a==="capaRm"){delete S.covers[k];flash("Original cover restored")}
  if(a==="auto"){d.auto=!d.auto;const md=mediaDOM();if(d.auto&&md.n)d.r=meioPonto(md.avg);flash(d.auto?"Auto rating on":"Auto rating off")}
  if(a==="usarMedia"){const md=mediaDOM();if(md.n){d.r=meioPonto(md.avg);flash("Album rating updated")}}
  if(a==="addLista"){const l=S.listas[+$("#lsel").dataset.v];if(l&&!l.ids.includes(k)){l.ids.push(k);flash(`Added to "${l.nome}"`)}else flash("Already in that list")}
  salvar();rota();
}

/* ===== Página do artista (estilo Apple Music / Apple TV) ===== */
const fmtFas=n=>{try{return new Intl.NumberFormat("en",{notation:"compact",maximumFractionDigits:1}).format(n)}catch(e){return String(n)}};
const fmtData=d=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(d||""))return d||"";try{return new Date(d+"T00:00:00Z").toLocaleDateString("en",{month:"short",day:"numeric",year:"numeric",timeZone:"UTC"})}catch(e){return d}};

async function apDados(k,a){
  let albuns=[],top=[],rel=[],gen="";
  if(a.ids.dz){
    const [alb,tp,rl]=await Promise.all([
      dz(`/artist/${a.ids.dz}/albums?limit=100`).catch(()=>({data:[]})),
      dz(`/artist/${a.ids.dz}/top?limit=10`).catch(()=>({data:[]})),
      dz(`/artist/${a.ids.dz}/related?limit=14`).catch(()=>({data:[]}))
    ]);
    const mapa=new Map();
    (alb.data||[]).forEach(x=>{
      const key=albumKey(x.title,a.n);
      const u={key,t:x.title,a:a.n,y:(x.release_date||"").slice(0,4),d:x.release_date||"",tipo:x.record_type,cover:x.cover_xl||x.cover_big||"",ids:{dz:x.id},fontes:["dz"]};
      const o=mapa.get(key);
      if(!o||(u.d&&o.d&&u.d<o.d))mapa.set(key,u);
    });
    albuns=[...mapa.values()];
    top=(tp.data||[]).map(t=>({t:t.title,al:albumKey(t.album.title,t.artist.name),ms:t.duration*1000,alb:t.album.title}));
    (tp.data||[]).forEach(t=>{const kk=albumKey(t.album.title,t.artist.name);if(!S.meta[kk])guardarAlbum({key:kk,t:t.album.title,a:t.artist.name,y:"",tipo:"album",cover:t.album.cover_xl||t.album.cover_big||"",ids:{dz:t.album.id},fontes:["dz"]})});
    rel=(rl.data||[]).filter(o=>o&&o.name).map(o=>({key:artistKey(o.name),n:o.name,foto:o.picture_xl||o.picture_big||"",fas:o.nb_fan||0,id:o.id}));
    rel.forEach(o=>{if(!S.artists[o.key])guardarArtista({key:o.key,n:o.n,foto:o.foto,fas:o.fas,ids:{dz:o.id},fontes:["dz"]})});
    const ult=[...albuns].sort((x,y)=>(y.d||y.y||"").localeCompare(x.d||x.y||""))[0];
    if(ult){try{const d=await dz(`/album/${ult.ids.dz}`);gen=((d.genres||{}).data||[]).map(g=>g.name).join(", ")}catch(e){}}
  }else if(a.ids.sp){
    try{const j=await spGet(`/v1/artists/${a.ids.sp}/albums?include_groups=album,single&limit=50`);
      albuns=unirAlbuns((j.items||[]).map(x=>({src:"sp",id:x.id,t:x.name,a:a.n,y:(x.release_date||"").slice(0,4),tipo:spTipo(x),cover:spImg(x),n:x.total_tracks}))).map(u=>({...u,d:u.y}))}catch(e){}
  }else if(a.ids.mb){
    try{const rgs=(await mb(`/release-group?artist=${a.ids.mb}&limit=100`))["release-groups"]||[];
      albuns=unirAlbuns(rgs.map(r=>({src:"mb",id:r.id,t:r.title,a:a.n,y:(r["first-release-date"]||"").slice(0,4),tipo:(r["primary-type"]||"album").toLowerCase(),cover:`${CAA}/release-group/${r.id}/front-500`}))).map(u=>({...u,d:u.y}))}catch(e){}
  }
  albuns.forEach(u=>{const m=S.meta[u.key];if(!m||(!m.cover&&u.cover))guardarAlbum({...u,genre:(m&&m.genre)||""})});
  return {albuns,top,rel,gen};
}

async function artistView(k){
  const a=S.artists[k];
  if(!a)return `<div class="empty">Artist not found.</div>`;
  if(!a.ids.dz||!window.__dzOk||!window.__dzOk.has(k)){
    (window.__dzOk=window.__dzOk||new Set()).add(k);
    try{
      const j=await dz(`/search/artist?q=${encodeURIComponent(a.n)}&limit=10`);
      const hit=(j.data||[]).filter(x=>norm(x.name)===norm(a.n)).sort((x,y)=>(y.nb_fan||0)-(x.nb_fan||0))[0]||null;
      if(hit&&String(hit.id)!==String(a.ids.dz||"")){a.ids.dz=hit.id;a.foto=hit.picture_xl||hit.picture_big||a.foto;a.fas=hit.nb_fan||0;salvar()}
      else if(hit&&!a.foto){a.foto=hit.picture_xl||hit.picture_big||"";a.fas=a.fas||hit.nb_fan||0;salvar()}
    }catch(e){}
  }
  S.seguindo=S.seguindo||[];
  if(a.ids.dz){S.ultimoArtista={id:a.ids.dz,n:a.n};salvar()}
  const C=(window.__apC=window.__apC||{});
  const D=C[k]||(C[k]=await apDados(k,a));
  const [c1]=cores(k);
  const por=(x,y)=>(y.d||y.y||"").localeCompare(x.d||x.y||"");
  const todos=[...D.albuns].sort(por),ult=todos[0];
  const anos=D.albuns.map(u=>+u.y).filter(Boolean),desde=anos.length?Math.min(...anos):0;
  const fi=-2,auto=0,F={n:"Inter",w:900,i:0,ls:"-.04em",sz:.95};
  const foto=a.foto||(todos.find(u=>u.cover)||{}).cover||"";
  const ban=await bannerDe(k,a).catch(()=>"");
  const hero=ban||foto;
  const gs=[...new Set([a.genre,...String(D.gen||"").split(", ")].filter(Boolean))].slice(0,2);
  const meta=[...gs,a.fas?fmtFas(a.fas)+" fans":""].filter(Boolean).join(" · ");
  const seg=S.seguindo.some(s=>s.k===k);
  const tipoDe=u=>(u.tipo||"album").toLowerCase();
  const grupos=[["Albums",u=>tipoDe(u)==="album"],["EPs",u=>tipoDe(u)==="ep"],["Singles",u=>tipoDe(u)==="single"],["Compilations & live",u=>/compil|live/.test(tipoDe(u))]];
  const discosHTML=sv=>{
    const ord=({new:(x,y)=>por(x,y),old:(x,y)=>por(y,x),az:(x,y)=>String(x.t).localeCompare(String(y.t))})[sv]||por;
    return grupos.map(([nome,f])=>{
      const l=todos.filter(f).sort(ord);
      return l.length?`<div class="sec-h"><h2>${nome} <span class="cnt">${l.length}</span></h2></div><div class="carrossel" data-keep>${l.map(u=>cardAlbum({...u,fontes:u.fontes||[],solo:true})).join("")}</div>`:"";
    }).join("");
  };
  window.__apDiscos=discosHTML;
  const sv=window.__apSort||"new";
  const discos=discosHTML(sv);
  const barra=todos.length>1?`<div class="apbar"><span class="mut sm" style="font-weight:700">Sort releases by</span>${xsel("apsort",[["new","Newest first"],["old","Oldest first"],["az","Title A–Z"]],sv)}</div>`:"";
  const late=ult?`<div class="sec-h"><h2>Latest release</h2></div>
    <a class="ap-late" href="#album-${ult.key}">${capaAlbum(ult.key,ult.t,132)}<div class="ap-latei"><span class="pill">${tipoLabel(ult.tipo)}${ult.d?" · "+esc(fmtData(ult.d)):""}</span><div class="t">${esc(ult.t)}</div><div class="s">${esc(a.n)}</div></div><span class="ap-chev">›</span></a>`:"";
  const tops=D.top.length?`<div class="ap-tw"><div class="sec-h"><h2>Top songs</h2></div><div class="ap-top">${D.top.map((t,i)=>{const yy=((D.albuns.find(u=>u.key===t.al)||{}).y)||"";return `<div class="ap-tr"><a class="ap-tl" href="#album-${t.al}">${capaAlbum(t.al,t.alb,44)}<span class="ap-tt"><b>${esc(t.t)}</b><i>${esc(t.alb)}${yy?" · "+yy:""}</i></span></a><button class="ap-more" data-aplay="${i}" aria-label="Preview, video and links" title="Preview, video and links">···</button></div>`}).join("")}</div></div>`:"";
  const sim=D.rel.length?`<div class="sec-h"><h2>Similar artists</h2></div><div class="carrossel sim" data-keep>${D.rel.map(o=>`<a class="ap-sim" href="#artist-${o.key}"><div class="im" style="background-image:url('${o.foto}')">${o.foto?"":esc(ini(o.n))}</div><div class="t">${esc(o.n)}</div></a>`).join("")}</div>`:"";
  const nAlb=todos.filter(grupos[0][1]).length,nSin=todos.filter(u=>/single|ep/.test(tipoDe(u))).length;
  const kp=(n,l)=>`<div class="kpi"><strong>${n}</strong><span>${l}</span></div>`;
  const banBtns=`<label class="btn" style="cursor:pointer">🖼 Change banner<input id="apbanup" type="file" accept="image/*" hidden></label>${(S.banners||{})[k]?`<button class="btn" data-apbanrm="${k}">Restore original banner</button>`:""}`;
  const links=[a.ids.dz?`<a class="btn" href="https://www.deezer.com/artist/${a.ids.dz}" target="_blank" rel="noopener">Deezer ↗</a>`:"",a.ids.sp?`<a class="btn" href="https://open.spotify.com/artist/${a.ids.sp}" target="_blank" rel="noopener">Spotify ↗</a>`:"",`<a class="btn" href="https://music.apple.com/search?term=${encodeURIComponent(a.n)}" target="_blank" rel="noopener">Apple Music ↗</a>`,banBtns].join("");
  const sobre=`<div class="sec-h" id="apabout"><h2>About</h2></div><div class="kpis">${kp(a.fas?fmtFas(a.fas):"—","Fans")}${kp(nAlb,"Albums")}${kp(nSin,"Singles & EPs")}${kp(desde||"—","Active since")}</div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">${links}</div>`;
  setTimeout(()=>{if(document.querySelector(`.ap[data-k="${k}"]`))apBg(D.ac||c1);apTema(k,hero)},0);
  return `<div class="ap" data-k="${k}" data-fi="${fi}" style="--ac:${D.ac||c1};--af:'${F.n}';--aw:${F.w};--ai:${F.i?"italic":"normal"};--als:${F.ls};--asz:${F.sz}">
  <section class="ap-hero${ban?"":" nob"}"${hero?` style="--hero:url('${hero}')"`:""}><div class="ap-img" style="${hero?`background-image:url('${hero}')`:`background:linear-gradient(135deg,${c1},#000)`}"></div><div class="ap-shade"></div>
    <div class="ap-hbody"><span class="atv-tag">Artist</span>
      <h1 class="ap-name${F.up?" up":""}">${esc(a.n)}</h1>
      ${meta?`<div class="ap-meta">${esc(meta)}</div>`:""}
      <div class="ap-btns">
        ${D.top.length?`<button class="gl pri" data-aplay="0">▶ Play</button>`:""}
        <button class="gl ${seg?"on":""}" data-apfollow="${k}">${followInner(seg)}</button>
        <button class="gl ic" data-apshare aria-label="Share" title="Share"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M8 7l4-4 4 4"/><path d="M8 11H6.5A1.5 1.5 0 0 0 5 12.5v7A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5v-7A1.5 1.5 0 0 0 17.5 11H16"/></svg></button>
      </div>
    </div></section>
  <div class="ap-main"><div class="ap-row2">${late}${tops}</div>${barra}<div id="apdiscos">${discos||`<div class="empty" style="margin-top:30px">No releases found.</div>`}</div>${sim}${sobre}</div></div>`;
}
function apBg(c){document.documentElement.style.setProperty("--bg",`color-mix(in srgb,${c} 14%,var(--base))`)}
async function bannerDe(k,a){
  S.banners=S.banners||{};S.bcache=S.bcache||{};
  if(S.banners[k])return S.banners[k];
  const c=S.bcache[k];
  if(c&&(c.u||Date.now()-c.t<6048e5))return c.u;
  let u="";
  try{
    const url=`https://www.theaudiodb.com/api/v1/json/2/search.php?s=${encodeURIComponent(a.n)}`;
    const busca=getJSON(url).catch(()=>PROXY?getJSON(PROXY+"/deezer?u="+encodeURIComponent(url)):Promise.reject(new Error("x")));
    const j=await Promise.race([busca,new Promise((_,r)=>setTimeout(()=>r(new Error("t")),4500))]);
    const ar=(j.artists||[]).find(x=>norm(x.strArtist)===norm(a.n));
    if(ar)u=[ar.strArtistFanart,ar.strArtistFanart2,ar.strArtistFanart3,ar.strArtistFanart4,ar.strArtistWideThumb,ar.strArtistBanner].find(Boolean)||"";
  }catch(e){return ""}
  S.bcache[k]={u,t:Date.now()};salvar();return u;
}
function apBordas(im){
  try{
    const W=48,H=48,N=8,c=document.createElement("canvas");c.width=W;c.height=H;
    const x=c.getContext("2d",{willReadFrequently:true});x.drawImage(im,0,0,W,H);
    const lado=x0=>{const arr=[];for(let i=0;i<N;i++){const y0=Math.floor(i*H/N),h=Math.floor((i+1)*H/N)-y0,d=x.getImageData(x0,y0,2,h).data;let r=0,g=0,b=0;const n=d.length/4;for(let j=0;j<d.length;j+=4){r+=d[j];g+=d[j+1];b+=d[j+2]}arr.push(`rgb(${Math.round(r/n)},${Math.round(g/n)},${Math.round(b/n)})`)}return arr};
    return {L:lado(0),R:lado(W-2)};
  }catch(e){return null}
}
function apEdge(el,E){
  const h=el&&el.querySelector(".ap-hero");if(!h||!E)return;
  const g=a=>`linear-gradient(180deg,${a.join(",")})`;
  h.style.setProperty("--eL",g(E.L));h.style.setProperty("--eR",g(E.R));h.classList.add("edge");
}
async function apTema(k,src){
  const D=(window.__apC||{})[k];if(!D||!src)return;
  const el=()=>document.querySelector(`.ap[data-k="${k}"]`);
  const nob=()=>{const e=el();return !!(e&&e.querySelector(".ap-hero.nob"))};
  if(D.ac&&(D.edge||!nob())){if(D.edge)apEdge(el(),D.edge);return}
  const im=await carregarImg(src);
  if(!im)return;
  if(!D.ac){
    const p=paletaDaImagem(im,k)[0];
    if(p){D.ac=`rgb(${p.join(",")})`;const e=el();if(e){e.style.setProperty("--ac",D.ac);apBg(D.ac)}}
  }
  if(nob()&&!D.edge)D.edge=apBordas(im);
  if(D.edge)apEdge(el(),D.edge);
}
document.addEventListener("click",e=>{
  const t=e.target,ap=t.closest&&t.closest(".ap");
  const pl=t.closest("[data-aplay]");
  if(pl&&ap){
    const k=ap.dataset.k,D=(window.__apC||{})[k],a=S.artists[k],tr=D&&D.top[+pl.dataset.aplay];
    if(tr&&a){const m=S.meta[tr.al]||{};abrirFaixa(tr.t,a.n,tr.alb,coverDe(tr.al)||m.cover||"")}
    return;
  }
  const fo=t.closest("[data-apfollow]");
  if(fo){
    const k=fo.dataset.apfollow;S.seguindo=S.seguindo||[];
    const i=S.seguindo.findIndex(s=>s.k===k);
    if(i>=0){S.seguindo.splice(i,1);flash("Unfollowed")}
    else{const a=S.artists[k]||{};S.seguindo.push({k,n:a.n||"",dz:(a.ids||{}).dz||""});flash("Following")}
    const on=S.seguindo.some(s=>s.k===k);
    fo.innerHTML=followInner(on);fo.classList.toggle("on",on);
    salvar();return;
  }
  if(t.closest("[data-apshare]")&&ap){
    const a=S.artists[ap.dataset.k]||{};
    if(navigator.share)navigator.share({title:a.n,url:location.href}).catch(()=>{});
    else navigator.clipboard?.writeText(location.href).then(()=>flash("Link copied")).catch(()=>flash("Could not copy"));
    return;
  }

});

/* ===== Diário ===== */
function diaryList(){
  const e=Object.entries(S.u).filter(([,v])=>v.d).sort((a,b)=>b[1].d.localeCompare(a[1].d));
  if(!e.length)return `<div class="empty">You haven't marked any album as listened yet.</div>`;
  const MESES=["January","February","March","April","May","June","July","August","September","October","November","December"];
  let atual="",html="";
  e.forEach(([k,v])=>{
    const mk=v.d.slice(0,7);
    if(mk!==atual){
      if(atual)html+=`</div>`;
      atual=mk;const [y,mm]=mk.split("-"),n=e.filter(x=>x[1].d.slice(0,7)===mk).length;
      html+=`<h3 class="sec" style="margin:22px 4px 10px">${MESES[+mm-1]} ${y} · ${n}</h3><div class="mlist">`;
    }
    const m=S.meta[k]||{t:"Album",a:""};
    html+=`<a class="row" href="#album-${k}">${capaAlbum(k,m.t,50)}<div class="grow"><div class="ttl">${esc(m.t)}</div><div class="sm mut" style="font-weight:700">${esc(m.a)} · ${v.d.slice(8,10)}/${v.d.slice(5,7)}</div></div>${v.r?estrelas(v.r):""}</a>`;
  });
  return html+(atual?`</div>`:"");
}

/* ===== Perfil ===== */
function perfilView(){
  const p=P(),fav=p.fav||[];
  const av=Object.entries(S.u).filter(([,v])=>v.r);
  const ouv=Object.values(S.u).filter(v=>v.d).length;
  const curt=Object.values(S.u).filter(v=>v.l).length;
  const media=av.length?av.reduce((s,[,v])=>s+v.r,0)/av.length:0;
  const [c1,c2]=fav[0]?cores(fav[0]):cores(p.handle||"trackly");
  const banner=p.banner?`<div class="pban"><div class="art img" style="background-image:url(${p.banner})"></div></div>`:`<div class="pban"><div class="art" style="background:linear-gradient(135deg,${c1},${c2})"></div></div>`;
  const avatar=p.avatar?`<img src="${p.avatar}" alt="">`:`<div style="width:100%;height:100%;background:linear-gradient(145deg,${c1},${c2});display:grid;place-items:center">${esc(ini(p.nome))}</div>`;
  const stats=[[ouv,"Listened"],[av.length,"Ratings"],[media?media.toFixed(1):"—","Avg"],[curt,"Liked"],[S.listas.length,"Lists"]].map(([n,l])=>`<div><strong>${n}</strong><span>${l}</span></div>`).join("");
  const tabs=[["perfil","Profile"],["avaliacoes","Ratings"],["diario","Diary"],["fila","Queue"],["stats","Stats"],["listas","Lists"]];
  let corpo="";
  if(aba==="perfil"){
    const slot=i=>fav[i]?`<a class="fitem" href="#album-${fav[i]}">${capaAlbum(fav[i],(S.meta[fav[i]]||{}).t,null)}<div class="ttl" style="margin-top:8px">${esc((S.meta[fav[i]]||{}).t||"")}</div></a>`:`<div class="fvazio">Empty</div>`;
    const nPag=Math.max(1,Math.ceil(fav.length/4));
    const slots=`<div class="favpages" id="favpages">${Array.from({length:nPag},(_,pg)=>`<div class="favpage">${[0,1,2,3].map(j=>slot(pg*4+j)).join("")}</div>`).join("")}</div>${nPag>1?`<div class="favdots">${Array.from({length:nPag},(_,n)=>`<button class="${n===0?"on":""}" data-favpg="${n}" aria-label="Group ${n+1}"></button>`).join("")}</div>`:""}`;
    const mus=p.musicas.length?`<div class="mlist">${p.musicas.map((m,i)=>`<div class="row"><span class="num">${String(i+1).padStart(2,"0")}</span><div class="ttl grow">${esc(m)}</div></div>`).join("")}</div>`:`<div class="empty">Add favorite songs in Edit.</div>`;
    const recs=av.slice(-5).reverse();
    const rec=recs.length?`<div class="mlist">${recs.map(([k,v])=>{const m=S.meta[k]||{t:"Album",a:""};return `<a class="row" href="#album-${k}">${capaAlbum(k,m.t,46)}<div class="grow"><div class="ttl">${esc(m.t)}</div><div class="sm mut" style="font-weight:700">${esc(m.a)}</div></div>${estrelas(v.r)}</a>`}).join("")}</div>`:`<div class="empty">No ratings yet.</div>`;
    corpo=`<div class="pgrid"><div><h3 class="sec">Favorite albums${fav.length>4?` <span style="text-transform:none;letter-spacing:0;font-weight:700">· ${fav.length}</span>`:""}</h3>${slots}<h3 class="sec" style="margin-top:34px">Favorite songs</h3>${mus}</div><aside><h3 class="sec">Recent ratings</h3>${rec}</aside></div>`;
  }else if(aba==="avaliacoes"){
    corpo=av.length?`<div class="mlist" style="margin-top:30px">${[...av].reverse().map(([k,v])=>{const m=S.meta[k]||{t:"Album",a:""};return `<a class="row" href="#album-${k}" style="display:block"><div style="display:flex;align-items:center;gap:14px">${capaAlbum(k,m.t,46)}<div class="grow"><div class="ttl">${esc(m.t)}</div><div class="sm mut" style="font-weight:700">${esc(m.a)}</div></div>${estrelas(v.r)}</div>${v.rev?`<div style="font-weight:600;padding:10px 0 0 60px;line-height:1.45">${esc(v.rev)}</div>`:""}</a>`}).join("")}</div>`:`<div class="empty" style="margin-top:30px">You haven't rated any album yet.</div>`;
  }else if(aba==="diario"){
    corpo=`<div style="margin-top:30px">${diaryList()}</div>`;
  }else if(aba==="fila"){
    corpo=filaView();
  }else if(aba==="stats"){
    corpo=statsView();
  }else{
    corpo=`<div class="mlist" style="margin-top:30px">${S.listas.map((l,i)=>`<a class="row" href="#lista-${i}"><div class="grow"><div class="ttl">${esc(l.nome)}</div><div class="sm mut" style="font-weight:700">${l.ids.length} album${l.ids.length===1?"":"s"}</div></div><span class="mut">›</span></a>`).join("")||`<div class="empty" style="border-radius:0">No lists yet.</div>`}<div class="row" style="gap:10px"><input class="field" id="nlNew" placeholder="New list name"><button class="fab" data-lst="nova">Create</button></div></div>`;
  }
  return `${banner}<div class="phead"><div class="pav">${avatar}</div>
    <div class="pinfo"><h1>${esc(p.nome)}</h1><div class="phandle">@${esc(p.handle)}${p.local?" · "+esc(p.local):""}</div>${p.bio?`<p class="pbio">${esc(p.bio)}</p>`:""}</div>
    <div class="pright"><div class="pstats">${stats}</div><button class="shbtn" data-pact="compartilhar" aria-label="Share" title="Share"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M8 7l4-4 4 4"/><path d="M8 11H6.5A1.5 1.5 0 0 0 5 12.5v7A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5v-7A1.5 1.5 0 0 0 17.5 11H16"/></svg></button></div></div>
  <nav class="ptabs">${tabs.map(([k,l])=>`<button class="${aba===k?"on":""}" data-aba="${k}">${l}</button>`).join("")}</nav>${corpo}${extraPerfil()}`;
}
function compartilhar(){
  const p=P();
  const favs=(p.fav||[]).map(k=>(S.meta[k]||{}).t).filter(Boolean).join(", ")||"—";
  const txt=`${p.nome} (@${p.handle}) on Trackly\n\nFavorite albums: ${favs}\nFavorite songs: ${p.musicas.join(", ")||"—"}`;
  if(navigator.share){navigator.share({title:"Trackly",text:txt}).catch(()=>{});return}
  navigator.clipboard?.writeText(txt).then(()=>flash("Profile copied")).catch(()=>flash("Could not copy"));
}

/* ===== Listas ===== */
function listaView(i){
  const l=S.listas[i];
  if(!l)return `<div class="empty">List not found.</div>`;
  const capas=l.ids.slice(0,4);
  const colagem=capas.length?`<div class="collage">${[0,1,2,3].map(n=>{const u=capas[n]?coverDe(capas[n]):"";return `<div${u?` style="background-image:url(${u})"`:""}></div>`}).join("")}</div>`:"";
  const rk=l.rank;
  const itens=!l.ids.length?`<div class="empty">This list is empty. Add albums from each album's page.</div>`
   :rk?`<div class="mlist">${l.ids.map((k,n)=>{const m=S.meta[k]||{t:"Album",a:""};return `<div class="rkrow"><span class="rn">${n+1}</span><a href="#album-${k}">${capaAlbum(k,m.t,48)}<div class="grow"><div class="ttl">${esc(m.t)}</div><div class="sm mut" style="font-weight:700">${esc(m.a)}</div></div></a><button class="mv" data-lst="up" data-i="${i}" data-id="${k}" aria-label="Up">▲</button><button class="mv" data-lst="dn" data-i="${i}" data-id="${k}" aria-label="Down">▼</button><button class="mv" data-lst="rm" data-i="${i}" data-id="${k}" aria-label="Remove">×</button></div>`}).join("")}</div>`
   :`<div class="grid">${l.ids.map(k=>{const m=S.meta[k]||{t:"Album",a:""};return `<div style="position:relative">${cardAlbum({key:k,t:m.t,a:m.a,y:m.y,fontes:m.fontes||[]})}<button data-lst="rm" data-i="${i}" data-id="${k}" aria-label="Remove" style="position:absolute;top:10px;right:10px;z-index:3;width:30px;height:30px;border-radius:50%;background:rgba(0,0,0,.6);font-weight:800">×</button></div>`}).join("")}</div>`;
  return `<div class="lhead">${colagem}<div style="min-width:0"><span class="pill">List${rk?" · Ranking":""}</span><h1 style="margin:10px 0 4px">${esc(l.nome)}</h1><div class="mut sm" style="font-weight:700">${l.ids.length} album${l.ids.length===1?"":"s"}</div></div></div>
  <div style="display:flex;gap:10px;flex-wrap:wrap;margin:14px 0 22px"><input class="field" id="lnome" value="${esc(l.nome)}" style="flex:1;min-width:200px"><button class="btn" data-lst="ren" data-i="${i}">Rename</button><button class="btn ${rk?"on":""}" data-lst="rank" data-i="${i}">${rk?"✓ Ranking":"Ranking"}</button><button class="btn" data-lst="share" data-i="${i}">Share</button><button class="btn" data-lst="del" data-i="${i}" style="color:#B794F6">${listaDel===i?"Confirm delete":"Delete list"}</button></div>
  ${itens}`;
}
function listAct(el){
  const a=el.dataset.lst,i=+el.dataset.i;
  if(a==="rank"){S.listas[i].rank=!S.listas[i].rank;salvar();rota();return}
  if(a==="up"||a==="dn"){const ids=S.listas[i].ids,j=ids.indexOf(el.dataset.id),t2=a==="up"?j-1:j+1;if(j>=0&&t2>=0&&t2<ids.length){[ids[j],ids[t2]]=[ids[t2],ids[j]];salvar();rota()}return}
  if(a==="share"){const l=S.listas[i];const txt=l.nome+"\n\n"+l.ids.map((k,n)=>`${l.rank?(n+1)+". ":"• "}${(S.meta[k]||{}).t||"Album"} — ${(S.meta[k]||{}).a||""}`).join("\n")+"\n\nMade on Trackly";if(navigator.share){navigator.share({title:l.nome,text:txt}).catch(()=>{})}else if(navigator.clipboard){navigator.clipboard.writeText(txt).then(()=>flash("List copied")).catch(()=>flash("Could not copy"))}return}
  if(a==="nova"){const n=($("#nlNew").value||"").trim();if(!n){flash("Name your list");return}S.listas.push({nome:n,ids:[]});salvar();rota();flash("List created");return}
  if(a==="ren"){const n=($("#lnome").value||"").trim();if(n)S.listas[i].nome=n;salvar();rota();flash("List renamed");return}
  if(a==="rm"){S.listas[i].ids=S.listas[i].ids.filter(x=>x!==el.dataset.id);salvar();rota();flash("Removed from list");return}
  if(a==="del"){if(listaDel!==i){listaDel=i;rota();flash("Tap again to delete");return}S.listas.splice(i,1);listaDel=null;salvar();aba="listas";NAV.go("profile");flash("List deleted");return}
}

/* ===== Editor do perfil ===== */
function abrirEditor(){EDIT=JSON.parse(JSON.stringify(P()));EDTAB="perfil";renderEditor()}
function renderEditorAntigo(){
  let el=$("#ed");
  if(!el){el=document.createElement("div");el.id="ed";document.body.appendChild(el)}
  const e=EDIT;
  el.innerHTML=`<div class="ehead"><button class="lk" data-ed="fechar">Cancel</button><h2>Edit profile</h2><button class="sv" data-ed="salvar">Save</button></div>
  <div class="ebody">
    <div class="esec"><h3 class="sec">Foto e banner</h3><div style="display:flex;gap:10px;flex-wrap:wrap">
      <label class="btn" style="cursor:pointer">Escolher foto<input id="edfoto" type="file" accept="image/*" hidden></label>
      <label class="btn" style="cursor:pointer">Escolher banner<input id="edbanner" type="file" accept="image/*" hidden></label>
      <button class="btn" data-ed="foto-rm">Sem foto</button><button class="btn" data-ed="banner-rm">Sem banner</button></div></div>
    <div class="esec"><h3 class="sec">Info</h3>
      <input class="field" data-f="nome" maxlength="40" placeholder="Nome" value="${esc(e.nome)}">
      <input class="field" data-f="handle" maxlength="30" placeholder="Username" value="${esc(e.handle)}">
      <textarea class="field" data-f="bio" maxlength="160" placeholder="Bio">${esc(e.bio)}</textarea>
      <input class="field" data-f="local" maxlength="40" placeholder="Location" value="${esc(e.local)}"></div>
    <div class="esec"><h3 class="sec">Favorite songs · uma por linha, até 10</h3>
      <textarea class="field" data-f="musicasTxt" style="min-height:160px">${esc(e.musicasTxt??e.musicas.join("\n"))}</textarea></div>
    <div class="esec"><h3 class="sec">Favorite albums</h3><p class="mut sm">On any album page, tap ☆ Favorite to pick it (up to 4).</p>
      <div class="favs">${[0,1,2,3].map(i=>e.fav[i]?`<div class="fitem">${capaAlbum(e.fav[i],(S.meta[e.fav[i]]||{}).t,null)}</div>`:`<div class="fvazio">Empty</div>`).join("")}</div></div>
  </div>`;
  document.body.style.overflow="hidden";
}
function fecharEditor(){const el=$("#ed");if(el)el.remove();EDIT=null;document.body.style.overflow=""}
function lerImg(f,max,quadrado,cb){
  const r=new FileReader();
  r.onload=()=>{const im=new Image();im.onload=()=>{
    const c=document.createElement("canvas");
    if(quadrado){c.width=c.height=max;const s=Math.min(im.width,im.height);c.getContext("2d").drawImage(im,(im.width-s)/2,(im.height-s)/2,s,s,0,0,max,max)}
    else{const k=Math.min(1,max/im.width);c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext("2d").drawImage(im,0,0,c.width,c.height)}
    cb(c.toDataURL("image/jpeg",.85));
  };im.onerror=()=>flash("Could not read that image");im.src=r.result};
  r.readAsDataURL(f);
}


/* ===== Avaliação de músicas ===== */
const tkey=(t,a)=>"t"+hash(norm(t)+"|"+norm(a));
function trateHTML(t,a){const k=tkey(t,a);const r=(S.u[k]||{}).r||0;return `<span class="trate" data-tk="${k}" data-tt="${esc(t)}" data-ta="${esc(a)}" style="display:inline-flex;flex-shrink:0;zoom:.6">${rateHTML(r).replace(/data-v=/g,'data-tv=')}</span>`}

/* ===== Editor do perfil com busca de álbuns e músicas ===== */
let EDQ="",EDQF="albuns",edT=null,edTok=0,EDRES=[],EDTAB="perfil";
function favoritosAlbHTML(){
  const favs=(EDIT&&EDIT.fav)||[];
  return `<div class="gr-tit">Favorite albums <span>${favs.length}/10</span></div><div class="mut sm" style="margin:-6px 2px 0;font-weight:600">On your profile they appear in groups of 4.</div>
    <div class="ed-fav">${Array.from({length:Math.min(10,Math.ceil((favs.length+1)/4)*4)},(_,i)=>i).map(i=>favs[i]?`<div class="ed-fitem">${capaAlbum(favs[i],(S.meta[favs[i]]||{}).t,null)}<button data-ed="fav-rm" data-k="${favs[i]}" class="xb" aria-label="Remove">×</button></div>`:`<div class="ed-vazio">+</div>`).join("")}</div>`;
}
function favoritosMusHTML(){
  const e=EDIT||{musicas:[]};
  return `<div class="gr-tit">Favorite songs <span>${e.musicas.length}/10</span></div>
    ${e.musicas.length?`<div class="gr">${e.musicas.map((m,i)=>`<div class="gr-row"><span class="num">${String(i+1).padStart(2,"0")}</span><span class="gr-in" style="flex:1">${esc(m)}</span><button data-ed="mus-rm" data-i="${i}" class="xb" aria-label="Remove">×</button></div>`).join("")}</div>`:`<div class="empty" style="padding:22px">No songs yet. Search below.</div>`}`;
}
/* Depois de marcar/desmarcar um "+" sem redesenhar o editor inteiro, atualiza só os botões
   visíveis na lista de resultados de busca pra refletir o novo estado (✓ ou +) */
function atualizarBotoesBusca(){
  document.querySelectorAll('#edres [data-ed="pick-alb"]').forEach(b=>{b.textContent=EDIT.fav.includes(b.dataset.k)?"✓":"+"});
  document.querySelectorAll('#edres [data-ed="pick-mus"]').forEach(b=>{
    const mm=EDRES[+b.dataset.i];const linha=mm?`${mm.titulo} — ${mm.artista}`:"";
    b.textContent=EDIT.musicas.includes(linha)?"✓":"+";
  });
}
function renderEditor(){
  let el=$("#ed");
  if(!el){el=document.createElement("div");el.id="ed";document.body.appendChild(el)}
  const e=EDIT,favs=e.fav||[];
  const abas=[["perfil","Profile"],["favoritos","Favoritos"]].map(([k,l])=>`<button class="${EDTAB===k?"on":""}" data-edt="${k}">${l}</button>`).join("");
  const previa=`
    <div class="ed-previa">
      <div class="ed-banner" style="${e.banner?`background-image:url(${e.banner})`:"background:linear-gradient(135deg,#2a1b4d,#0b0b0d)"}">
        <label class="ed-chip" style="right:12px;top:12px;cursor:pointer">Change banner<input id="edbanner" type="file" accept="image/*" hidden></label>
        <button class="ed-chip" data-ed="banner-rm" style="right:12px;top:52px">Remove</button>
      </div>
      <div class="ed-avwrap">
        <div class="ed-av">${e.avatar?`<img src="${e.avatar}" alt="">`:`<span>${esc(ini(e.nome))}</span>`}</div>
        <div class="ed-av-acoes">
          <label class="ed-chip" style="cursor:pointer">Change photo<input id="edfoto" type="file" accept="image/*" hidden></label>
          <button class="ed-chip" data-ed="foto-rm">Remove</button>
        </div>
      </div>
      <div class="ed-nome">${esc(e.nome||"Your name")}<span>@${esc(e.handle||"username")}</span></div>
    </div>`;
  const campos=`
    <div class="gr">
      <div class="gr-row"><span class="gr-lbl">Name</span><input class="gr-in" data-f="nome" maxlength="40" value="${esc(e.nome)}" placeholder="Your name"></div>
      <div class="gr-row"><span class="gr-lbl">Username</span><input class="gr-in" data-f="handle" maxlength="30" value="${esc(e.handle)}" placeholder="your.handle"></div>
      <div class="gr-row gr-alto"><span class="gr-lbl">Bio</span><textarea class="gr-in" data-f="bio" maxlength="160" placeholder="Tell us what you listen to">${esc(e.bio)}</textarea></div>
      <div class="gr-row"><span class="gr-lbl">Location</span><input class="gr-in" data-f="local" maxlength="40" value="${esc(e.local)}" placeholder="City, country"></div>
    </div>`;
  const favoritosAlb=`<div id="edfavalb">${favoritosAlbHTML()}</div>`;
  const favoritosMus=`<div id="edfavmus">${favoritosMusHTML()}</div>`;
  const busca=`
    <div class="gr-tit">Add</div>
    <input class="search" id="edq" placeholder="Search for an album or a song" autocomplete="off" value="${esc(EDQ)}" style="font-size:16px;padding:12px 14px 12px 42px">
    <div class="chips" style="padding-top:10px">${[["albuns","Albums"],["musicas","Songs"]].map(([k,l])=>`<button class="chip ${EDQF===k?"on":""}" data-edf="${k}">${l}</button>`).join("")}</div>
    <div id="edres"></div>`;
  el.innerHTML=`
  <div class="ehead"><button class="lk" data-ed="fechar">Cancel</button><h2>Edit profile</h2><button class="sv" data-ed="salvar">Save</button></div>
  <div class="ebody">
    ${previa}
    <div class="edtabs">${abas}</div>
    ${EDTAB==="perfil"?`<div class="gr-tit">Info</div>${campos}`:`${favoritosAlb}${favoritosMus}${busca}`}
  </div>`;
  document.body.style.overflow="hidden";
  if(EDTAB==="favoritos"&&EDQ.trim().length>=2)runEdSearch();
}
async function runEdSearch(){
  const q=EDQ.trim(),res=$("#edres");
  if(!res)return;
  if(q.length<2){res.innerHTML="";return}
  const e=encodeURIComponent(q),tok=++edTok;
  res.innerHTML=`<div class="load">Searching…</div>`;
  if(EDQF==="albuns"){
    const r=await Promise.allSettled([fontes.albunsDZ(e),fontes.albunsIT(e)]);
    if(tok!==edTok)return;
    const itens=r.filter(x=>x.status==="fulfilled").flatMap(x=>x.value);
    const albuns=unirAlbuns(itens).slice(0,20);
    albuns.forEach(guardarAlbum);salvar();
    res.innerHTML=albuns.length?`<div class="mlist">${albuns.map(u=>`<div class="row">${capaAlbum(u.key,u.t,46)}<div class="grow"><div class="ttl">${esc(u.t)}</div><div class="sm mut" style="font-weight:700">${esc(u.a)}${u.y?" · "+u.y:""}</div></div><button class="btn" data-ed="pick-alb" data-k="${u.key}" style="padding:8px 12px;font-size:13px">${EDIT.fav.includes(u.key)?"✓":"+"}</button></div>`).join("")}</div>`:`<div class="empty">Nothing found.</div>`;
  }else{
    const r=await Promise.allSettled([fontes.musicasDZ(e),fontes.musicasIT(e)]);
    if(tok!==edTok)return;
    const itens=r.filter(x=>x.status==="fulfilled").flatMap(x=>x.value);
    const vistos=new Set();
    EDRES=itens.filter(m=>{const c=norm(m.titulo)+"|"+norm(m.artista);if(vistos.has(c))return false;vistos.add(c);return true}).slice(0,25);
    res.innerHTML=EDRES.length?`<div class="mlist">${EDRES.map((m,i)=>`<div class="row"><div class="grow"><div class="ttl">${esc(m.titulo)}</div><div class="sm mut" style="font-weight:700">${esc(m.artista)} · ${esc(m.album.t)}</div></div><button class="btn" data-ed="pick-mus" data-i="${i}" style="padding:8px 12px;font-size:13px">${EDIT.musicas.includes(`${m.titulo} — ${m.artista}`)?"✓":"+"}</button></div>`).join("")}</div>`:`<div class="empty">Nothing found.</div>`;
  }
}

/* ===== Roteamento ===== */
function rota(){
  let h=decodeURIComponent(NAV.hash.slice(1))||"home";if(h[0]==="@")h="profile";else if(h==="profile")NAV.replace("#@"+encodeURIComponent(P().handle));
  document.documentElement.style.removeProperty("--bg");
  document.body.classList.toggle("perfil",h==="profile");
  document.querySelectorAll(".nav a").forEach(t=>t.classList.toggle("on",t.dataset.tab===(h.startsWith("album")||h.startsWith("artist")?"search":(h.startsWith("lista")?"profile":h))));
  const app=$("#app");
  const tok=++rotaTok;
  if(!h.startsWith("album-")&&!h.startsWith("artist-"))resetAmb();
  const carrega=p=>{app.innerHTML=`<div class="load">Loading…</div>`;p.then(html=>{if(tok===rotaTok)app.innerHTML=html}).catch(()=>{if(tok===rotaTok)app.innerHTML=erroHTML()})};
  if(h.startsWith("album-")){carrega(albumView(h.slice(6)));return}
  if(h.startsWith("artist-")){carrega(artistRoute(h.slice(7)));return}
  if(h==="search"){app.innerHTML=searchView();runSearch();return}
  if(h==="diary"){app.innerHTML=`<h1>Diary</h1>${diaryList()}`;return}
  if(h==="feed"){app.innerHTML=feedHTML();return}
  if(h==="profile"){app.innerHTML=perfilView();return}
  if(h.startsWith("lista-")){app.innerHTML=listaView(+h.slice(6));return}
  carrega(homeView());
}
window.addEventListener("navchange",rota);

/* ===== Menu select customizado ===== */
function xsel(id,opts,cur){
  const o=opts.find(x=>x[0]===cur)||opts[0];
  return `<div class="xsel" id="${id}" data-v="${esc(o[0])}"><button type="button" class="xs-btn" aria-haspopup="listbox"><span class="xs-l">${esc(o[1])}</span><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></button><div class="xs-menu" role="listbox">${opts.map(([v,l])=>`<button type="button" class="xs-o${v===o[0]?" on":""}" role="option" data-xv="${esc(v)}">${esc(l)}</button>`).join("")}</div></div>`;
}
document.addEventListener("click",e=>{
  const t=e.target,b=t.closest&&t.closest(".xs-btn"),op=t.closest&&t.closest(".xs-o"),br=t.closest&&t.closest("[data-apbanrm]");
  document.querySelectorAll(".xsel.open").forEach(x=>{if(!b||x!==b.parentNode)x.classList.remove("open")});
  if(t.closest&&t.closest("[data-apabout]")){const el=document.getElementById("apabout");if(el)el.scrollIntoView({behavior:"smooth",block:"start"});return}
  if(br){const k=br.dataset.apbanrm;if(S.banners)delete S.banners[k];salvar();rota();flash("Original banner restored");return}
  if(b){const x=b.parentNode,abre=x.classList.toggle("open");if(abre){const r=b.getBoundingClientRect(),baixo=innerHeight-r.bottom;x.classList.toggle("up",baixo<280&&r.top>baixo)}return}
  if(op){const x=op.closest(".xsel");x.dataset.v=op.dataset.xv;x.querySelector(".xs-l").textContent=op.textContent;x.querySelectorAll(".xs-o").forEach(y=>y.classList.toggle("on",y===op));x.classList.remove("open");x.dispatchEvent(new CustomEvent("xselchange",{bubbles:true,detail:op.dataset.xv}))}
});
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.querySelectorAll(".xsel.open").forEach(x=>x.classList.remove("open"))});
document.addEventListener("xselchange",e=>{
  const x=e.target,v=e.detail;
  if(x.id==="apsort"){window.__apSort=v;const el=document.getElementById("apdiscos");if(el&&window.__apDiscos){el.innerHTML=window.__apDiscos(v);if(window.melhorarCarrosseis)melhorarCarrosseis()}}
  if(x.id==="tsort"){
    const l=document.getElementById("tlist");if(!l)return;
    const none=document.getElementById("tnone"),rows=[...l.querySelectorAll(".row")];
    const f=({n:(a,b)=>a.dataset.i-b.dataset.i,az:(a,b)=>a.dataset.tn.localeCompare(b.dataset.tn),za:(a,b)=>b.dataset.tn.localeCompare(a.dataset.tn),long:(a,b)=>b.dataset.ms-a.dataset.ms,short:(a,b)=>a.dataset.ms-b.dataset.ms})[v];
    if(f)rows.sort(f).forEach(r=>l.insertBefore(r,none));
  }
});

/* ===== Eventos ===== */
document.addEventListener("input",e=>{
  if(e.target&&e.target.id==="tsearch"){
    const q=e.target.value.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();
    const rows=document.querySelectorAll("#tlist .row");let n=0;
    rows.forEach(r=>{const ok=!q||(r.dataset.tn||"").includes(q);r.style.display=ok?"":"none";if(ok)n++});
    const none=document.getElementById("tnone");if(none)none.style.display=n?"none":"block";
    return;
  }
  const t=e.target;
  if(t.id==="q"){busca.q=t.value;clearTimeout(hqT);hqT=setTimeout(runSearch,300);return}
  if(t.id==="edq"){EDQ=t.value;clearTimeout(edT);edT=setTimeout(runEdSearch,300);return}
  if(t.dataset&&t.dataset.f&&EDIT)EDIT[t.dataset.f]=t.value;
});
document.addEventListener("keydown",e=>{
  if(e.target.id==="hq"&&e.key==="Enter"){busca.q=e.target.value;NAV.go("search")}
});
document.addEventListener("focusin",e=>{
  const t=e.target;
  if((t.tagName==="INPUT"||t.tagName==="TEXTAREA")&&t.closest("#ed")){
    setTimeout(()=>{try{t.scrollIntoView({block:"center",behavior:"smooth"})}catch(err){}},300);
  }
});
document.addEventListener("change",e=>{
  const t=e.target;
  if(t.id==="ddate"){const kk=NAV.hash.slice(7);if(t.value&&S.u[kk]){S.u[kk].d=t.value;salvar();flash("Date updated")}return}
  if(t.id==="impf"){importar(t.files[0]);t.value="";return}
  /* Trocar a capa de um álbum, EP ou single */
  if(t.id==="apbanup"&&t.files&&t.files[0]){
    const ap=document.querySelector(".ap"),k=ap&&ap.dataset.k;
    if(!k)return;
    lerImg(t.files[0],1280,false,u=>{S.banners=S.banners||{};S.banners[k]=u;salvar();rota();flash("Banner changed")});
    return;
  }
  if(t.id==="capaup"&&t.files&&t.files[0]){
    const k=NAV.hash.slice(7);
    if(!S.meta[k])return;
    lerImg(t.files[0],700,true,u=>{S.covers[k]=u;salvar();rota();flash("Cover changed")});
    return;
  }
  if(!t.files||!t.files[0]||!EDIT)return;
  if(t.id==="edfoto")lerImg(t.files[0],256,true,u=>{EDIT.avatar=u;renderEditor()});
  if(t.id==="edbanner")lerImg(t.files[0],1400,false,u=>{EDIT.banner=u;renderEditor()});
});
document.addEventListener("click",e=>{
  const t=e.target;
  const tv=t.closest("[data-tv]");
  if(tv){e.preventDefault();const box=tv.closest(".trate");const k=box.dataset.tk;const d=dd(k);const val=+tv.dataset.tv;d.r=d.r===val?0:val;if(!d.r)delete d.r;S.tracks=S.tracks||{};S.tracks[k]=Object.assign(S.tracks[k]||{},{t:box.dataset.tt,a:box.dataset.ta});if(d.r)S.tracks[k].p=hojeLocal();salvar();box.innerHTML=rateHTML(d.r).replace(/data-v=/g,'data-tv=');flash(d.r?`Rating ${String(val)} for the song`:"Rating removed");tic();atualizarMedia();return}
  const sg=t.closest("[data-seguir]");
  if(sg){
    const k=sg.dataset.seguir;S.seguindo=S.seguindo||[];
    const i=S.seguindo.findIndex(s=>s.k===k);
    if(i>=0){S.seguindo.splice(i,1);flash("Unfollowed")}
    else{const a=S.artists[k]||{};S.seguindo.push({k,n:a.n||"",dz:(a.ids||{}).dz||""});flash("Following")}
    salvar();rota();return;
  }
  const hg=t.closest("[data-hg]");
  if(hg){homeGenero=+hg.dataset.hg;rota();return}
  const edt=t.closest("[data-edt]");
  if(edt){EDTAB=edt.dataset.edt;renderEditor();return}
  const edf=t.closest("[data-edf]");
  if(edf){EDQF=edf.dataset.edf;renderEditor();return}
  const ed=t.closest("[data-ed]");
  if(ed&&EDIT){
    const a=ed.dataset.ed;
    if(a==="fechar"){fecharEditor();return}
    if(a==="foto-rm"){EDIT.avatar="";renderEditor();return}
    if(a==="banner-rm"){EDIT.banner="";renderEditor();return}
    if(a==="pick-alb"){
      const k=ed.dataset.k;
      if(EDIT.fav.includes(k)){EDIT.fav=EDIT.fav.filter(x=>x!==k)}
      else if(EDIT.fav.length<10)EDIT.fav.push(k);
      else{flash("Up to 10 favorite albums");return}
      const box=$("#edfavalb");if(box)box.innerHTML=favoritosAlbHTML();
      atualizarBotoesBusca();
      return;
    }
    if(a==="fav-rm"){
      EDIT.fav=EDIT.fav.filter(x=>x!==ed.dataset.k);
      const box=$("#edfavalb");if(box)box.innerHTML=favoritosAlbHTML();
      atualizarBotoesBusca();
      return;
    }
    if(a==="pick-mus"){
      const m=EDRES[+ed.dataset.i];const linha=`${m.titulo} — ${m.artista}`;
      if(EDIT.musicas.includes(linha)){EDIT.musicas=EDIT.musicas.filter(x=>x!==linha)}
      else if(EDIT.musicas.length<10)EDIT.musicas.push(linha);
      else{flash("Up to 10 songs");return}
      const box=$("#edfavmus");if(box)box.innerHTML=favoritosMusHTML();
      atualizarBotoesBusca();
      return;
    }
    if(a==="mus-rm"){
      EDIT.musicas.splice(+ed.dataset.i,1);
      const box=$("#edfavmus");if(box)box.innerHTML=favoritosMusHTML();
      atualizarBotoesBusca();
      return;
    }
    if(a==="salvar"){
      const {musicasTxt,...r}=EDIT;
      const txt=musicasTxt??r.musicas.join("\n");
      S.perfil={...r,musicas:txt.split("\n").map(s=>s.trim()).filter(Boolean).slice(0,10)};
      salvar();fecharEditor();rota();flash("Profile saved");
    }
    return;
  }
  const pa=t.closest("[data-pact]");
  if(pa){if(pa.dataset.pact==="editar")abrirEditor();if(pa.dataset.pact==="compartilhar")compartilhar();return}
  const ab=t.closest("[data-aba]");
  if(ab){aba=ab.dataset.aba;rota();return}
  const fl=t.closest("[data-fl]");
  if(fl){busca.f=fl.dataset.fl;document.querySelectorAll("[data-fl]").forEach(c=>c.classList.toggle("on",c===fl));runSearch();return}
  const v=t.closest("#rate [data-v], #rate2 [data-v]");
  if(v){
    const k=$("#rate").dataset.id;const d=dd(k);const val=+v.dataset.v;
    d.r=d.r===val?0:val;if(!d.r)delete d.r;
    salvar();
    tic();$("#rate").innerHTML=rateHTML(d.r);const r2=$("#rate2");if(r2)r2.innerHTML=rateHTML(d.r);
    $("#rlab").textContent=d.r?String(d.r)+" of 5":"Your rating";
    flash(d.r?`Rating ${String(val)} saved`:"Rating removed");
    return;
  }
  const act=t.closest("[data-act]");
  if(act){albumAct(act.dataset.act);return}
  const l=t.closest("[data-lst]");
  if(l){listAct(l);return}
});
window.addEventListener("DOMContentLoaded",()=>rota());

;/* ---------- bloco 02 ---------- */
function extraPerfil(){
  const av=Object.entries(S.u).filter(([k,v])=>v.r&&S.meta[k]);
  const dist=[.5,1,1.5,2,2.5,3,3.5,4,4.5,5].map(n=>{const c=av.filter(([,v])=>v.r===n).length;return `<div class="hrow"><span>${String(n)}</span><div class="hbar"><i style="width:${av.length?c/av.length*100:0}%"></i></div><span class="mut">${c}</span></div>`}).join("");
  const cont={};av.forEach(([k])=>{const a=S.meta[k].a;cont[a]=(cont[a]||0)+1});
  const topA=Object.entries(cont).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const faixas=Object.entries(S.tracks||{}).filter(([k])=>S.u[k]?.r).sort((a,b)=>S.u[b[0]].r-S.u[a[0]].r).slice(0,8);
  return `<h2>Following</h2>${(S.seguindo||[]).length?`<div class="mlist">${(S.seguindo||[]).map(s=>`<a class="row" href="#artist-${s.k}">${capaFoto("",s.n,44,true)}<div class="grow"><div class="ttl">${esc(s.n)}</div></div><span class="mut">›</span></a>`).join("")}</div>`:`<div class="empty">Follow artists to see their releases on the home page.</div>`}
  <h2>Top artists</h2>${topA.length?`<div class="mlist">${topA.map(([n,c],i)=>`<a class="row" href="#artist-${artistKey(n)}"><span class="num">${i+1}</span><div class="grow"><div class="ttl">${esc(n)}</div><div class="sm mut" style="font-weight:700">${c} album${c>1?"s":""}  rated</div></div><span class="mut">›</span></a>`).join("")}</div>`:`<div class="empty">Rate albums to see your favorite artists.</div>`}
  <h2>Rating distribution</h2><div class="hist2">${dist}</div>
  <h2>Rated songs</h2>${faixas.length?`<div class="mlist">${faixas.map(([k,v])=>`<div class="row"><div class="grow"><div class="ttl">${esc(v.t)}</div><div class="sm mut" style="font-weight:700">${esc(v.a)}</div></div>${estrelas(S.u[k].r)}</div>`).join("")}</div>`:`<div class="empty">Rate tracks on an album page.</div>`}
  <h2>Share</h2><button class="btn p" data-pact="cartao">Share to Story</button>${aba==="perfil"?backupHTML():""}`;
}
function rr(g,x,y,w,h,r){g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath()}
function gerarCartao(){
  const p=P(),fav=p.fav||[];
  const c=document.createElement("canvas");c.width=1080;c.height=1350;
  const g=c.getContext("2d");
  const [c1,c2]=fav[0]?cores(fav[0]):cores(p.handle||"trackly");
  const fundo=g.createLinearGradient(0,0,0,1350);fundo.addColorStop(0,c1);fundo.addColorStop(.55,c2);fundo.addColorStop(1,"#000");
  g.fillStyle=fundo;g.fillRect(0,0,1080,1350);
  g.fillStyle="#fff";g.font="900 104px Inter, Helvetica, Arial, sans-serif";g.fillText(p.nome.slice(0,16),80,260);
  g.font="700 44px Inter, Helvetica, Arial, sans-serif";g.fillStyle="rgba(255,255,255,.8)";g.fillText("@"+p.handle,84,330);
  const ouv=Object.values(S.u).filter(v=>v.d).length;
  const av=Object.values(S.u).filter(v=>v.r);
  const media=av.length?(av.reduce((s,v)=>s+v.r,0)/av.length).toFixed(1):"—";
  g.font="600 38px Inter, Helvetica, Arial, sans-serif";g.fillText(`${ouv} listened · ${av.length} ratings · avg ${media}`,84,410);
  fav.slice(0,4).forEach((k,i)=>{
    const x=80+i*236,y=500,[a,b]=cores(k);
    const t=g.createLinearGradient(x,y,x+200,y+200);t.addColorStop(0,a);t.addColorStop(1,b);
    g.fillStyle=t;rr(g,x,y,200,200,26);g.fill();
    g.fillStyle="#fff";g.font="800 26px Inter, Helvetica, Arial, sans-serif";
    const nome=(S.meta[k]||{}).t||"";
    g.fillText(nome.slice(0,14),x,y+240);
  });
  g.font="800 40px Inter, Helvetica, Arial, sans-serif";g.fillStyle="#fff";g.fillText("Favorite songs",84,880);
  g.font="600 36px Inter, Helvetica, Arial, sans-serif";
  (p.musicas||[]).slice(0,5).forEach((m,i)=>{g.fillStyle="rgba(255,255,255,.9)";g.fillText(`${i+1}. ${m.slice(0,40)}`,84,950+i*62)});
  g.font="900 46px Inter, Helvetica, Arial, sans-serif";g.fillStyle="#fff";g.fillText("Trackly.",84,1250);
  c.toBlob(blob=>{
    const file=new File([blob],"trackly-perfil.png",{type:"image/png"});
    if(navigator.canShare&&navigator.canShare({files:[file]})){navigator.share({files:[file],title:"Trackly"}).catch(()=>{});return}
    const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="trackly-perfil.png";document.body.appendChild(a);a.click();a.remove();
    flash("Image generated");
  },"image/png");
}
document.addEventListener("click",e=>{
  if(e.target.closest("[data-pact='cartao']")){gerarStoryPerfil();return}
  if(e.target.closest("[data-rnd]")){
    const lista=window.__chart||[];
    if(!lista.length){flash("Trends haven't loaded yet");return}
    const x=lista[Math.floor(Math.random()*lista.length)];
    NAV.go("album-"+albumKey(x.title,x.artist?.name||""));
  }
});

;/* ---------- bloco 03 ---------- */
window.addEventListener("scroll",()=>document.querySelector("header").classList.toggle("rolou",window.scrollY>12),{passive:true});

;/* ---------- bloco 04 ---------- */
function melhorarCarrosseis(){
  document.querySelectorAll('.carrossel:not([data-m])').forEach(c=>{
    c.dataset.m='1';
    if(!c.hasAttribute('data-keep')&&c.children.length>2&&c.children.length%2)c.lastElementChild.remove();
    const w=document.createElement('div');w.className='carw';
    c.parentNode.insertBefore(w,c);w.appendChild(c);
    const bot=(d)=>{const b=document.createElement('button');b.className='carbtn '+(d<0?'l':'r');b.innerHTML=d<0?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>':'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>';b.setAttribute('aria-label',d<0?'Previous':'Next');b.onclick=()=>c.scrollBy({left:d*c.clientWidth*.8,behavior:'smooth'});return b};
    w.append(bot(-1),bot(1));
  });
}
new MutationObserver(melhorarCarrosseis).observe(document.getElementById('app'),{childList:true,subtree:true});
melhorarCarrosseis();
(function(){
  const nav=document.querySelector('.nav');
  if(!nav)return;
  const box=document.createElement('div');box.className='hsearch';
  box.innerHTML='<input id="hq2" type="search" placeholder="Search artists, albums, songs" autocomplete="off" aria-label="Buscar">';
  nav.before(box);
  let t=null;
  box.querySelector('input').addEventListener('input',e=>{
    busca.q=e.target.value;
    const qi=document.getElementById('q');if(qi)qi.value=e.target.value;
    clearTimeout(t);
    t=setTimeout(()=>{
      if(NAV.hash!=='#search'){NAV.go('search')}
      else{runSearch()}
    },350);
  });
  box.querySelector('input').addEventListener('keydown',e=>{if(e.key==='Enter'){busca.q=e.target.value;NAV.go('search');if(NAV.hash==='#search')runSearch()}});
})();

;/* ---------- bloco 05 ---------- */
/* ===== Stories: imagens 1080x1920 com cores extraídas da própria capa ===== */
function quebrarLinhas(g,texto,maxW){
  const palavras=String(texto||"").split(/\s+/).filter(Boolean);const out=[];let l="";
  for(const p of palavras){const t=l?l+" "+p:p;if(g.measureText(t).width>maxW&&l){out.push(l);l=p}else l=t}
  if(l)out.push(l);return out;
}
function rrect(g,x,y,w,h,r){g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath()}
function texto(g,t,x,y,font,cor,align){g.font=font;g.fillStyle=cor;g.textAlign=align||"center";g.fillText(t,x,y)}
const FNT="Inter, Helvetica, Arial, sans-serif";

/* Carregamento com CORS (necessário para exportar o canvas e ler os pixels) */
function tentarImg(src,cors){return new Promise(res=>{const im=new Image();if(cors)im.crossOrigin="anonymous";im.onload=()=>res(im);im.onerror=()=>res(null);im.src=src})}
async function carregarImg(src){
  if(!src)return null;
  if(src.startsWith("data:"))return tentarImg(src,false);
  const bust=src+(src.includes("?")?"&":"?")+"cb="+Date.now();
  return (await tentarImg(src,true))
      || (await tentarImg(bust,true))
      || (PROXY?await tentarImg(`${PROXY}/img?u=${encodeURIComponent(src)}`,true):null);
}
function desenharCapa(g,im,x,y,w,h,r){
  g.save();rrect(g,x,y,w,h,r);g.clip();
  const s=Math.max(w/im.width,h/im.height),dw=im.width*s,dh=im.height*s;
  g.drawImage(im,x+(w-dw)/2,y+(h-dh)/2,dw,dh);
  g.restore();
}

/* ---- Paleta a partir da imagem ---- */
function hsl2rgb(h,s,l){h=((h%360)+360)%360;const a=s*Math.min(l,1-l),f=n=>{const k=(n+h/30)%12;return Math.round(255*(l-a*Math.max(-1,Math.min(k-3,9-k,1))))};return [f(0),f(8),f(4)]}
function paletaFallback(seed){let h=0;for(const ch of String(seed))h=(h*31+ch.charCodeAt(0))%360;return [hsl2rgb(h,.7,.5),hsl2rgb(h+50,.65,.25),hsl2rgb(h+120,.6,.4)]}
function paletaDaImagem(im,seed){
  if(!im)return paletaFallback(seed);
  try{
    const n=40,c=document.createElement("canvas");c.width=c.height=n;
    const x=c.getContext("2d",{willReadFrequently:true});
    x.drawImage(im,0,0,n,n);
    const d=x.getImageData(0,0,n,n).data,mapa=new Map();
    for(let i=0;i<d.length;i+=4){
      const r=d[i],g=d[i+1],b=d[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b),lum=(r+g+b)/3;
      if(lum<25||lum>235)continue;
      const key=(r>>5)+","+(g>>5)+","+(b>>5),o=mapa.get(key)||{n:0,r:0,g:0,b:0,s:0};
      o.n++;o.r+=r;o.g+=g;o.b+=b;o.s+=mx?(mx-mn)/mx:0;mapa.set(key,o);
    }
    const arr=[...mapa.values()].map(o=>({r:o.r/o.n,g:o.g/o.n,b:o.b/o.n,score:o.n*(.4+o.s/o.n)})).sort((a,b)=>b.score-a.score);
    if(!arr.length)return paletaFallback(seed);
    const dist=(a,b)=>Math.hypot(a.r-b.r,a.g-b.g,a.b-b.b),pick=[arr[0]];
    for(const o of arr){if(pick.length>=3)break;if(pick.every(p=>dist(p,o)>70))pick.push(o)}
    while(pick.length<3){const b=pick[0];pick.push({r:b.r*.6,g:b.g*.6,b:b.b*.6})}
    return pick.map(o=>[Math.round(o.r),Math.round(o.g),Math.round(o.b)]);
  }catch(e){return paletaFallback(seed)}
}
const rgba=(c,a=1)=>`rgba(${c[0]},${c[1]},${c[2]},${a})`;
const escurece=(c,k)=>c.map(v=>Math.round(v*(1-k)));

/* ---- Variações de fundo ---- */
const VARIACOES=["Gradient","Radial","Blurred","Vibrant","Dark","Light","Solid"];
function fundoStory(g,W,H,pal,im,v){
  const [p1,p2,p3]=pal;
  if(v===2&&!im)v=0;
  if(v===0){
    const f=g.createLinearGradient(0,0,0,H);f.addColorStop(0,rgba(escurece(p1,.1)));f.addColorStop(.55,rgba(escurece(p2,.5)));f.addColorStop(1,"#000");
    g.fillStyle=f;g.fillRect(0,0,W,H);
  }else if(v===1){
    g.fillStyle=rgba(escurece(p2,.7));g.fillRect(0,0,W,H);
    let r=g.createRadialGradient(W/2,H*.3,0,W/2,H*.3,W*1.1);r.addColorStop(0,rgba(p1,.95));r.addColorStop(1,rgba(p1,0));
    g.fillStyle=r;g.fillRect(0,0,W,H);
    r=g.createRadialGradient(W*.15,H*.92,0,W*.15,H*.92,W*.9);r.addColorStop(0,rgba(p3,.55));r.addColorStop(1,rgba(p3,0));
    g.fillStyle=r;g.fillRect(0,0,W,H);
  }else if(v===2){
    const t=document.createElement("canvas");t.width=18;t.height=32;const tg=t.getContext("2d");
    const s=Math.max(18/im.width,32/im.height);tg.drawImage(im,(18-im.width*s)/2,(32-im.height*s)/2,im.width*s,im.height*s);
    const t2=document.createElement("canvas");t2.width=108;t2.height=192;const t2g=t2.getContext("2d");
    t2g.imageSmoothingEnabled=true;t2g.imageSmoothingQuality="high";t2g.drawImage(t,0,0,108,192);
    g.imageSmoothingEnabled=true;g.imageSmoothingQuality="high";g.drawImage(t2,0,0,W,H);
    g.fillStyle="rgba(0,0,0,.28)";g.fillRect(0,0,W,H);
  }else if(v===3){
    const f=g.createLinearGradient(0,0,W,H);f.addColorStop(0,rgba(p1));f.addColorStop(.5,rgba(p3));f.addColorStop(1,rgba(escurece(p2,.4)));
    g.fillStyle=f;g.fillRect(0,0,W,H);
  }else if(v===5){
    const mix=(c,k)=>c.map(x=>Math.round(x+(255-x)*k));
    const f=g.createLinearGradient(0,0,0,H);f.addColorStop(0,rgba(mix(p1,.82)));f.addColorStop(1,rgba(mix(p2,.62)));
    g.fillStyle=f;g.fillRect(0,0,W,H);return;
  }else if(v===6){
    const f=g.createLinearGradient(0,0,W*.4,H);f.addColorStop(0,rgba(escurece(p1,.12)));f.addColorStop(1,rgba(escurece(p1,.38)));
    g.fillStyle=f;g.fillRect(0,0,W,H);return;
  }else{
    const f=g.createLinearGradient(0,0,0,H);f.addColorStop(0,rgba(escurece(p1,.72)));f.addColorStop(1,"#000");
    g.fillStyle=f;g.fillRect(0,0,W,H);
    const r=g.createRadialGradient(W/2,H*.3,0,W/2,H*.3,W*.9);r.addColorStop(0,rgba(p1,.5));r.addColorStop(1,rgba(p1,0));
    g.fillStyle=r;g.fillRect(0,0,W,H);
  }
  const b=g.createLinearGradient(0,H*.55,0,H);b.addColorStop(0,"rgba(0,0,0,0)");b.addColorStop(1,"rgba(0,0,0,.5)");
  g.fillStyle=b;g.fillRect(0,H*.55,W,H*.45);
}
function desenharEstrelas(g,cx,y,r,size,cor,vazio){
  cor=cor||"#fff";vazio=vazio||"rgba(255,255,255,.25)";
  const gap=size*1.2,x0=cx-gap*2;
  g.font=`900 ${size}px ${FNT}`;g.textAlign="center";
  for(let i=0;i<5;i++){
    const x=x0+i*gap;
    g.fillStyle=vazio;g.fillText("★",x,y);
    const f=r>=i+1?1:r>=i+.5?.5:0;
    if(f){g.save();g.beginPath();g.rect(x-size,y-size*1.1,f===1?size*2:size,size*1.5);g.clip();g.fillStyle=cor;g.fillText("★",x,y);g.restore()}
  }
}

/* ---- Desenho: resenha (centralizado; fundo e estrelas opcionais) ---- */
function desenharResenha(c,k,A,v,o){
  const m=S.meta[k],d=S.u[k]||{},W=1080,pal=paletaDaImagem(A.capa,k);
  const tam=620;
  const tit=A.musica?A.musica.t:m.t,nota=A.musica?((S.u[tkey(A.musica.t,m.a)]||{}).r||0):(d.r||0);
  const I={m,tit,nota,pal,A,ms:A.musica&&A.musica.ms};
  if(o.mode==="let")return desenharLetra(c,I,v,o);
  if(o.lay===0)return desenharFade(c,I,v,o);
  if(o.lay===1)return desenharPoster(c,I,v,o);
  if(o.lay===2)return desenharVinil(c,I,v,o);
  if(o.lay===3)return desenharPolaroid(c,I,v,o);
  const gm=c.getContext("2d");
  let fs=64;gm.font=`900 ${fs}px ${FNT}`;
  let ls=quebrarLinhas(gm,tit,860);
  if(ls.length>2){fs=52;gm.font=`900 ${fs}px ${FNT}`;ls=quebrarLinhas(gm,tit,860)}
  ls=ls.slice(0,2);
  const lh=fs*1.15,estrelas=!!(o.estrelas&&nota);
  let h=tam+56+ls.length*lh+46+(estrelas?104:0)+94;
  const pad=o.fundo?0:50,H=o.fundo?1920:Math.round(h+pad*2);
  c.width=W;c.height=H;
  const g=c.getContext("2d");
  if(o.fundo)fundoStory(g,W,H,pal,A.capa,v);
  const x=(W-tam)/2;let y=o.fundo?(H-h)/2:pad;
  if(A.capa){
    if(o.fundo){g.save();g.shadowColor="rgba(0,0,0,.55)";g.shadowBlur=60;g.shadowOffsetY=24;rrect(g,x,y,tam,tam,36);g.fillStyle="#000";g.fill();g.restore()}
    desenharCapa(g,A.capa,x,y,tam,tam,36);
  }else{
    const t=g.createLinearGradient(x,y,x+tam,y+tam);t.addColorStop(0,rgba(pal[0]));t.addColorStop(1,rgba(escurece(pal[1],.2)));
    g.fillStyle=t;rrect(g,x,y,tam,tam,36);g.fill();
    texto(g,ini(m.t),W/2,y+tam/2+60,`900 180px ${FNT}`,"rgba(255,255,255,.92)");
  }
  let cy=y+tam+56;
  ls.forEach(l=>{texto(g,l,W/2,cy+fs*.85,`900 ${fs}px ${FNT}`,"#fff");cy+=lh});
  texto(g,(m.a||"").slice(0,44),W/2,cy+30,`600 38px ${FNT}`,"rgba(255,255,255,.78)");cy+=46;
  if(estrelas){cy+=34;desenharEstrelas(g,W/2,cy+58,nota,70);cy+=70}
  cy+=64;
  siteNome(g,W/2,cy+26,"center");
}

/* ---- Layouts: Fade, Pôster, Vinil, Polaroid, Clássico e Letra ---- */
const LAYOUTS=["Fade","Poster","Vinyl","Polaroid","Classic"];
function cortar(g,t,maxW){t=String(t||"");if(g.measureText(t).width<=maxW)return t;while(t.length>1&&g.measureText(t+"…").width>maxW)t=t.slice(0,-1);return t+"…"}
function desfocar(src,w,h){
  let cur=src;
  for(const f of [32,8,1]){
    const k=document.createElement("canvas");k.width=Math.max(4,Math.round(w/f));k.height=Math.max(4,Math.round(h/f));
    const kg=k.getContext("2d");kg.imageSmoothingEnabled=true;kg.imageSmoothingQuality="high";kg.drawImage(cur,0,0,k.width,k.height);cur=k;
  }
  return cur;
}
function fotoOuGrad(g,I,x,y,w,h,r){
  if(I.A.capa)desenharCapa(g,I.A.capa,x,y,w,h,r);
  else{const f=g.createLinearGradient(x,y,x+w,y+h);f.addColorStop(0,rgba(I.pal[0]));f.addColorStop(1,rgba(escurece(I.pal[1],.2)));g.fillStyle=f;rrect(g,x,y,w,h,r);g.fill();texto(g,ini(I.m.t),x+w/2,y+h/2+Math.min(w,h)*.12,`900 ${Math.round(Math.min(w,h)*.34)}px ${FNT}`,"rgba(255,255,255,.9)")}
}
function medirTitulo(g,t,max,fs,maxL){
  g.font=`900 ${fs}px ${FNT}`;let f=fs,ls=quebrarLinhas(g,t,max);
  if(ls.length>maxL){f=Math.round(fs*.78);g.font=`900 ${f}px ${FNT}`;ls=quebrarLinhas(g,t,max)}
  return {f,ls:ls.slice(0,maxL)};
}
function estrelasAl(g,x,y,r,size,al,cor,vazio){const gap=size*1.2;desenharEstrelas(g,al==="left"?x+size*.45+gap*2:x,y,r,size,cor,vazio)}
function blocoTexto(g,I,x,y,max,fs,al,cor,cor2){
  const mt=medirTitulo(g,I.tit,max,fs,2);let cy=y;
  mt.ls.forEach(l=>{texto(g,l,x,cy+mt.f*.85,`900 ${mt.f}px ${FNT}`,cor,al);cy+=mt.f*1.1});
  const s=Math.round(mt.f*.5);g.font=`600 ${s}px ${FNT}`;
  texto(g,cortar(g,I.m.a||"",max),x,cy+s+4,`600 ${s}px ${FNT}`,cor2,al);
  return cy+s+20;
}
function siteNome(g,x,y,al,cor){if(window.__marca===false)return;g.letterSpacing="8px";texto(g,"TRACKLY",x+(al==="center"?4:0),y,`800 30px ${FNT}`,cor||"rgba(255,255,255,.75)",al);g.letterSpacing="0px"}

/* Fade: foto inteira no topo que vira desfoque e some em degradê com as informações embaixo */
function desenharFade(c,I,v,o){
  const W=1080,{A,nota}=I,est=!!(o.estrelas&&nota);
  const H=o.fundo?1920:1750,PH=1250;
  c.width=W;c.height=H;const g=c.getContext("2d");
  if(o.fundo)fundoStory(g,W,H,I.pal,A.capa,v);
  const sh=document.createElement("canvas");sh.width=W;sh.height=PH;const sg=sh.getContext("2d");
  fotoOuGrad(sg,I,0,0,W,PH,0);
  const bl=desfocar(sh,W,PH),bg=bl.getContext("2d");
  bg.globalCompositeOperation="destination-in";
  const m1=bg.createLinearGradient(0,0,0,PH);m1.addColorStop(0,"rgba(0,0,0,0)");m1.addColorStop(.4,"rgba(0,0,0,0)");m1.addColorStop(.8,"rgba(0,0,0,1)");m1.addColorStop(1,"rgba(0,0,0,1)");
  bg.fillStyle=m1;bg.fillRect(0,0,W,PH);
  sg.drawImage(bl,0,0);
  sg.globalCompositeOperation="destination-in";
  const m2=sg.createLinearGradient(0,0,0,PH);m2.addColorStop(0,"#000");m2.addColorStop(.58,"#000");m2.addColorStop(1,"rgba(0,0,0,0)");
  sg.fillStyle=m2;sg.fillRect(0,0,W,PH);
  g.drawImage(sh,0,0);
  let cy=blocoTexto(g,I,W/2,1190,900,92,"center","#fff","rgba(255,255,255,.78)");
  if(est)desenharEstrelas(g,W/2,cy+52,nota,70);
  siteNome(g,W/2,H-80,"center");
}

/* Pôster: foto em tela cheia, título gigante no rodapé */
function desenharPoster(c,I,v,o){
  const W=1080,{A,nota,m}=I,est=!!(o.estrelas&&nota);
  const H=o.fundo?1920:1500;
  c.width=W;c.height=H;const g=c.getContext("2d");
  if(!o.fundo){rrect(g,0,0,W,H,56);g.clip()}
  fotoOuGrad(g,I,0,0,W,H,0);
  const sc=g.createLinearGradient(0,H*.3,0,H);sc.addColorStop(0,"rgba(0,0,0,0)");sc.addColorStop(.6,"rgba(0,0,0,.55)");sc.addColorStop(1,"rgba(0,0,0,.9)");
  g.fillStyle=sc;g.fillRect(0,H*.3,W,H*.7);
  const tp=g.createLinearGradient(0,0,0,260);tp.addColorStop(0,"rgba(0,0,0,.45)");tp.addColorStop(1,"rgba(0,0,0,0)");
  g.fillStyle=tp;g.fillRect(0,0,W,260);
  siteNome(g,80,120,"left","rgba(255,255,255,.85)");
  const mt=medirTitulo(g,I.tit,920,112,3);
  let yb=H-110;
  if(est){estrelasAl(g,80,yb,nota,70,"left");yb-=110}
  g.font=`600 52px ${FNT}`;texto(g,cortar(g,m.a||"",920),80,yb,`600 52px ${FNT}`,"rgba(255,255,255,.82)","left");yb-=88;
  mt.ls.forEach((l,i)=>texto(g,l,80,yb-(mt.ls.length-1-i)*mt.f*1.04,`900 ${mt.f}px ${FNT}`,"#fff","left"));
}

/* Vinil: capa com o disco saindo por trás */
function desenharVinil(c,I,v,o){
  const W=1080,{A,nota}=I,est=!!(o.estrelas&&nota);
  const tam=640,cxv=70,pad=50;
  const gm=c.getContext("2d");const mt=medirTitulo(gm,I.tit,860,72,2);
  const h=tam+70+mt.ls.length*mt.f*1.1+mt.f*.5+20+(est?110:0)+94;
  const H=o.fundo?1920:Math.round(h+pad*2);
  c.width=W;c.height=H;const g=c.getContext("2d");
  if(o.fundo)fundoStory(g,W,H,I.pal,A.capa,v);
  const y0=o.fundo?(H-h)/2:pad;
  const dr=320,dcx=cxv+tam-10,dcy=y0+tam/2;
  g.save();g.shadowColor="rgba(0,0,0,.5)";g.shadowBlur=50;g.shadowOffsetY=20;
  g.beginPath();g.arc(dcx,dcy,dr,0,Math.PI*2);g.fillStyle="var(--srf2)";g.fill();g.restore();
  g.save();g.beginPath();g.arc(dcx,dcy,dr,0,Math.PI*2);g.clip();
  g.lineWidth=2;
  for(let r=130;r<dr-6;r+=11){g.strokeStyle=`rgba(255,255,255,${r%22<11?.05:.025})`;g.beginPath();g.arc(dcx,dcy,r,0,Math.PI*2);g.stroke()}
  g.fillStyle="rgba(255,255,255,.07)";
  for(const a0 of [-.75,Math.PI-.75]){g.beginPath();g.moveTo(dcx,dcy);g.arc(dcx,dcy,dr,a0,a0+.45);g.closePath();g.fill()}
  g.restore();
  g.beginPath();g.arc(dcx,dcy,108,0,Math.PI*2);g.fillStyle=rgba(I.pal[0]);g.fill();
  g.beginPath();g.arc(dcx,dcy,14,0,Math.PI*2);g.fillStyle="var(--srf2)";g.fill();
  g.save();g.shadowColor="rgba(0,0,0,.55)";g.shadowBlur=50;g.shadowOffsetY=22;rrect(g,cxv,y0,tam,tam,26);g.fillStyle="#000";g.fill();g.restore();
  fotoOuGrad(g,I,cxv,y0,tam,tam,26);
  let cy=blocoTexto(g,I,W/2,y0+tam+70,860,72,"center","#fff","rgba(255,255,255,.78)");
  if(est){desenharEstrelas(g,W/2,cy+52,nota,70);cy+=110}
  siteNome(g,W/2,cy+54,"center");
}

/* Polaroid: moldura inclinada com a foto e o texto embaixo */
function desenharPolaroid(c,I,v,o){
  const W=1080,{A,nota,m}=I,est=!!(o.estrelas&&nota);
  const H=o.fundo?1920:1260;
  c.width=W;c.height=H;const g=c.getContext("2d");
  if(o.fundo)fundoStory(g,W,H,I.pal,A.capa,v);
  const fw=800,fh=980,cy=o.fundo?H/2-50:fh/2+90;
  g.save();g.translate(W/2,cy);g.rotate(-4*Math.PI/180);
  g.shadowColor="rgba(0,0,0,.45)";g.shadowBlur=60;g.shadowOffsetY=30;
  rrect(g,-fw/2,-fh/2,fw,fh,14);g.fillStyle="#f7f4ee";g.fill();
  g.shadowColor="transparent";g.shadowBlur=0;g.shadowOffsetY=0;
  fotoOuGrad(g,I,-fw/2+40,-fh/2+40,720,720,6);
  const by=-fh/2+40+720;
  g.font=`800 50px ${FNT}`;texto(g,cortar(g,I.tit,700),0,by+84,`800 50px ${FNT}`,"#17171a");
  g.font=`500 34px ${FNT}`;texto(g,cortar(g,m.a||"",700),0,by+134,`500 34px ${FNT}`,"#6b6b70");
  if(est)desenharEstrelas(g,0,by+196,nota,50,"#17171a","rgba(0,0,0,.15)");
  g.save();g.rotate(.06);rrect(g,-95,-fh/2-28,190,58,4);g.fillStyle="rgba(255,226,140,.8)";g.fill();g.restore();
  g.restore();
  siteNome(g,W/2,H-(o.fundo?120:50),"center");
}

/* ---- Letra: vários estilos para o trecho digitado pelo usuário ---- */
const LSTYLES=["Center","Card","Highlight","Minimal","Cover","Poster"];
const LSTYLE_AL=[1,0,0,0,0,0];
const LFONTS=[
  ["Sans",s=>`800 ${s}px ${FNT}`],
  ["Serif",s=>`700 ${s}px Georgia,"Times New Roman",serif`],
  ["Mono",s=>`600 ${s}px ui-monospace,Menlo,Consolas,monospace`],
  ["Italic",s=>`italic 700 ${s}px Georgia,"Times New Roman",serif`]
];
const LALIN=["left","center","right"];
const LTAM=[["S",.72],["M",1],["L",1.3]];
const LCORES=["Auto","White","Black","Color"];
const marcaOn=()=>window.__marca!==false;
const ancora=(L,W,M)=>L.al==="left"?M:L.al==="right"?W-M:W/2;

function lyricCfg(I,o,v){
  const vazio=!(o.letra||"").trim();
  const txt=vazio?"Write the lyric\nexcerpt you want\nto share here":o.letra.trim();
  const clar=I.pal[0].map(x=>Math.round(x+(255-x)*.5));
  const sobreClaro=!!(o.fundo&&v===5);
  const escuro=o.lc===2||(o.lc===0&&sobreClaro);
  let real=escuro?"#101012":"#fff";
  if(o.lc===3)real=sobreClaro?rgba(escurece(I.pal[0],.4)):rgba(clar);
  const textoEscuro=escuro||(o.lc===3&&sobreClaro);
  return {
    vazio,txt,clar,sobreClaro,escuro,
    mainReal:real,
    main:vazio?(textoEscuro?"rgba(16,16,18,.38)":"rgba(255,255,255,.4)"):real,
    sub:textoEscuro?"rgba(16,16,18,.62)":"rgba(255,255,255,.75)",
    faint:textoEscuro?"rgba(16,16,18,.18)":"rgba(255,255,255,.28)",
    font:LFONTS[o.lf||0][1],
    al:LALIN[o.la==null?1:o.la],
    mult:LTAM[o.lt==null?1:o.lt][1]
  };
}
/* Versão do texto para superfícies escuras ou coloridas (cartão, pôster) */
function sobreSuperficie(L,I,o,preto){
  const p=!!(preto&&o.lc===2);
  const real=o.lc===3?rgba(L.clar):p?"#101012":"#fff";
  return {...L,mainReal:real,main:L.vazio?(p?"rgba(16,16,18,.4)":"rgba(255,255,255,.45)"):real,sub:p?"rgba(16,16,18,.65)":"rgba(255,255,255,.78)",faint:p?"rgba(16,16,18,.18)":"rgba(255,255,255,.28)",escuro:p};
}
function ajustarLetra(g,L,maxW,maxH,fsMax,lhm,inq){
  lhm=lhm||1.22;
  const base=inq&&!L.vazio?`“${L.txt}”`:L.txt;
  let fs=Math.round(fsMax*L.mult),ls=[];
  for(;;){
    g.font=L.font(fs);
    ls=base.split(/\n/).flatMap(p=>p.trim()?quebrarLinhas(g,p.trim(),maxW):[""]);
    if(ls.length*fs*lhm<=maxH||fs<=30)break;
    fs-=4;
  }
  return {fs,ls,lh:fs*lhm};
}
function linhasLetra(g,L,T,ax,y){
  T.ls.forEach((l,i)=>{if(l)texto(g,l,ax,y+T.fs*.9+i*T.lh,L.font(T.fs),L.main,L.al)});
}
/* Rodapé: capa pequena + título e artista, alinhado conforme a opção de alinhamento */
function rodapeLetra(g,I,o,L,W,M,y,rod,comCapa){
  const tc=comCapa&&o.lcapa,ti=o.linfo;
  if(!tc&&!ti)return 0;
  g.font=`800 40px ${FNT}`;const wt=g.measureText(I.tit).width;
  g.font=`600 32px ${FNT}`;const wa=g.measureText(I.m.a||"").width;
  const tw=ti?Math.min(620,Math.max(wt,wa)):0,gap=tc&&ti?26:0,bw=(tc?rod:0)+gap+tw;
  const x0=L.al==="left"?M:L.al==="right"?W-M-bw:(W-bw)/2;
  if(tc)fotoOuGrad(g,I,x0,y,rod,rod,18);
  const hh=tc?rod:84;
  if(ti){
    const tx=x0+(tc?rod+gap:0),ty=y+hh/2-6;
    g.font=`800 40px ${FNT}`;const t1=cortar(g,I.tit,620);
    g.font=`600 32px ${FNT}`;const t2=cortar(g,I.m.a||"",620);
    texto(g,t1,tx,ty,`800 40px ${FNT}`,L.mainReal,"left");
    texto(g,t2,tx,ty+46,`600 32px ${FNT}`,L.sub,"left");
  }
  return hh;
}
function estrelasLetra(g,I,L,x,y){
  desenharEstrelas(g,x,y,I.nota,70,L.escuro?"#101012":"#fff",L.escuro?"rgba(16,16,18,.2)":undefined);
}

/* 0 · Centro: aspas grandes, texto, e capa com título embaixo */
function letraCentro(c,I,v,o,L){
  const W=1080,M=100,rod=120,est=!!(o.estrelas&&I.nota),mk=marcaOn();
  const T=ajustarLetra(c.getContext("2d"),L,W-2*M,820,86);
  const th=T.ls.length*T.lh,qh=o.lq?150:0,ft=(o.lcapa||o.linfo)?(o.lcapa?rod:84):0;
  const h=qh+th+(ft?70+ft:0)+(est?110:0)+(mk?90:0);
  const pad=60,H=o.fundo?1920:Math.round(h+pad*2);
  c.width=W;c.height=H;const g=c.getContext("2d");
  if(o.fundo)fundoStory(g,W,H,I.pal,I.A.capa,v);
  const ax=ancora(L,W,M);let y=o.fundo?(H-h)/2:pad;
  if(o.lq){texto(g,"“",ax,y+190,`900 240px Georgia,serif`,L.faint,L.al);y+=qh}
  linhasLetra(g,L,T,ax,y);y+=th;
  if(ft){y+=70;rodapeLetra(g,I,o,L,W,M,y,rod,true);y+=ft}
  if(est){estrelasLetra(g,I,L,W/2,y+80);y+=110}
  siteNome(g,W/2,y+40,"center",L.sub);
}

/* 1 · Cartão: cartão colorido com a capa no topo e a letra dentro */
function letraCartao(c,I,v,o,L0){
  const W=1080,cw=920,px=70,x0=(W-cw)/2,rod=130,est=!!(o.estrelas&&I.nota),mk=marcaOn();
  const L=sobreSuperficie(L0,I,o,true);
  const T=ajustarLetra(c.getContext("2d"),L,cw-2*px,760,74);
  const th=T.ls.length*T.lh,hd=(o.lcapa||o.linfo)?(o.lcapa?rod:84)+56:0;
  const ch=px+hd+th+(est?110:0)+(mk?90:20)+Math.round(px*.6);
  const H=o.fundo?1920:Math.round(ch+120);
  c.width=W;c.height=H;const g=c.getContext("2d");
  if(o.fundo)fundoStory(g,W,H,I.pal,I.A.capa,v);
  const cy=(H-ch)/2;
  g.save();g.shadowColor="rgba(0,0,0,.5)";g.shadowBlur=70;g.shadowOffsetY=28;
  const f=g.createLinearGradient(x0,cy,x0+cw,cy+ch);f.addColorStop(0,rgba(escurece(I.pal[0],.1)));f.addColorStop(1,rgba(escurece(I.pal[1],.25)));
  g.fillStyle=f;rrect(g,x0,cy,cw,ch,56);g.fill();g.restore();
  if(o.lq)texto(g,"”",x0+cw-px+10,cy+px+170,`900 220px Georgia,serif`,L.faint,"right");
  let y=cy+px;
  if(hd){rodapeLetra(g,I,o,{...L,al:"left"},W,x0+px,y,rod,true);y+=hd}
  const ax=L.al==="left"?x0+px:L.al==="right"?x0+cw-px:W/2;
  linhasLetra(g,L,T,ax,y);y+=th;
  if(est){
    const cr=L.escuro?"#101012":"#fff",vz=L.escuro?"rgba(16,16,18,.2)":undefined;
    if(L.al==="left")estrelasAl(g,x0+px,y+80,I.nota,70,"left",cr,vz);else desenharEstrelas(g,L.al==="right"?x0+cw-px-70*2.4:W/2,y+80,I.nota,70,cr,vz);
    y+=110;
  }
  if(mk){g.letterSpacing="6px";texto(g,"TRACKLY",x0+px,y+54,`800 26px ${FNT}`,L.sub,"left");g.letterSpacing="0px"}
}

/* 2 · Destaque: cada linha com marca-texto atrás */
function letraDestaque(c,I,v,o,L){
  const W=1080,M=90,rod=120,padx=30,est=!!(o.estrelas&&I.nota),mk=marcaOn();
  const T=ajustarLetra(c.getContext("2d"),L,W-2*M-2*padx,820,76,1.4);
  const th=T.ls.length*T.lh,ft=(o.lcapa||o.linfo)?(o.lcapa?rod:84):0;
  const h=th+(ft?80+ft:0)+(est?110:0)+(mk?90:0);
  const pad=60,H=o.fundo?1920:Math.round(h+pad*2);
  c.width=W;c.height=H;const g=c.getContext("2d");
  if(o.fundo)fundoStory(g,W,H,I.pal,I.A.capa,v);
  const bar=o.lc===2?["#101012","#fff"]:o.lc===3?[rgba(L.sobreClaro?escurece(I.pal[0],.2):I.pal[0]),"#fff"]:["#fff","#101012"];
  let y=o.fundo?(H-h)/2:pad;
  T.ls.forEach((l,i)=>{
    if(!l)return;
    g.font=L.font(T.fs);
    const w=g.measureText(l).width,bw=w+2*padx;
    const bx=L.al==="left"?M:L.al==="right"?W-M-bw:(W-bw)/2,by=y+i*T.lh;
    g.fillStyle=L.vazio?"rgba(255,255,255,.5)":bar[0];rrect(g,bx,by,bw,T.fs*1.22,14);g.fill();
    texto(g,l,bx+padx,by+T.fs*.93,L.font(T.fs),L.vazio?"rgba(16,16,18,.6)":bar[1],"left");
  });
  y+=th;
  if(ft){y+=80;rodapeLetra(g,I,o,L,W,M,y,rod,true);y+=ft}
  if(est){estrelasLetra(g,I,L,W/2,y+80);y+=110}
  siteNome(g,W/2,y+40,"center",L.sub);
}

/* 3 · Minimal: só o texto grande, com informações discretas embaixo */
function letraMinimal(c,I,v,o,L){
  const W=1080,M=100,rod=120,est=!!(o.estrelas&&I.nota),mk=marcaOn();
  const T=ajustarLetra(c.getContext("2d"),L,W-2*M,1000,118,1.18,o.lq);
  const th=T.ls.length*T.lh,ft=(o.lcapa||o.linfo)?(o.lcapa?rod:84):0;
  const h=th+(est?110:0)+(ft?130+ft:0)+(mk?100:0);
  const pad=70,H=o.fundo?1920:Math.round(h+pad*2);
  c.width=W;c.height=H;const g=c.getContext("2d");
  if(o.fundo)fundoStory(g,W,H,I.pal,I.A.capa,v);
  const ax=ancora(L,W,M);
  let y=o.fundo?Math.max(150,(H-th-(est?110:0))/2-90):pad;
  linhasLetra(g,L,T,ax,y);y+=th;
  if(est){estrelasLetra(g,I,L,W/2,y+90);y+=110}
  if(ft){
    const fy=o.fundo?H-ft-(mk?220:140):y+130;
    const rx=L.al==="left"?M:L.al==="right"?W-M-120:(W-120)/2;
    g.fillStyle=L.faint;rrect(g,rx,fy-60,120,8,4);g.fill();
    rodapeLetra(g,I,o,L,W,M,fy,rod,true);y=fy+ft;
  }
  siteNome(g,W/2,o.fundo?H-90:y+70,"center",L.sub);
}

/* 4 · Capa: capa grande no topo e a letra logo abaixo */
function letraCapa(c,I,v,o,L){
  const W=1080,M=100,tam=700,est=!!(o.estrelas&&I.nota),mk=marcaOn();
  const T=ajustarLetra(c.getContext("2d"),L,W-2*M,o.lcapa?560:900,68,1.22,o.lq);
  const th=T.ls.length*T.lh,cap=o.lcapa?tam+70:0,fi=o.linfo?84:0;
  const h=cap+th+(fi?60+fi:0)+(est?110:0)+(mk?90:0);
  const pad=70,H=o.fundo?1920:Math.round(h+pad*2);
  c.width=W;c.height=H;const g=c.getContext("2d");
  if(o.fundo)fundoStory(g,W,H,I.pal,I.A.capa,v);
  const ax=ancora(L,W,M);let y=o.fundo?(H-h)/2:pad;
  if(o.lcapa){
    const cx=L.al==="left"?M:L.al==="right"?W-M-tam:(W-tam)/2;
    g.save();g.shadowColor="rgba(0,0,0,.5)";g.shadowBlur=60;g.shadowOffsetY=26;rrect(g,cx,y,tam,tam,34);g.fillStyle="#000";g.fill();g.restore();
    fotoOuGrad(g,I,cx,y,tam,tam,34);y+=cap;
  }
  linhasLetra(g,L,T,ax,y);y+=th;
  if(fi){y+=60;rodapeLetra(g,I,o,L,W,M,y,120,false);y+=fi}
  if(est){estrelasLetra(g,I,L,W/2,y+80);y+=110}
  siteNome(g,W/2,y+40,"center",L.sub);
}

/* 5 · Pôster: capa em tela cheia escurecida com a letra por cima */
function letraPoster(c,I,v,o,L0){
  const W=1080,M=90,est=!!(o.estrelas&&I.nota),mk=marcaOn();
  const H=o.fundo?1920:1500;
  const L=sobreSuperficie(L0,I,o,false);
  const T=ajustarLetra(c.getContext("2d"),L,W-2*M,H*.5,96,1.2,o.lq);
  c.width=W;c.height=H;const g=c.getContext("2d");
  if(!o.fundo){rrect(g,0,0,W,H,56);g.clip()}
  fotoOuGrad(g,I,0,0,W,H,0);
  g.fillStyle="rgba(0,0,0,.28)";g.fillRect(0,0,W,H);
  const sc=g.createLinearGradient(0,H*.25,0,H);sc.addColorStop(0,"rgba(0,0,0,0)");sc.addColorStop(.55,"rgba(0,0,0,.6)");sc.addColorStop(1,"rgba(0,0,0,.92)");
  g.fillStyle=sc;g.fillRect(0,H*.25,W,H*.75);
  if(mk)siteNome(g,M,120,"left","rgba(255,255,255,.85)");
  const th=T.ls.length*T.lh,fi=o.linfo?84:0;
  const total=th+(est?110:0)+(fi?50+fi:0);
  let y=H-110-total;
  const ax=ancora(L,W,M);
  linhasLetra(g,L,T,ax,y);y+=th;
  if(est){
    if(L.al==="left")estrelasAl(g,M,y+80,I.nota,70,"left");else estrelasLetra(g,I,{escuro:false},W/2,y+80);
    y+=110;
  }
  if(fi){y+=50;rodapeLetra(g,I,o,L,W,M,y,120,false)}
}

function desenharLetra(c,I,v,o){
  const L=lyricCfg(I,o,v);
  [letraCentro,letraCartao,letraDestaque,letraMinimal,letraCapa,letraPoster][o.ly||0](c,I,v,o,L);
}


/* ---- Desenho: perfil ---- */
function desenharPerfil(g,W,H,A,v){
  const p=P(),fav=p.fav||[];
  const pal=paletaDaImagem(A.fonte,p.handle||"trackly");
  fundoStory(g,W,H,pal,A.fonte,v);
  g.letterSpacing="10px";texto(g,"TRACKLY",W/2,150,`800 34px ${FNT}`,"rgba(255,255,255,.8)");g.letterSpacing="0px";
  g.save();g.beginPath();g.arc(W/2,400,150,0,Math.PI*2);g.closePath();g.clip();
  if(A.avatar){desenharCapa(g,A.avatar,W/2-150,250,300,300,0)}else{const f=g.createLinearGradient(W/2-150,250,W/2+150,550);f.addColorStop(0,"#8B5CF6");f.addColorStop(1,"#B794F6");g.fillStyle=f;g.fillRect(W/2-150,250,300,300);texto(g,ini(p.nome),W/2,430,`900 120px ${FNT}`,"#fff")}
  g.restore();
  g.lineWidth=8;g.strokeStyle="rgba(255,255,255,.25)";g.beginPath();g.arc(W/2,400,150,0,Math.PI*2);g.stroke();
  texto(g,p.nome.slice(0,20),W/2,640,`900 92px ${FNT}`,"#fff");
  texto(g,"@"+p.handle,W/2,710,`600 42px ${FNT}`,"rgba(255,255,255,.7)");
  if(p.bio){g.font=`500 38px ${FNT}`;quebrarLinhas(g,p.bio,840).slice(0,3).forEach((l,i)=>texto(g,l,W/2,790+i*54,`500 38px ${FNT}`,"rgba(255,255,255,.9)"))}
  const ouv=Object.values(S.u).filter(x=>x.d).length,av2=Object.values(S.u).filter(x=>x.r);
  const media=av2.length?(av2.reduce((s,x)=>s+x.r,0)/av2.length).toFixed(1):"—";
  [[ouv,"listened"],[av2.length,"ratings"],[media,"avg"]].forEach(([n,l],i)=>{const x=W/2+(i-1)*290;texto(g,String(n),x,1000,`900 84px ${FNT}`,"#fff");texto(g,l,x,1050,`700 30px ${FNT}`,"rgba(255,255,255,.6)")});
  texto(g,"Favorite albums",W/2,1150,`800 40px ${FNT}`,"#fff");
  const tam=200,gap=26,x0=(W-(4*tam+3*gap))/2;
  for(let i=0;i<4;i++){const x=x0+i*(tam+gap),y=1190,k=fav[i];
    if(k){
      if(A.capas[i])desenharCapa(g,A.capas[i],x,y,tam,tam,26);
      else{const [a,b]=paletaFallback(k);const t=g.createLinearGradient(x,y,x+tam,y+tam);t.addColorStop(0,rgba(a));t.addColorStop(1,rgba(escurece(b,.3)));g.fillStyle=t;rrect(g,x,y,tam,tam,26);g.fill()}
      texto(g,((S.meta[k]||{}).t||"").slice(0,16),x+tam/2,y+tam+42,`700 26px ${FNT}`,"rgba(255,255,255,.9)");
    }else{g.strokeStyle="rgba(255,255,255,.25)";g.setLineDash([12,10]);g.lineWidth=3;rrect(g,x,y,tam,tam,26);g.stroke();g.setLineDash([])}
  }
  texto(g,"Favorite songs",W/2,1560,`800 40px ${FNT}`,"#fff");
  (p.musicas||[]).slice(0,4).forEach((m,i)=>texto(g,(i+1)+". "+m.slice(0,38),W/2,1625+i*64,`600 38px ${FNT}`,"rgba(255,255,255,.92)"));
  texto(g,"@"+p.handle+" · Trackly",W/2,1850,`600 32px ${FNT}`,"rgba(255,255,255,.55)");
}

/* ---- Prévia com variações ---- */
function compartilharCanvas(c,nome){
  c.toBlob(async blob=>{
    if(!blob){flash("Could not generate the image");return}
    const file=new File([blob],nome,{type:"image/png"});
    try{if(navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({files:[file],title:"Trackly"});return}}
    catch(e){if(e.name==="AbortError")return}
    const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=nome;document.body.appendChild(a);a.click();a.remove();
    flash("Image saved. Post it to your Story from the Instagram app.");
  },"image/png");
}
/* Painel de Story: prévia em cima e abas embaixo (Estilo, Letra, Fundo, Extras) */
(function(){const s=document.createElement("style");s.textContent=`
#stv{position:fixed;left:0;right:0;top:0;height:var(--vh,100dvh);z-index:90;background:#050506;display:flex;flex-direction:column;overflow:hidden}
#stv .stprev{position:relative;flex:1 1 0;min-height:0;display:flex;align-items:center;justify-content:center;padding:calc(16px + env(safe-area-inset-top,0px)) 16px 12px;overflow:hidden}
#stv canvas{display:block;flex:0 0 auto;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.6)}
#stv canvas.xp{background:repeating-conic-gradient(#2a2a2e 0 25%,#1c1c1f 0 50%) 0 0/24px 24px}
#stv .stx{position:absolute;top:calc(10px + env(safe-area-inset-top,0px));right:12px;width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.14);display:grid;place-items:center;font-size:22px;font-weight:600;line-height:1;z-index:3;text-align:center;padding:0}
#stv .stpanel{flex:0 0 auto;display:flex;flex-direction:column;background:#111113;border-radius:24px 24px 0 0;border-top:1px solid rgba(255,255,255,.08)}
#stv .sttabs{display:flex;gap:4px;margin:12px 14px 2px;padding:4px;border-radius:14px;background:rgba(255,255,255,.07);flex-shrink:0}
#stv .stt{flex:1;padding:9px 4px;border-radius:10px;text-align:center;font-weight:800;font-size:13px;color:#8e8e93;white-space:nowrap}
#stv .stt.on{background:#fff;color:#000}
#stv .stbody{height:min(200px,calc(var(--vh,100vh)*.3));overflow-y:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;padding:10px 14px 8px;display:flex;flex-direction:column;gap:10px}
#stv .seg{display:flex;gap:3px;padding:3px;border-radius:12px;background:rgba(255,255,255,.07);min-width:0;flex-shrink:0}
#stv .opt .seg{flex:1}
#stv .seg button{flex:1;padding:8px 2px;border-radius:9px;text-align:center;font-weight:700;font-size:13px;color:#b0b0b5;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#stv .seg button.on{background:#fff;color:#000}
#stv .opt{display:flex;align-items:center;gap:10px;flex-shrink:0}
#stv .opt>span{flex:0 0 62px;font-size:12px;font-weight:800;color:#8e8e93}
#stv .throw{display:flex;gap:10px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding:2px 2px 4px;flex-shrink:0}
#stv .throw::-webkit-scrollbar{display:none}
#stv .th{flex:0 0 auto;width:58px;display:flex;flex-direction:column;align-items:center;gap:6px;padding:0}
#stv .thb{display:block;width:58px;height:103px;border-radius:12px;background:#1c1c1f center/cover no-repeat;border:2px solid transparent;box-sizing:border-box}
#stv .th.on .thb{border-color:#fff}
#stv .th em{font-style:normal;font-size:11px;font-weight:700;color:#8e8e93;white-space:nowrap}
#stv .th.on em{color:#fff}
#stv .tg{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-radius:14px;background:rgba(255,255,255,.06);font-weight:700;font-size:14px;width:100%;flex-shrink:0}
#stv .sw{display:block;width:42px;height:26px;border-radius:13px;background:rgba(255,255,255,.2);position:relative;flex-shrink:0;transition:background .2s}
#stv .sw::after{content:"";position:absolute;left:3px;top:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:transform .2s}
#stv .sw.on{background:var(--acc)}
#stv .sw.on::after{transform:translateX(16px)}
#stv textarea.field{min-height:84px;font-size:16px;resize:none;flex-shrink:0}
#stv .sthint{font-size:12px;color:#8e8e93;font-weight:600;flex-shrink:0}
#stv .stacts{flex:0 0 auto;display:flex;gap:10px;padding:10px 14px calc(12px + env(safe-area-inset-bottom,0px));border-top:1px solid rgba(255,255,255,.08)}
#stv .stacts .btn{flex:1;justify-content:center;padding:13px 16px;font-size:15px}
#stv .stld{margin:auto;color:#8e8e93;font-weight:700}
#stv.kb .stacts{display:none}
#stv.kb .stbody{height:auto;max-height:calc(var(--vh,100vh)*.36)}
@media(min-width:900px){
  #stv{flex-direction:row}
  #stv .stpanel{width:410px;height:100%;border-radius:0;border-top:0;border-left:1px solid rgba(255,255,255,.08)}
  #stv .stbody{height:auto;flex:1 1 auto}
}
`;document.head.appendChild(s)})();

async function abrirStory(tipo,k,mus){
  document.getElementById("stv")?.remove();
  const ov=document.createElement("div");ov.id="stv";
  ov.innerHTML=`<div class="stld">Preparing image…</div>`;
  document.body.appendChild(ov);document.body.style.overflow="hidden";
  const vv=window.visualViewport;
  const medir=()=>{if(!vv)return;ov.style.setProperty("--vh",vv.height+"px");ov.style.top=vv.offsetTop+"px";ov.classList.toggle("kb",vv.height<window.innerHeight*.75)};
  medir();
  if(vv){vv.addEventListener("resize",medir);vv.addEventListener("scroll",medir)}
  let ro=null;
  const esc2=e=>{if(e.key==="Escape"&&e.target.tagName!=="TEXTAREA")fechar()};
  const fechar=()=>{
    if(ro)ro.disconnect();
    if(vv){vv.removeEventListener("resize",medir);vv.removeEventListener("scroll",medir)}
    ov.remove();document.body.style.overflow="";window.__marca=true;
    document.removeEventListener("keydown",esc2);
  };
  document.addEventListener("keydown",esc2);
  try{await Promise.all(["400","500","600","700","800","900"].map(w=>document.fonts.load(`${w} 40px Inter`)))}catch(e){}
  if(!ov.isConnected)return;
  let A={};
  if(mus)A.musica=mus;
  if(tipo==="resenha"){A.capa=await carregarImg(coverDe(k))}
  else{
    const p=P(),fav=p.fav||[];
    A.capas=await Promise.all(fav.slice(0,4).map(x=>carregarImg(coverDe(x))));
    A.avatar=await carregarImg(p.avatar);
    const banner=await carregarImg(p.banner);
    A.fonte=A.capas.find(Boolean)||banner||A.avatar||null;
  }
  if(!ov.isConnected)return;

  const W=1080,H=1920,c=document.createElement("canvas");
  const temNota=tipo==="resenha"&&!!(mus?(S.u[tkey(mus.t,(S.meta[k]||{}).a)]||{}).r:(S.u[k]||{}).r);
  let v=0,tab=tipo==="resenha"?"estilo":"fundo";
  const o={fundo:true,estrelas:true,marca:true,mode:"res",lay:0,ly:0,letra:"",lf:0,la:1,lt:1,lc:0,lq:true,lcapa:true,linfo:true};
  const pal0=tipo==="resenha"?paletaDaImagem(A.capa,k):paletaDaImagem(A.fonte,P().handle||"trackly");
  const im0=tipo==="resenha"?A.capa:A.fonte;

  ov.innerHTML=`<div class="stprev"><button class="stx" data-sf aria-label="Close">×</button></div>
  <div class="stpanel"><div class="sttabs" id="sttabs"></div><div class="stbody" id="stbody"></div>
  <div class="stacts"><button class="btn" data-sf>Close</button><button class="btn p" data-ss>Share</button></div></div>`;
  const prev=ov.querySelector(".stprev");prev.appendChild(c);

  const ajusta=()=>{
    const cs=getComputedStyle(prev);
    const pw=prev.clientWidth-parseFloat(cs.paddingLeft)-parseFloat(cs.paddingRight);
    const ph=prev.clientHeight-parseFloat(cs.paddingTop)-parseFloat(cs.paddingBottom);
    if(pw<=0||ph<=0||!c.width||!c.height)return;
    const s=Math.min(pw/c.width,ph/c.height);
    c.style.width=Math.floor(c.width*s)+"px";c.style.height=Math.floor(c.height*s)+"px";
  };
  const desenhar=()=>{
    window.__marca=o.marca;
    if(tipo==="resenha"){desenharResenha(c,k,A,v,o);c.classList.toggle("xp",!o.fundo)}
    else{c.width=W;c.height=H;desenharPerfil(c.getContext("2d"),W,H,A,v)}
    ajusta();
  };

  /* Miniaturas: estilos desenhados de verdade e amostras de fundo */
  const thCache=new Map(),swCache=[];
  const swatch=i=>{
    if(swCache[i])return swCache[i];
    const t=document.createElement("canvas");t.width=116;t.height=206;
    try{fundoStory(t.getContext("2d"),116,206,pal0,im0,i)}catch(e){}
    return swCache[i]=t.toDataURL("image/jpeg",.7);
  };
  const tk=()=>[v,o.estrelas,o.marca,o.letra,o.lf,o.la,o.lt,o.lc,o.lq,o.lcapa,o.linfo].join("¦");
  let thTok=0;
  const renderThumbs=()=>{
    if(tab!=="estilo"||tipo!=="resenha")return;
    const tok=++thTok,modo=o.mode,n=(modo==="let"?LSTYLES:LAYOUTS).length,key=tk();
    let i=0;
    const prox=()=>{
      if(tok!==thTok||!ov.isConnected||i>=n)return;
      const ck=key+"|"+modo+"|"+i,el=ov.querySelector(`.thb[data-ti="${i}"]`);
      let url=thCache.get(ck);
      if(!url){
        try{
          window.__marca=o.marca;
          const oo={...o,fundo:true,mode:modo};
          if(modo==="let")oo.ly=i;else oo.lay=i;
          const tmp=document.createElement("canvas");
          desenharResenha(tmp,k,A,v,oo);
          const th=document.createElement("canvas");th.width=116;th.height=206;
          const tg=th.getContext("2d");tg.imageSmoothingEnabled=true;tg.imageSmoothingQuality="high";
          tg.drawImage(tmp,0,0,116,206);
          url=th.toDataURL("image/jpeg",.72);thCache.set(ck,url);
        }catch(e){url=""}
      }
      if(el&&url)el.style.backgroundImage=`url(${url})`;
      i++;setTimeout(prox,0);
    };
    setTimeout(prox,30);
  };

  /* Conteúdo das abas */
  const seg=(attr,arr,sel)=>`<div class="seg">${arr.map((n,i)=>`<button class="${i===sel?"on":""}" ${attr}="${i}">${n}</button>`).join("")}</div>`;
  const tog=(key,label,on)=>`<button class="tg" data-so="${key}"><span>${label}</span><i class="sw ${on?"on":""}"></i></button>`;
  const abasDe=()=>tipo!=="resenha"?[["fundo","Background"]]:[["estilo","Style"],...(o.mode==="let"?[["texto","Lyrics"]]:[]),["fundo","Background"],["extras","Extras"]];
  const corpo=()=>{
    if(tab==="estilo"){
      const nomes=o.mode==="let"?LSTYLES:LAYOUTS,atual=o.mode==="let"?o.ly:o.lay,key=tk();
      return `<div class="seg"><button class="${o.mode==="res"?"on":""}" data-md="res">Review</button><button class="${o.mode==="let"?"on":""}" data-md="let">Lyric excerpt</button></div>
      <div class="throw">${nomes.map((n,i)=>{const u=thCache.get(key+"|"+o.mode+"|"+i);return `<button class="th ${i===atual?"on":""}" data-sl="${i}"><span class="thb" data-ti="${i}"${u?` style="background-image:url(${u})"`:""}></span><em>${n}</em></button>`}).join("")}</div>`;
    }
    if(tab==="texto"){
      return `<textarea class="field" id="stlt" rows="3" maxlength="400" placeholder="Type or paste the excerpt you want to share">${esc(o.letra)}</textarea>
      <div class="opt"><span>Font</span>${seg("data-lf",LFONTS.map(f=>f[0]),o.lf)}</div>
      <div class="opt"><span>Align</span>${seg("data-la",["Left","Center","Right"],o.la)}</div>
      <div class="opt"><span>Size</span>${seg("data-lt",LTAM.map(t=>t[0]),o.lt)}</div>
      <div class="opt"><span>Color</span>${seg("data-lc",LCORES,o.lc)}</div>`;
    }
    if(tab==="fundo"){
      return `${tog("fundo","Use background",o.fundo)}
      <div class="throw" style="opacity:${o.fundo?1:.35};pointer-events:${o.fundo?"auto":"none"}">${VARIACOES.map((n,i)=>`<button class="th ${i===v?"on":""}" data-sv="${i}"><span class="thb" style="background-image:url(${swatch(i)})"></span><em>${n}</em></button>`).join("")}</div>
      ${o.fundo?"":`<div class="sthint">Without background, the image is exported with transparency (PNG).</div>`}`;
    }
    if(o.mode==="let"){
      return `${tog("lq","Quotes",o.lq)}${tog("lcapa","Show cover",o.lcapa)}${tog("linfo","Show song and artist",o.linfo)}${temNota?tog("estrelas","Show stars",o.estrelas):""}${tog("marca","Trackly signature",o.marca)}`;
    }
    return `${temNota?tog("estrelas","Show stars",o.estrelas):""}${tog("marca","Trackly signature",o.marca)}`;
  };
  const pintar=()=>{
    const abas=abasDe();
    if(!abas.some(a=>a[0]===tab))tab=abas[0][0];
    const tb=ov.querySelector("#sttabs");
    tb.style.display=abas.length>1?"":"none";
    tb.innerHTML=abas.map(([id,n])=>`<button class="stt ${id===tab?"on":""}" data-tab="${id}">${n}</button>`).join("");
    const sb=ov.querySelector("#stbody"),st=sb.scrollTop;
    sb.innerHTML=corpo();sb.scrollTop=st;
    renderThumbs();
  };
  pintar();desenhar();
  ro=new ResizeObserver(ajusta);ro.observe(prev);

  let tl=null;
  ov.addEventListener("input",e=>{
    if(e.target.id!=="stlt")return;
    o.letra=e.target.value;clearTimeout(tl);tl=setTimeout(desenhar,120);
  });
  ov.addEventListener("click",e=>{
    const t=e.target;
    const bt=t.closest("[data-tab]");if(bt){tab=bt.dataset.tab;pintar();return}
    const md=t.closest("[data-md]");
    if(md){o.mode=md.dataset.md;if(o.mode==="let"&&!o.letra.trim())tab="texto";pintar();desenhar();return}
    const sl=t.closest("[data-sl]");
    if(sl){
      const i=+sl.dataset.sl;
      if(o.mode==="let"){o.ly=i;o.la=LSTYLE_AL[i]}else o.lay=i;
      pintar();desenhar();return;
    }
    const sv=t.closest("[data-sv]");if(sv){v=+sv.dataset.sv;pintar();desenhar();return}
    const so=t.closest("[data-so]");if(so){o[so.dataset.so]=!o[so.dataset.so];pintar();desenhar();return}
    for(const a of ["lf","la","lt","lc"]){
      const b=t.closest(`[data-${a}]`);
      if(b){o[a]=+b.dataset[a];pintar();desenhar();return}
    }
    if(t.closest("[data-sf]")){fechar();return}
    if(t.closest("[data-ss]")){
      const base=tipo==="resenha"?(o.mode==="let"?"letra":(A.musica?"musica":"resenha")):"perfil";
      compartilharCanvas(c,tipo==="resenha"?(o.fundo?`trackly-${base}-story.png`:`trackly-${base}-sem-fundo.png`):"trackly-perfil-story.png");
    }
  });
}

function gerarStoryPerfil(){abrirStory("perfil")}
function gerarStoryResenha(k){
  if(!S.meta[k]){flash("Open the album from search first");return}
  abrirStory("resenha",k);
}
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-story]");
  if(b&&b.dataset.story==="album"){gerarStoryResenha(NAV.hash.slice(7));}
  if(b&&b.dataset.story==="musica"){const k=NAV.hash.slice(7);if(S.meta[k])abrirStory("resenha",k,{t:b.dataset.tt,ms:+b.dataset.ms||0});}
});

;/* ---------- bloco 06 ---------- */
/* ===== Novidades: média das faixas, fila, estatísticas, backup, ranking ===== */
const tic=()=>{try{navigator.vibrate&&navigator.vibrate(8)}catch(e){}};
const meioPonto=v=>Math.max(.5,Math.min(5,Math.round(v*2)/2));
function calcMedia(keys){
  const rs=keys.map(k=>(S.u[k]||{}).r).filter(Boolean);
  return {n:rs.length,total:keys.length,avg:rs.length?rs.reduce((a,b)=>a+b,0)/rs.length:0};
}
function mediaDOM(){return calcMedia([...document.querySelectorAll("#app .trate")].map(b=>b.dataset.tk))}
function mediaHTML(md){
  if(!md.n)return `<span class="mut sm">Rate tracks to see the album average</span>`;
  return `<span>Track average <strong>${md.avg.toFixed(1)}</strong></span><span class="mut sm">${md.n} of ${md.total} rated</span><button class="chip" data-act="usarMedia">Use as rating</button>`;
}
function mediaBloco(faixas,m,x){
  const md=calcMedia(faixas.map(t=>tkey(t.t,m.a)));
  return `<div class="autobox"><div id="mediaf" class="mediaf">${mediaHTML(md)}</div></div>`;
}
function atualizarMedia(){
  const el=document.getElementById("mediaf");if(!el)return;
  const md=mediaDOM();el.innerHTML=mediaHTML(md);
  const k=NAV.hash.slice(7),x=S.u[k];
  if(x&&x.auto&&md.n){
    x.r=meioPonto(md.avg);salvar();
    const r=document.getElementById("rate");if(r)r.innerHTML=rateHTML(x.r);
    const rl=document.getElementById("rlab");if(rl)rl.textContent=String(x.r)+" of 5";
  }
}

function filaView(){
  const e=Object.entries(S.u).filter(([k,v])=>v.w&&S.meta[k]);
  if(!e.length)return `<div class="empty" style="margin-top:30px">Your queue is empty. Tap "+ Want to listen" on an album page.</div>`;
  return `<div style="margin:26px 0 16px;display:flex;gap:12px;flex-wrap:wrap;align-items:center"><button class="btn p" data-fila="rnd">🎲 Pick from queue</button><span class="mut sm" style="font-weight:700">${e.length} album${e.length===1?"":"s"} waiting</span></div>
  <div class="grid">${e.map(([k])=>`<div style="position:relative">${cardMeta(k)}<button class="xb" data-fila="rm" data-id="${k}" aria-label="Remove from queue" style="position:absolute;top:8px;right:8px;z-index:3">×</button></div>`).join("")}</div>`;
}

function statsView(){
  const al=Object.entries(S.u).filter(([k])=>S.meta[k]);
  const ou=al.filter(([,v])=>v.d),av=al.filter(([,v])=>v.r);
  if(!ou.length&&!av.length)return `<div class="empty" style="margin-top:30px">Mark albums as listened and rate a few to see your stats.</div>`;
  const MES=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const hj=new Date(),meses=[];
  for(let i=11;i>=0;i--){const d=new Date(hj.getFullYear(),hj.getMonth()-i,1);meses.push({k:d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0"),l:MES[d.getMonth()],n:0})}
  ou.forEach(([,v])=>{const m=meses.find(x=>x.k===v.d.slice(0,7));if(m)m.n++});
  const mx=Math.max(1,...meses.map(m=>m.n));
  const esteAno=ou.filter(([,v])=>v.d.startsWith(String(hj.getFullYear()))).length;
  const media=av.length?(av.reduce((s,[,v])=>s+v.r,0)/av.length).toFixed(1):"—";
  const uso=al.filter(([,v])=>v.d||v.r);
  const conta=fn=>{const c={};uso.forEach(([k])=>{const x=fn(S.meta[k]);if(x)c[x]=(c[x]||0)+1});return Object.entries(c).sort((a,b)=>b[1]-a[1])};
  const gen=conta(m=>m.genre).slice(0,5);
  const dec=conta(m=>/^\d{4}$/.test(m.y||"")?Math.floor(+m.y/10)*10+"s":"").sort((a,b)=>a[0].localeCompare(b[0]));
  const art=conta(m=>m.a).slice(0,5);
  const bars=arr=>{const m=Math.max(1,...arr.map(x=>x[1]));return arr.map(([n,c])=>`<div class="brow"><span>${esc(n)}</span><div class="hbar"><i style="width:${c/m*100}%"></i></div><b>${c}</b></div>`).join("")};
  const top=[...av].sort((a,b)=>b[1].r-a[1].r).slice(0,5);
  const sec=(t,h)=>`<h3 class="sec" style="margin:30px 0 12px">${t}</h3>${h}`;
  const kpi=(n,l)=>`<div class="kpi"><strong>${n}</strong><span>${l}</span></div>`;
  return `<div class="kpis" style="margin-top:30px">${kpi(ou.length,"Listened")}${kpi(esteAno,"In "+hj.getFullYear())}${kpi(av.length,"Rated")}${kpi(media,"Avg")}</div>`
  +sec("Listened in the last 12 months",`<div class="hist2"><div class="mbars">${meses.map(m=>`<div class="mb"><b>${m.n||""}</b><i style="height:${Math.max(m.n?6:2,Math.round(m.n/mx*80))}px;${m.n?"":"opacity:.25"}"></i><span>${m.l}</span></div>`).join("")}</div></div>`)
  +(gen.length?sec("Top genres",`<div class="hist2">${bars(gen)}</div>`):"")
  +(dec.length?sec("By decade",`<div class="hist2">${bars(dec)}</div>`):"")
  +(art.length?sec("Most frequent artists",`<div class="hist2">${bars(art)}</div>`):"")
  +(top.length?sec("Highest rated",`<div class="mlist">${top.map(([k,v])=>{const m=S.meta[k];return `<a class="row" href="#album-${k}">${capaAlbum(k,m.t,46)}<div class="grow"><div class="ttl">${esc(m.t)}</div><div class="sm mut" style="font-weight:700">${esc(m.a)}</div></div>${estrelas(v.r)}</a>`}).join("")}</div>`):"");
}

function backupHTML(){
  return `<h2>Your data</h2><p class="mut sm" style="margin:-4px 0 12px;font-weight:600">Everything is saved only in this browser. Back up from time to time.</p>
  <div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn" data-bk="exp">Export backup</button><label class="btn" style="cursor:pointer">Import backup<input id="impf" type="file" accept="application/json,.json" hidden></label></div>`;
}
function exportar(){
  const blob=new Blob([JSON.stringify(S)],{type:"application/json"});
  const url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download="trackly-backup-"+hoje()+".json";document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),2000);flash("Backup saved");
}
function importar(f){
  if(!f)return;
  const r=new FileReader();
  r.onload=()=>{
    try{
      const o=JSON.parse(r.result);
      if(!o||typeof o!=="object"||!o.u||!o.meta)throw 0;
      if(!confirm("Importing this backup will replace the current data in this browser. Continue?"))return;
      S={u:{},meta:{},artists:{},listas:[],perfil:null,covers:{},...o};salvar();rota();flash("Backup imported");
    }catch(e){flash("Invalid backup file")}
  };
  r.readAsText(f);
}

document.addEventListener("click",e=>{
  const t=e.target;
  const fi=t.closest("[data-fila]");
  if(fi){
    if(fi.dataset.fila==="rnd"){
      const ks=Object.entries(S.u).filter(([k,v])=>v.w&&S.meta[k]).map(([k])=>k);
      if(ks.length)NAV.go("album-"+ks[Math.floor(Math.random()*ks.length)]);
    }else{const d=S.u[fi.dataset.id];if(d){delete d.w;salvar();rota();flash("Removed from queue")}}
    return;
  }
  if(t.closest("[data-bk]"))exportar();
});

;/* ---------- bloco 07 ---------- */
/* pontos do carrossel de favoritos */
document.addEventListener("scroll",e=>{
  const el=e.target;
  if(!el||!el.classList||!el.classList.contains("favpages"))return;
  const i=Math.round(el.scrollLeft/Math.max(1,el.clientWidth-0));
  document.querySelectorAll(".favdots button").forEach((b,n)=>b.classList.toggle("on",n===i));
},true);
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-favpg]");if(!b)return;
  const el=document.getElementById("favpages");
  if(el)el.scrollTo({left:+b.dataset.favpg*el.clientWidth,behavior:"smooth"});
});

;/* ---------- bloco 08 ---------- */
/* Sem zoom: o Safari do iPhone ignora user-scalable=no, então bloqueia os gestos na mão */
["gesturestart","gesturechange","gestureend"].forEach(n=>document.addEventListener(n,e=>e.preventDefault(),{passive:false}));
document.addEventListener("touchmove",e=>{if(e.touches&&e.touches.length>1)e.preventDefault()},{passive:false});
/* Se algo ainda empurrar a página pro lado, volta pro lugar */
window.addEventListener("scroll",()=>{if(window.scrollX)window.scrollTo(0,window.scrollY)},{passive:true});

;/* ---------- bloco 09 ---------- */
/* ===== Card da faixa: preview, clipe no YouTube e links para os serviços ===== */
async function abrirFaixa(t,a,alb,cover){
  document.getElementById("trk")?.remove();
  const ov=document.createElement("div");ov.id="trk";
  const q=encodeURIComponent(`${t} ${a}`),nt=norm(t);
  ov.innerHTML=`<div class="trkbox"><button class="trkx" data-trkx aria-label="Close">×</button>
  <div class="trkbg"${cover?` style="background-image:url('${cover}')"`:""}></div><div class="trkhead">${cover?`<img src="${cover}" alt="">`:`<div class="trkph">${esc(ini(t))}</div>`}<div class="trkt">${esc(t)}</div><div class="trksub">${esc(a)}${alb?" · "+esc(alb):""}</div></div>
  <h3 class="sec">Preview</h3><div id="trkprev" class="mut sm" style="font-weight:600">Looking for a preview…</div>
  <h3 class="sec" style="margin-top:20px">Music video</h3><div id="trkyt" class="mut sm" style="font-weight:600">Looking for the video…</div>
  <h3 class="sec" style="margin-top:20px">Listen on</h3><div class="trklinks" id="trklinks"></div></div>`;
  document.body.appendChild(ov);document.body.style.overflow="hidden";
  const L={},ytSearch=`https://www.youtube.com/results?search_query=${encodeURIComponent(t+" "+a+" official video")}`;
  const $$=s=>ov.querySelector(s);
  const pinta=()=>{const el=$$("#trklinks");if(!el)return;
    const it=[["Spotify",L.sp,`https://open.spotify.com/search/${q}`],["Apple Music",L.it,`https://music.apple.com/search?term=${q}`],["Deezer",L.dz,`https://www.deezer.com/search/${q}`],["YouTube",L.yt,ytSearch],["YouTube Music",null,`https://music.youtube.com/search?q=${q}`]];
    el.innerHTML=it.map(([n,d,f])=>`<a class="${d?"ok":""}" data-b="${n}" href="${esc(d||f)}" target="_blank" rel="noopener"><i class="bd">${n[0]}</i><span><b>${n}</b><small>${d?"Open this track":"Search for it"}</small></span><em>↗</em></a>`).join("")};
  pinta();
  const bate=x=>norm(x)===nt;
  const prev={};
  const tarefas=[
    getJSON(`${IT}/search?term=${q}&entity=song&limit=6`).then(j=>{const r=j.results||[];const x=r.find(y=>bate(y.trackName))||r[0];if(x){L.it=x.trackViewUrl;prev.it=x.previewUrl}}),
    dz(`/search/track?q=${q}&limit=6`).then(j=>{const r=j.data||[];const x=r.find(y=>bate(y.title))||r[0];if(x){L.dz=x.link;prev.dz=x.preview}}),
    spOn()?spSearch(q).then(j=>{const r=((j.tracks||{}).items||[]).filter(Boolean);const x=r.find(y=>bate(y.name))||r[0];if(x){L.sp=(x.external_urls||{}).spotify||`https://open.spotify.com/track/${x.id}`;prev.sp=x.preview_url}}):Promise.resolve()
  ].map(p=>p.catch(()=>{}));
  Promise.all(tarefas).then(()=>{
    pinta();const el=$$("#trkprev");if(!el)return;
    const u=prev.dz||prev.it||prev.sp;
    if(!u){el.textContent="No preview available for this track.";return}
    el.innerHTML=`<div class="trkpl"><button class="trkpp" aria-label="Play">▶</button><div class="trkcol"><div class="trkbar"><div class="trkfill"></div></div><div class="trktm"><span class="tc">0:00</span><span>0:30</span></div></div><audio preload="none" src="${esc(u)}"></audio></div>`;
    const au=el.querySelector("audio"),pp=el.querySelector(".trkpp"),fl=el.querySelector(".trkfill"),tc=el.querySelector(".tc"),br=el.querySelector(".trkbar");
    pp.onclick=()=>{au.paused?au.play().catch(()=>{}):au.pause()};
    au.onplay=()=>{pp.textContent="❚❚";ov.classList.add("pl")};
    au.onpause=()=>{pp.textContent="▶";ov.classList.remove("pl")};
    au.onended=()=>{fl.style.width="0";tc.textContent="0:00"};
    au.ontimeupdate=()=>{const d=au.duration||30;fl.style.width=(au.currentTime/d*100)+"%";tc.textContent="0:"+String(Math.floor(au.currentTime)).padStart(2,"0")};
    br.onclick=e=>{const r=br.getBoundingClientRect();au.currentTime=((e.clientX-r.left)/r.width)*(au.duration||30)};
  });
  (async()=>{
    let id=null;
    for(const h of ["https://pipedapi.kavin.rocks","https://pipedapi.adminforge.de","https://api.piped.private.coffee"]){
      if(!ov.isConnected)return;
      try{
        const c=new AbortController(),to=setTimeout(()=>c.abort(),4500);
        const r=await fetch(`${h}/search?q=${encodeURIComponent(t+" "+a+" official video")}&filter=videos`,{signal:c.signal});clearTimeout(to);
        if(!r.ok)continue;
        const j=await r.json(),v=(j.items||[]).find(x=>x.url&&/v=/.test(x.url));
        if(v){id=v.url.split("v=")[1].split("&")[0];break}
      }catch(e){}
    }
    const el=$$("#trkyt");if(!el)return;
    if(id){L.yt=`https://www.youtube.com/watch?v=${id}`;pinta();
      el.innerHTML=`<div class="yt"><iframe src="https://www.youtube-nocookie.com/embed/${id}" allow="accelerometer;encrypted-media;picture-in-picture;fullscreen" allowfullscreen loading="lazy"></iframe></div><div class="sm mut" style="margin-top:6px">Best match found automatically. It may not be the official clip.</div>`;
    }else el.innerHTML=`Couldn't load a video here. <a href="${ytSearch}" target="_blank" rel="noopener" style="color:var(--acc2);font-weight:800">Search on YouTube ↗</a>`;
  })();
}
function fecharFaixa(){document.getElementById("trk")?.remove();if(!document.getElementById("stv")&&!document.getElementById("ed"))document.body.style.overflow=""}
document.addEventListener("click",e=>{
  const p=e.target.closest("[data-play]");
  if(p){const k=NAV.hash.slice(7),m=S.meta[k]||{};abrirFaixa(p.dataset.tt,p.dataset.ta,m.t,coverDe(k));return}
  if(e.target.closest("[data-trkx]")||e.target.id==="trk")fecharFaixa();
});
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&document.getElementById("trk"))fecharFaixa()});
function atvGo(i){const sl=document.querySelectorAll("#atv .atv-s"),dt=document.querySelectorAll("#atv .atv-dots button");if(!sl.length)return;i=(i+sl.length)%sl.length;sl.forEach((x,n)=>x.classList.toggle("on",n===i));dt.forEach((x,n)=>x.classList.toggle("on",n===i))}
function atvCur(){return [...document.querySelectorAll("#atv .atv-s")].findIndex(x=>x.classList.contains("on"))}
setInterval(()=>{if(!document.hidden&&document.getElementById("atv")&&!document.getElementById("atv").matches(":hover"))atvGo(atvCur()+1)},6500);
document.addEventListener("click",e=>{const b=e.target.closest("[data-atv]");if(b)atvGo(+b.dataset.atv)});
(function(){let x0=null;document.addEventListener("touchstart",e=>{x0=e.target.closest("#atv")?e.touches[0].clientX:null},{passive:true});document.addEventListener("touchend",e=>{if(x0===null)return;const d=e.changedTouches[0].clientX-x0;if(Math.abs(d)>40)atvGo(atvCur()+(d<0?1:-1));x0=null},{passive:true})})();

;/* ---------- bloco 10 ---------- */
/* v2: efeito de borda só durante o arraste/rolagem, e arrastar com o mouse */
(function(){const marca=e=>{const w=e.target.closest&&e.target.closest(".carw");const c=e.target.closest&&e.target.closest(".carrossel")||(w&&w.querySelector(".carrossel"));if(c)c._u=Date.now()};
  ["pointerdown","touchstart","wheel","keydown"].forEach(n=>document.addEventListener(n,marca,{passive:true,capture:true}))})();
document.addEventListener("scroll",e=>{const c=e.target;if(!c||!c.classList||!c.classList.contains("carrossel"))return;
  if(!c._dn&&Date.now()-(c._u||0)>3000)return;
  const mx=c.scrollWidth-c.clientWidth;if(c.scrollLeft>4)c._arr=1;c.classList.toggle("fl",c.scrollLeft>4);c.classList.toggle("fr",!!c._arr&&c.scrollLeft<mx-4);
  c.classList.add("scr");clearTimeout(c._t);if(!c._dn)c._t=setTimeout(()=>c.classList.remove("scr"),500)},true);
(function(){const on=(e,v)=>{const c=e.target.closest&&e.target.closest('.carrossel');if(!c)return;c._dn=v;if(!v){clearTimeout(c._t);c._t=setTimeout(()=>c.classList.remove('scr'),350)}};
  document.addEventListener('pointerdown',e=>on(e,true));
  ['pointerup','pointercancel'].forEach(n=>document.addEventListener(n,()=>{document.querySelectorAll('.carrossel').forEach(c=>{if(c._dn){c._dn=false;clearTimeout(c._t);c._t=setTimeout(()=>c.classList.remove('scr'),350)}})}))})();
(function(){let c=null,x0=0,s0=0,mv=false;
  document.addEventListener("pointerdown",e=>{mv=false;if(e.pointerType!=="mouse"||e.button)return;c=e.target.closest(".carrossel");if(c){x0=e.clientX;s0=c.scrollLeft}});
  document.addEventListener("pointermove",e=>{if(!c)return;const d=e.clientX-x0;if(Math.abs(d)>5){mv=true;c.style.scrollSnapType="none";c.style.cursor="grabbing";c.scrollLeft=s0-d}});
  const up=()=>{if(c){c.style.scrollSnapType="";c.style.cursor=""}c=null};
  document.addEventListener("pointerup",up);document.addEventListener("pointercancel",up);
  document.addEventListener("click",e=>{if(mv){e.preventDefault();e.stopPropagation();mv=false}},true);
  document.addEventListener("dragstart",e=>{if(e.target.closest&&e.target.closest(".carrossel"))e.preventDefault()});
})();

;/* ---------- bloco 11 ---------- */
/* ===== Ícones SVG estilo SF Symbols ===== */
const ICP={
  listen:'<circle cx="12" cy="12" r="9"/><path d="M8 12.4l2.7 2.7 5.5-5.7"/>',
  queue:'<path d="M7.5 3.8h9A1.5 1.5 0 0 1 18 5.3v15l-6-4.2-6 4.2v-15a1.5 1.5 0 0 1 1.5-1.5z"/>',
  heart:'<path d="M12 20.2s-7.6-4.5-9.3-9.5C1.6 7.4 3.6 4.4 6.9 4.4c2 0 3.4 1.1 5.1 3 1.7-1.9 3.1-3 5.1-3 3.3 0 5.3 3 4.2 6.3-1.7 5-9.3 9.5-9.3 9.5z"/>',
  star:'<path d="M12 3.8l2.5 5.2 5.7.8-4.1 4 1 5.7L12 16.9l-5.1 2.6 1-5.7-4.1-4 5.7-.8z"/>',
  play:'<path d="M8.2 5.6v12.8a.6.6 0 0 0 .9.5l10.3-6.4a.6.6 0 0 0 0-1L9.1 5.1a.6.6 0 0 0-.9.5z"/>',
  share:'<path d="M12 3.5v11.5M8.2 7.2L12 3.5l3.8 3.7M7.5 10.5h-.8A1.7 1.7 0 0 0 5 12.2v6.1A1.7 1.7 0 0 0 6.7 20h10.6a1.7 1.7 0 0 0 1.7-1.7v-6.1a1.7 1.7 0 0 0-1.7-1.7h-.8"/>',
  more:'<circle cx="5.5" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18.5" cy="12" r="1.7"/>',
  chev:'<path d="M9 5l7 7-7 7"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  check:'<path d="M5 12.5l4.5 4.5L19 7"/>',
  list:'<path d="M9 6.5h10.5M9 12h10.5M9 17.5h10.5M4.5 6.5h.01M4.5 12h.01M4.5 17.5h.01"/>',
  calendar:'<rect x="4" y="5.5" width="16" height="14.5" rx="3"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>',
  tag:'<path d="M3.5 12.2V5A1.5 1.5 0 0 1 5 3.5h7.2a1.5 1.5 0 0 1 1.1.44l7.2 7.2a1.5 1.5 0 0 1 0 2.12l-6.9 6.9a1.5 1.5 0 0 1-2.12 0l-7.2-7.2a1.5 1.5 0 0 1-.44-1.1z"/><circle cx="8" cy="8" r="1.1"/>',
  note:'<path d="M9 17.5V6.5l10-2v11"/><circle cx="6.5" cy="17.5" r="2.5"/><circle cx="16.5" cy="15.5" r="2.5"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.4 2"/>',
  people:'<circle cx="9" cy="8.5" r="3.2"/><path d="M3 19c.6-3.2 3-5 6-5s5.4 1.8 6 5"/><path d="M16 5.6a3.2 3.2 0 0 1 0 5.8M18.5 14.4c1.5.7 2.4 2.1 2.7 4.6"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 3.8 5.6 3.8 9s-1.2 6.4-3.8 9c-2.6-2.6-3.8-5.6-3.8-9S9.4 5.6 12 3z"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.8h.01"/>',
  disc:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.6"/>',
  mic:'<rect x="9" y="3.5" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3"/>',
  chart:'<path d="M5 20v-8M12 20V5M19 20v-10"/>',
  pin:'<path d="M12 21s-6.5-5.7-6.5-11a6.5 6.5 0 0 1 13 0c0 5.3-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
  user:'<circle cx="12" cy="8.5" r="3.5"/><path d="M5 20c.8-3.6 3.6-5.5 7-5.5s6.2 1.9 7 5.5"/>',
  external:'<path d="M9 5H6.5A1.5 1.5 0 0 0 5 6.5v11A1.5 1.5 0 0 0 6.5 19h11a1.5 1.5 0 0 0 1.5-1.5V15M13 5h6v6M19 5l-8 8"/>',
  home:'<path d="M4 11l8-6.5 8 6.5v8a1 1 0 0 1-1 1h-4.5v-6h-5v6H5a1 1 0 0 1-1-1z"/>',
  search:'<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
  diary:'<path d="M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5z"/><path d="M5 19.5A1.5 1.5 0 0 0 6.5 21H19v-3"/>'
};
function ico(n,w,on){
  w=w||18;let p=ICP[n]||"",f=0,sw=1.9;
  if(on){
    if(n==="listen")p='<circle cx="12" cy="12" r="9" fill="currentColor"/><path d="M8 12.4l2.7 2.7 5.5-5.7" stroke="#fff"/>';
    else if(n==="queue"||n==="heart"||n==="star")f=1;
  }
  if(n==="play"){f=1;sw=1.2}
  if(n==="more"){f=1;sw=0}
  return `<svg class="ic" viewBox="0 0 24 24" width="${w}" height="${w}" fill="${f?"currentColor":"none"}" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
}
const likeInner=on=>ico("heart",18,on)+`<span>${on?"Liked":"Like"}</span>`;
const followInner=on=>on?ico("check",15)+" Following":ico("plus",15)+" Follow";

/* ===== Utilitários ===== */
const whenEl=(sel,fn,n)=>{n=n==null?60:n;const t=()=>{const e=document.querySelector(sel);if(e)fn(e);else if(n-->0)setTimeout(t,100)};t()};
function quando(d){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(d||""))return"";
  const days=Math.floor((Date.now()-new Date(d+"T00:00:00Z"))/864e5);
  if(days<0)return"Upcoming";
  if(days<1)return"Today";
  if(days<30)return days+(days>1?" days ago":" day ago");
  const mo=Math.floor(days/30.44);
  if(mo<12)return mo+(mo>1?" months ago":" month ago");
  const y=Math.floor(days/365.25);
  return y+(y>1?" years ago":" year ago");
}
function durTxt(ms){const mi=Math.max(1,Math.round(ms/60000));if(mi<60)return mi+" min";const h=Math.floor(mi/60),r=mi%60;return h+" hr"+(r?" "+r+" min":"")}
const urlOk=u=>{u=String(u||"").trim();if(!u)return"";return /^https?:\/\//i.test(u)?u:"https://"+u};

/* ===== Dados completos do álbum: faixas + data, gravadora, duração, copyright... ===== */
const _dadosCache={};
async function dadosAlbum(m){
  const ck=JSON.stringify(m.ids||{});
  if(_dadosCache[ck])return _dadosCache[ck];
  const info={},faixas=[],tarefas=[];
  if(m.ids.dz)tarefas.push(dz(`/album/${m.ids.dz}`).then(d=>{
    info.date=d.release_date||"";info.label=d.label||"";
    info.genres=((d.genres||{}).data||[]).map(g=>g.name);
    info.dur=(d.duration||0)*1000;info.fans=d.fans||0;info.upc=d.upc||"";
    info.ex=!!d.explicit_lyrics;info.artistDz=(d.artist||{}).id;info.link=d.link||"";
    info.contrib=(d.contributors||[]).map(c=>c.name);
    ((d.tracks||{}).data||[]).forEach(t=>faixas.push({t:t.title,ms:t.duration*1000,ex:!!t.explicit_lyrics,rk:t.rank||0}));
  }));
  if(m.ids.it)tarefas.push(getJSON(`${IT}/lookup?id=${m.ids.it}`).then(j=>{
    const r=(j.results||[])[0]||{};
    info.copy=r.copyright||"";info.itLink=r.collectionViewUrl||"";
    if(!info.date&&r.releaseDate)info.date=r.releaseDate.slice(0,10);
    if(r.primaryGenreName)info.itGenre=r.primaryGenreName;
  }));
  else tarefas.push(Promise.race([getJSON(`${IT}/search?term=${encodeURIComponent(m.t+" "+m.a)}&entity=album&limit=5`),new Promise((_,r)=>setTimeout(()=>r(0),4000))]).then(j=>{
    const r=(j.results||[]).find(x=>albumKey(x.collectionName,x.artistName)===albumKey(m.t,m.a));
    if(r){info.copy=r.copyright||"";info.itLink=r.collectionViewUrl||"";if(!info.date&&r.releaseDate)info.date=r.releaseDate.slice(0,10);if(r.primaryGenreName)info.itGenre=r.primaryGenreName}
  }));
  if(m.ids.sp)tarefas.push(spGet(`/v1/albums/${m.ids.sp}`).then(d=>{
    if(d.label&&!info.label)info.label=d.label;
    if(d.release_date&&!info.date&&/^\d{4}-\d{2}-\d{2}$/.test(d.release_date))info.date=d.release_date;
    if(!info.copy&&(d.copyrights||[])[0])info.copy=d.copyrights[0].text||"";
    if(d.popularity!=null)info.pop=d.popularity;
  }));
  await Promise.allSettled(tarefas);
  if(!faixas.length){(await faixasDe(m)).forEach(t=>faixas.push(t))}
  const res={faixas,info};
  if(faixas.length)_dadosCache[ck]=res;
  return res;
}

/* ===== Página do álbum (redesenhada) ===== */
async function albumView(k){
  const m=S.meta[k];
  if(!m)return `<div class="empty">Open this album from search to load its data.</div>`;
  setAmb(cores(k)[0]);
  const ak=artistKey(m.a);
  if(!S.artists[ak]){S.artists[ak]={n:m.a,foto:"",fas:0,genre:"",info:"",ids:{},fontes:[]};salvar()}
  const x=dd(k);
  const {faixas,info}=await dadosAlbum(m);
  const fav=(P().fav||[]).includes(k);
  const cv=coverDe(k);
  const tipo=tipoLabel(m.tipo);
  const tipoTxt=tipo==="EP"?"EP":tipo.toLowerCase();
  const date=info.date||m.y||"";
  const total=faixas.reduce((s,t)=>s+(t.ms||0),0)||info.dur||0;
  const gens=[...new Set((info.genres&&info.genres.length?info.genres:[m.genre||info.itGenre]).filter(Boolean))];
  const kind=[tipo.toUpperCase(),...gens.slice(0,2)].join(" · ");
  const bits=[date?esc(fmtData(date)):"",faixas.length?`${faixas.length} ${faixas.length===1?"song":"songs"}`:"",total?durTxt(total):""].filter(Boolean);
  const metaHTML=bits.join(`<span class="dot">•</span>`)+(info.ex?`<i class="exb" title="Explicit">E</i>`:"");
  const maxRk=Math.max(1,...faixas.map(t=>t.rk||0));
  const r=(ic,l,v)=>v?`<div class="ai-r">${ico(ic,18)}<div style="min-width:0"><dt>${l}</dt><dd>${v}</dd></div></div>`:"";
  const artistas=(info.contrib&&info.contrib.length>1)?info.contrib:[m.a];
  const md=calcMedia(faixas.map(t=>tkey(t.t,m.a)));
  const quandoTxt=quando(date);
  const linhas=[
    r("disc","Type",esc(tipo)+(info.ex?" · Explicit":"")),
    r("calendar","Released",date?esc(fmtData(date))+(quandoTxt?` <span class="mut">· ${quandoTxt}</span>`:""):""),
    r("mic",artistas.length>1?"Artists":"Artist",artistas.map((n,i)=>i===0?`<a href="#artist-${ak}" style="border-bottom:1px solid rgba(255,255,255,.4)">${esc(n)}</a>`:esc(n)).join(", ")),
    r("tag","Label",esc(info.label||"")),
    r("note","Genre",esc(gens.join(", "))),
    r("list","Tracks",faixas.length?String(faixas.length):""),
    r("clock","Length",total?durTxt(total):""),
    r("people","Fans on Deezer",info.fans?fmtFas(info.fans):""),
    r("chart","Spotify popularity",info.pop!=null?info.pop+"/100":""),
    r("globe","Available on",esc((m.fontes||[]).map(nomeFonte).join(", "))),
    r("info","Barcode (UPC)",esc(info.upc||"")),
    r("listen","Your listen",x.d?esc(fmtData(x.d)):""),
    r("star","Your rating",x.r?`${estrelas(x.r)} <span class="mut">${x.r}</span>`:""),
    r("star","Track ratings",md.n?`${md.n} of ${faixas.length} rated · avg ${md.avg.toFixed(1)}`:"")
  ].join("");
  const apple=info.itLink||`https://music.apple.com/search?term=${encodeURIComponent(m.t+" "+m.a)}`;
  const links=[info.link?["Deezer",info.link]:null,["Apple Music",apple],m.ids.sp?["Spotify",`https://open.spotify.com/album/${m.ids.sp}`]:null].filter(Boolean)
    .map(([n,u])=>`<a class="btn" href="${esc(u)}" target="_blank" rel="noopener">${n} ${ico("external",13)}</a>`).join("");
  const sobre=`<h2>About this ${tipoTxt}</h2><div class="ainfo">
    <div class="ai-top">${capaAlbum(k,m.t,72)}<div style="min-width:0"><div class="ai-t">${esc(m.t)}</div><div class="ai-s">${esc(m.a)}${date?" · "+esc(String(date).slice(0,4)):""}</div></div></div>
    <dl class="ai-grid">${linhas}</dl>
    ${info.copy?`<p class="ai-copy">${esc(info.copy)}</p>`:""}
    <div class="ai-links">${links}</div></div>`;
  whenEl("#amore",()=>maisDoArtista(k,m,ak,info));
  return `${cv?`<div class="abg" aria-hidden="true"><div style="background-image:url(${cv})"></div></div>`:""}<div class="hero">${capaAlbum(k,m.t,230)}<div class="info">
    <div class="ah-kind">${esc(kind)}</div>
    <h1>${esc(m.t)}</h1>
    <a class="ah-art" href="#artist-${ak}">${esc(m.a)} ${ico("chev",14)}</a>
    <div class="ah-meta">${metaHTML}</div>
    <div class="abar">
      <button class="ab ${x.d?"on":""}" data-act="ouvi" title="${x.d?"Remove from diary":"Log in your diary"}">${ico("listen",18,!!x.d)}<span>${x.d?"Listened":"Log listen"}</span></button>
      <button class="ab ${x.w?"on":""}" data-act="quero" title="Listen later">${ico("queue",18,!!x.w)}<span>${x.w?"In queue":"Queue"}</span></button>
      <button class="ab ${x.l?"on":""}" data-act="curtir" title="Like">${likeInner(!!x.l)}</button>
      <button class="ab ${fav?"on":""}" data-act="fav" title="Favorite album">${ico("star",18,fav)}<span>Favorite</span></button>
    </div>
    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;justify-content:inherit"><div style="display:flex" id="rate" data-id="${k}">${rateHTML(x.r)}</div><span class="mut" id="rlab">${x.r?String(x.r)+" of 5":"Your rating"}</span></div>
    ${faixas.length?mediaBloco(faixas,m,x):""}${scoreHero(k)}
  </div></div>
  ${faixas.length?`<h2>Tracks</h2>${faixas.length>1?`<div class="tbar"><div class="tsearch"><input class="search" id="tsearch" type="search" placeholder="Search tracks in this album" autocomplete="off"></div>${xsel("tsort",[["n","Album order"],["az","Title A–Z"],["za","Title Z–A"],["long","Longest first"],["short","Shortest first"]],"n")}</div>`:""}<div class="mlist" id="tlist">${faixas.map((t,i)=>`<div class="row" data-tn="${esc(t.t.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase())}" data-i="${i}" data-ms="${t.ms||0}"><span class="num">${String(i+1).padStart(2,"0")}</span><div class="ttl grow">${esc(t.t)}${t.ex?`<i class="exb" title="Explicit">E</i>`:""}</div>${t.rk?`<span class="pop" title="Popularity"><i style="width:${Math.max(6,Math.round(t.rk/maxRk*100))}%"></i></span>`:""}<div class="tact">${trateHTML(t.t,m.a)}<button class="ib" data-play data-tt="${esc(t.t)}" data-ta="${esc(m.a)}" aria-label="Preview, video and links" title="Preview, video and links">${ico("play",12)}</button><button class="ib hv" data-story="musica" data-tt="${esc(t.t)}" data-ms="${t.ms||0}" aria-label="Share song" title="Share song">${ico("share",14)}</button></div><span class="mut sm tdur">${tempo(t.ms)}</span></div>`).join("")}<div class="tnone" id="tnone">No tracks found</div></div>`:`<div class="empty" style="margin-top:30px">No tracks available for this album.</div>`}
  <h2>Review</h2>
  <div class="lbx">
    <div class="lbx-h">${capaAlbum(k,m.t,64)}<div style="min-width:0"><div class="lbx-t">${esc(m.t)}</div><div class="lbx-s">${esc(m.a)}${m.y?` · ${m.y}`:""}</div></div></div>
    <label class="lbx-d"><span>Listened on</span><input type="date" id="revd" value="${esc(x.d||hoje())}" max="${hoje()}"></label>
    <textarea class="field" id="rev" placeholder="Add a review…">${esc(x.rev||"")}</textarea>
    <div class="lbx-f">
      <div class="lbx-r"><span class="mut sm">Rating</span><div style="display:flex" id="rate2">${rateHTML(x.r)}</div></div>
      <button class="ab ${x.l?"on":""}" data-act="revlike">${likeInner(!!x.l)}</button>
    </div>
    <div class="lbx-b"><button class="btn" data-act="rev">Save draft</button><button class="fab" data-soc="pub">${SOC.mine(k)?"Update review":"Publish review"}</button><button class="btn" data-story="album">${ico("share",14)} Share to Story</button></div>
  </div>
  <h2>Reviews</h2><div id="socrev">${socHTML(k)}</div>
  ${S.listas.length?`<h2>Add to a list</h2><div style="display:flex;gap:10px;flex-wrap:wrap">${xsel("lsel",S.listas.map((l,i)=>[String(i),l.nome]),"0")}<button class="btn" data-act="addLista">Add</button></div>`:`<h2>Lists</h2><div class="empty">Create a list in the Lists tab of your Profile to add albums.</div>`}
  ${sobre}
  <div id="amore"></div>`;
}
async function maisDoArtista(k,m,ak,info){
  const id=((S.artists[ak]||{}).ids||{}).dz||info.artistDz;
  if(!id)return;
  try{
    const j=await dz(`/artist/${id}/albums?limit=30`);
    const l=unirAlbuns((j.data||[]).map(x=>({src:"dz",id:x.id,t:x.title,a:m.a,y:(x.release_date||"").slice(0,4),tipo:x.record_type||"album",cover:x.cover_xl||x.cover_big||""}))).filter(u=>u.key!==k&&temCapa(u)).slice(0,14);
    const el=document.getElementById("amore");
    if(!l.length||!el)return;
    l.forEach(guardarAlbum);salvar();
    el.innerHTML=`<div class="sec-h"><h2>More by ${esc(m.a)}</h2></div><div class="carrossel" data-keep>${l.map(u=>cardAlbum({...u,solo:true})).join("")}</div>`;
  }catch(e){}
}
/* Curtir pela caixa de review atualiza os botões sem perder o texto digitado */
const _albumAct0=albumAct;
albumAct=function(a){
  if(a==="revlike"){
    const k=NAV.hash.slice(7),d=dd(k);d.l=!d.l;salvar();
    document.querySelectorAll('[data-act="revlike"],[data-act="curtir"]').forEach(b=>{b.classList.toggle("on",!!d.l);b.innerHTML=likeInner(!!d.l)});
    flash(d.l?"Liked":"Unliked");return;
  }
  return _albumAct0(a);
};

/* ===== Página do artista: ícones + informações no final ===== */
async function audioDB(n){
  try{
    const url=`https://www.theaudiodb.com/api/v1/json/2/search.php?s=${encodeURIComponent(n)}`;
    const j=await Promise.race([getJSON(url).catch(()=>PROXY?getJSON(PROXY+"/deezer?u="+encodeURIComponent(url)):Promise.reject(0)),new Promise((_,rj)=>setTimeout(()=>rj(0),5000))]);
    return (j.artists||[]).find(x=>norm(x.strArtist)===norm(n))||null;
  }catch(e){return null}
}
async function wikiArtista(n){
  try{
    const f=u=>Promise.race([getJSON(u),new Promise((_,rj)=>setTimeout(()=>rj(0),6000))]);
    const s=await f(`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(n+" musician band singer rapper")}&srlimit=3&format=json&origin=*`);
    for(const c of ((s.query||{}).search||[])){
      const nt=norm(c.title),nn=norm(n);
      if(!nt.includes(nn)&&!nn.includes(nt))continue;
      const r=await f(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(c.title.replace(/ /g,"_"))}`);
      if(r.type==="disambiguation")continue;
      if(!/singer|band|musician|rapper|duo|group|songwriter|composer|producer|DJ|vocalist|artist/i.test((r.description||"")+" "+(r.extract||"").slice(0,200)))continue;
      return {t:r.title,x:r.extract||"",u:((r.content_urls||{}).desktop||{}).page||""};
    }
  }catch(e){}
  return null;
}
async function infoArtista(k){
  const sel=`.ap[data-k="${k}"] #apinfo`;
  if(!document.querySelector(sel))return;
  const a=S.artists[k]||{},D=(window.__apC||{})[k]||{albuns:[],top:[],rel:[],gen:""};
  const C=(window.__aiC=window.__aiC||{});
  let I=C[k];
  if(!I){const [b,w]=await Promise.all([audioDB(a.n),wikiArtista(a.n)]);I=C[k]={b,w}}
  const el=document.querySelector(sel);
  if(!el)return;
  const b=I.b,w=I.w,albs=D.albuns||[];
  const tipoDe=u=>(u.tipo||"album").toLowerCase();
  const datas=albs.map(u=>u.d||u.y).filter(Boolean).sort();
  const first=datas[0],last=datas[datas.length-1];
  const nAlb=albs.filter(u=>tipoDe(u)==="album").length,nEp=albs.filter(u=>tipoDe(u)==="ep").length,nSin=albs.filter(u=>tipoDe(u)==="single").length;
  const gens=[...new Set([a.genre,...String(D.gen||"").split(", "),b&&b.strGenre,b&&b.strStyle].filter(Boolean))].slice(0,4);
  const bio=((w&&w.x)||(b&&(b.strBiographyEN||"").trim())||"").trim();
  const fonte=w&&w.x?`<a href="${esc(w.u)}" target="_blank" rel="noopener">Wikipedia</a> (CC BY-SA)`:"TheAudioDB";
  const r=(ic,l,v)=>v?`<div class="ai-r">${ico(ic,18)}<div style="min-width:0"><dt>${l}</dt><dd>${v}</dd></div></div>`:"";
  const lastAlb=albs.find(u=>(u.d||u.y)===last);
  const linhas=[
    r("pin","Origin",esc(b&&b.strCountry||"")),
    b&&b.intFormedYear&&b.intFormedYear!=="0"?r("calendar","Formed",esc(b.intFormedYear)):(b&&b.intBornYear&&b.intBornYear!=="0"?r("calendar","Born",esc(b.intBornYear)):""),
    r("calendar","Disbanded",esc(b&&b.intDiedYear&&b.intDiedYear!=="0"?b.intDiedYear:(b&&b.strDisbanded&&b.strDisbanded!=="0"?b.strDisbanded:""))),
    r("people","Members",esc(b&&b.intMembers&&b.intMembers!=="0"?b.intMembers:"")),
    r("note","Genre",esc(gens.join(", "))),
    r("info","Mood",esc(b&&b.strMood||"")),
    r("people","Fans on Deezer",a.fas?fmtFas(a.fas):""),
    r("disc","Releases",albs.length?`${albs.length} total <span class="mut">· ${nAlb} albums, ${nEp} EPs, ${nSin} singles</span>`:""),
    r("calendar","First release",first?esc(fmtData(first)):""),
    r("calendar","Latest release",last?esc(fmtData(last))+(lastAlb?` <span class="mut">· ${esc(lastAlb.t)}</span>`:""):""),
    r("play","Top song",D.top&&D.top[0]?esc(D.top[0].t):""),
    r("mic","Similar to",esc((D.rel||[]).slice(0,4).map(o=>o.n).join(", ")))
  ].join("");
  const L=[
    w&&w.u?["Wikipedia",w.u]:null,
    b&&b.strWebsite?["Website",urlOk(b.strWebsite)]:null,
    b&&b.strTwitter?["Twitter",urlOk(b.strTwitter)]:null,
    b&&b.strFacebook?["Facebook",urlOk(b.strFacebook)]:null,
    a.ids&&a.ids.dz?["Deezer",`https://www.deezer.com/artist/${a.ids.dz}`]:null,
    a.ids&&a.ids.sp?["Spotify",`https://open.spotify.com/artist/${a.ids.sp}`]:null,
    ["Apple Music",`https://music.apple.com/search?term=${encodeURIComponent(a.n)}`]
  ].filter(Boolean).map(([n,u])=>`<a class="btn" href="${esc(u)}" target="_blank" rel="noopener">${n} ${ico("external",13)}</a>`).join("");
  el.innerHTML=`${bio?`<div><p class="abio${bio.length>380?" cl":""}" id="abio">${esc(bio)}</p>${bio.length>380?`<button class="abio-more" data-abio>More</button>`:""}<div class="asrc">Source: ${fonte}</div></div>`:""}
    <dl class="ai-grid">${linhas}</dl><div class="ai-links">${L}</div>`;
}
const _artistView0=artistView;
artistView=async function(k){
  let html=await _artistView0(k);
  html=html.replace(/>···<\/button>/g,`>${ico("more",16)}</button>`)
    .replace('<span class="ap-chev">›</span>',`<span class="ap-chev">${ico("chev",22)}</span>`)
    .replace("▶ Play",`${ico("play",15)} Play`)
    .replace("<h2>About</h2>","<h2>Overview</h2>");
  const blk=`<div class="sec-h"><h2>Artist info</h2></div><div id="apinfo" class="ainfo"><div class="load" style="min-height:120px">…</div></div>`;
  html=html.replace(/<\/div><\/div>\s*$/,blk+"</div></div>");
  whenEl(`.ap[data-k="${k}"] #apinfo`,()=>infoArtista(k),80);
  return html;
};
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-abio]");if(!b)return;
  const p=document.getElementById("abio");if(!p)return;
  const cl=p.classList.toggle("cl");b.textContent=cl?"More":"Less";
});

;/* ---------- bloco 12 ---------- */
/* ===== Logos dos serviços (marcas simplificadas) ===== */
const TKLOGO={
  "Spotify":'<svg viewBox="0 0 42 42"><circle cx="21" cy="21" r="21" fill="#1DB954"/><g fill="none" stroke="#000" stroke-linecap="round"><path d="M10.5 16.2c6.6-1.9 13.6-1.3 19.4 2" stroke-width="3.2"/><path d="M12 22.6c5.4-1.5 10.9-1 15.6 1.6" stroke-width="2.8"/><path d="M13.4 28.4c4.2-1.1 8.2-.7 11.8 1.3" stroke-width="2.4"/></g></svg>',
  "Apple Music":'<svg viewBox="0 0 42 42"><defs><linearGradient id="tkam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FA5C70"/><stop offset="1" stop-color="#FA233B"/></linearGradient></defs><rect width="42" height="42" rx="10" fill="url(#tkam)"/><path d="M17 28.5V13.6l12-2.7v15" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="14.2" cy="28.8" r="3.3" fill="#fff"/><circle cx="26.2" cy="26.2" r="3.3" fill="#fff"/></svg>',
  "Deezer":'<svg viewBox="0 0 42 42"><rect width="42" height="42" rx="10" fill="#15151a"/><g><rect x="7" y="27" width="5.4" height="3.6" rx=".8" fill="#40ab5d"/><rect x="14" y="27" width="5.4" height="3.6" rx=".8" fill="#3fb6c0"/><rect x="21" y="27" width="5.4" height="3.6" rx=".8" fill="#5d86f2"/><rect x="28" y="27" width="5.4" height="3.6" rx=".8" fill="#a238ff"/><rect x="14" y="21.6" width="5.4" height="3.6" rx=".8" fill="#fdb913"/><rect x="21" y="21.6" width="5.4" height="3.6" rx=".8" fill="#3fb6c0"/><rect x="28" y="21.6" width="5.4" height="3.6" rx=".8" fill="#a238ff"/><rect x="21" y="16.2" width="5.4" height="3.6" rx=".8" fill="#ff8a00"/><rect x="28" y="16.2" width="5.4" height="3.6" rx=".8" fill="#ef5466"/><rect x="28" y="10.8" width="5.4" height="3.6" rx=".8" fill="#ef5466"/></g></svg>',
  "YouTube":'<svg viewBox="0 0 42 42"><rect x="3" y="9" width="36" height="24" rx="8" fill="#FF0000"/><path d="M17.5 15.3v11.4L27.6 21z" fill="#fff"/></svg>',
  "YouTube Music":'<svg viewBox="0 0 42 42"><circle cx="21" cy="21" r="21" fill="#FF0000"/><circle cx="21" cy="21" r="12.2" fill="none" stroke="#fff" stroke-width="2.4"/><path d="M18.2 15.8v10.4L27 21z" fill="#fff"/></svg>'
};
const TKPLAY=ico("play",22),TKPAUSE='<svg class="ic" viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"><rect x="6.5" y="4.8" width="4" height="14.4" rx="1.3"/><rect x="13.5" y="4.8" width="4" height="14.4" rx="1.3"/></svg>';

async function abrirFaixa(t,a,alb,cover){
  document.getElementById("trk")?.remove();
  const ov=document.createElement("div");ov.id="trk";
  const q=encodeURIComponent(`${t} ${a}`),nt=norm(t);
  ov.innerHTML=`<div class="tk-box"${cover?` style="--cv:url('${esc(cover)}')"`:""}>
    <div class="tk-glow"></div><div class="tk-shade"></div><div class="tk-scroll">
    <div class="tk-top"><button class="tk-x" data-trkx aria-label="Close">${'<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>'}</button></div>
    <div class="tk-head">${cover?`<img class="tk-art" src="${esc(cover)}" alt="">`:`<div class="tk-art">${esc(ini(t))}</div>`}
      <div class="tk-t">${esc(t)}</div><div class="tk-s">${esc(a)}${alb?" · "+esc(alb):""}</div></div>
    <div class="tk-sec"><div class="tk-lb">Preview</div><div id="tkprev"><div class="tk-note">Looking for a preview…</div></div></div>
    <div class="tk-sec"><div class="tk-lb">Music video</div><div id="tkyt"><div class="tk-ph"></div></div></div>
    <div class="tk-sec"><div class="tk-lb">Listen on</div><div class="tk-links" id="tklinks"></div></div></div></div>`;
  document.body.appendChild(ov);document.body.style.overflow="hidden";
  const L={},ytSearch=`https://www.youtube.com/results?search_query=${encodeURIComponent(t+" "+a+" official video")}`;
  const $$=s=>ov.querySelector(s);
  const pinta=()=>{const el=$$("#tklinks");if(!el)return;
    const it=[["Spotify",L.sp,`https://open.spotify.com/search/${q}`],["Apple Music",L.it,`https://music.apple.com/search?term=${q}`],["Deezer",L.dz,`https://www.deezer.com/search/${q}`],["YouTube",L.yt,ytSearch],["YouTube Music",null,`https://music.youtube.com/search?q=${q}`]];
    el.innerHTML=it.map(([n,d,f])=>`<a class="tk-ln${d?" ok":""}" href="${esc(d||f)}" target="_blank" rel="noopener"><span class="tk-lg">${TKLOGO[n]}</span><span class="tk-lt"><b>${n}</b><small>${d?"Open this track":"Search for it"}</small></span><span class="tk-go">${ico("external",15)}</span></a>`).join("")};
  pinta();
  const bate=x=>norm(x)===nt,prev={};
  const tarefas=[
    getJSON(`${IT}/search?term=${q}&entity=song&limit=6`).then(j=>{const r=j.results||[];const x=r.find(y=>bate(y.trackName))||r[0];if(x){L.it=x.trackViewUrl;prev.it=x.previewUrl}}),
    dz(`/search/track?q=${q}&limit=6`).then(j=>{const r=j.data||[];const x=r.find(y=>bate(y.title))||r[0];if(x){L.dz=x.link;prev.dz=x.preview}}),
    spOn()?spSearch(q).then(j=>{const r=((j.tracks||{}).items||[]).filter(Boolean);const x=r.find(y=>bate(y.name))||r[0];if(x){L.sp=(x.external_urls||{}).spotify||`https://open.spotify.com/track/${x.id}`;prev.sp=x.preview_url}}):Promise.resolve()
  ].map(p=>p.catch(()=>{}));
  Promise.all(tarefas).then(()=>{
    pinta();const el=$$("#tkprev");if(!el)return;
    const u=prev.dz||prev.it||prev.sp;
    if(!u){el.innerHTML=`<div class="tk-note">No preview available for this track.</div>`;return}
    el.innerHTML=`<div class="tk-pl"><button class="tk-pp" aria-label="Play">${TKPLAY}</button><div class="tk-col"><div class="tk-bar"><i class="tk-fill"></i></div><div class="tk-tm"><span class="tc">0:00</span><span class="td">0:30</span></div></div><audio preload="none" src="${esc(u)}"></audio></div>`;
    const au=el.querySelector("audio"),pp=el.querySelector(".tk-pp"),fl=el.querySelector(".tk-fill"),tc=el.querySelector(".tc"),br=el.querySelector(".tk-bar");
    const fmt=s=>Math.floor(s/60)+":"+String(Math.floor(s%60)).padStart(2,"0");
    pp.onclick=()=>{au.paused?au.play().catch(()=>{}):au.pause()};
    au.onplay=()=>{pp.innerHTML=TKPAUSE;pp.classList.add("on");ov.classList.add("pl")};
    au.onpause=()=>{pp.innerHTML=TKPLAY;pp.classList.remove("on");ov.classList.remove("pl")};
    au.onended=()=>{fl.style.width="0";tc.textContent="0:00"};
    au.onloadedmetadata=()=>{const d=el.querySelector(".td");if(d&&isFinite(au.duration))d.textContent=fmt(au.duration)};
    au.ontimeupdate=()=>{const d=au.duration||30;fl.style.width=(au.currentTime/d*100)+"%";tc.textContent=fmt(au.currentTime)};
    br.onclick=e=>{const r=br.getBoundingClientRect();au.currentTime=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width))*(au.duration||30)};
  });
  (async()=>{
    let id=null;
    for(const h of ["https://pipedapi.kavin.rocks","https://pipedapi.adminforge.de","https://api.piped.private.coffee"]){
      if(!ov.isConnected)return;
      try{
        const c=new AbortController(),to=setTimeout(()=>c.abort(),4500);
        const r=await fetch(`${h}/search?q=${encodeURIComponent(t+" "+a+" official video")}&filter=videos`,{signal:c.signal});clearTimeout(to);
        if(!r.ok)continue;
        const j=await r.json(),v=(j.items||[]).find(x=>x.url&&/v=/.test(x.url));
        if(v){id=v.url.split("v=")[1].split("&")[0];break}
      }catch(e){}
    }
    const el=$$("#tkyt");if(!el)return;
    if(id){L.yt=`https://www.youtube.com/watch?v=${id}`;pinta();
      el.innerHTML=`<div class="tk-yt"><iframe src="https://www.youtube-nocookie.com/embed/${id}" allow="accelerometer;encrypted-media;picture-in-picture;fullscreen" allowfullscreen loading="lazy"></iframe></div><div class="tk-hint">Best match found automatically. It may not be the official clip.</div>`;
    }else el.innerHTML=`<div class="tk-note">Couldn't load a video here. <a href="${ytSearch}" target="_blank" rel="noopener">Search on YouTube</a></div>`;
  })();
}

;/* ---------- bloco 13 ---------- */
/* ===== Camada social (local por enquanto) =====
   Tudo passa pelo objeto SOC. Quando o banco de dados existir, basta trocar os métodos
   me / list / publish / unpublish / like / friends abaixo por chamadas à API. */
const DEMOF=[["marina.sol","Marina Sol"],["caio.vinil","Caio Vinil"],["bia.reverb","Bia Reverb"],["theo.lofi","Theo Lofi"],["duda.fm","Duda FM"],["lu.analog","Lu Analog"]];
const DEMOT=["Solid front to back, a few tracks I keep replaying.","Not what I expected, but it grew on me.","The production is incredible. Headphones recommended.","A couple of skips, but the highs are really high.","Instant favorite of the year for me.","Pleasant, a bit safe. Nice for background listening.","The second half is where it really shines.","Overhyped IMO, but I get why people love it."];
const SOC={
  s(){S.soc=S.soc||{};S.soc.amigos=S.soc.amigos||[];S.soc.rev=S.soc.rev||[];S.soc.likes=S.soc.likes||{};return S.soc},
  me(){const p=P();return {h:p.handle,n:p.nome,av:p.avatar||""}},
  isFriend(h){return this.s().amigos.some(a=>a.h===h)},
  demoRev(k){
    if(!this.s().demo)return [];
    return DEMOF.map(([h,n])=>{
      const x=parseInt(hash(k+h),36);
      if(x%100>=70)return null;
      const r=[2.5,3,3.5,3.5,4,4,4.5,5,2,3][x%10];
      return {id:"d"+hash(k+h),k,u:h,n,av:"",r,txt:x%3?DEMOT[x%DEMOT.length]:"",d:new Date(Date.now()-(x%60)*864e5).toISOString().slice(0,10),demo:1,base:x%12};
    }).filter(Boolean);
  },
  list(k){return [...this.s().rev.filter(x=>x.k===k),...this.demoRev(k)]},
  mine(k){const h=this.me().h;return this.s().rev.find(x=>x.k===k&&x.u===h)||null},
  publish(k,r,txt,d){
    const me=this.me(),s=this.s(),id="m"+hash(k+me.h),i=s.rev.findIndex(x=>x.id===id);
    const rv={id,k,u:me.h,n:me.n,av:me.av,r:r||0,txt,d};
    if(i>=0)s.rev[i]=rv;else s.rev.push(rv);
    salvar();
  },
  unpublish(id){const s=this.s();s.rev=s.rev.filter(x=>x.id!==id);salvar()},
  likes(rv){return (rv.base||0)+(this.s().likes[rv.id]||[]).length},
  liked(rv){return (this.s().likes[rv.id]||[]).includes(this.me().h)},
  like(id){const s=this.s(),l=s.likes[id]||(s.likes[id]=[]),h=this.me().h,i=l.indexOf(h);if(i>=0)l.splice(i,1);else l.push(h);salvar()},
  addFriend(h){h=String(h||"").trim().replace(/^@/,"").toLowerCase();if(!h)return"empty";const s=this.s();if(h===this.me().h.toLowerCase())return"self";if(s.amigos.some(a=>a.h===h))return"dup";const d=DEMOF.find(x=>x[0]===h);s.amigos.push({h,n:d?d[1]:h});salvar();return"ok"},
  rmFriend(h){const s=this.s();s.amigos=s.amigos.filter(a=>a.h!==h);salvar()},
  toggleDemo(){const s=this.s();s.demo=!s.demo;if(s.demo){DEMOF.slice(0,4).forEach(([h,n])=>{if(!s.amigos.some(a=>a.h===h))s.amigos.push({h,n})})}else{s.amigos=s.amigos.filter(a=>!DEMOF.some(d=>d[0]===a.h))}salvar()}
};
/* ===== Feed de atividade (você + amigos, cruzando todos os álbuns conhecidos) =====
   Hoje só existe o que está salvo neste navegador (suas próprias publicações) mais as
   avaliações demo dos amigos de mentira, quando o modo demo está ligado — mesma limitação
   do socHTML. Quando o banco de dados existir, troque feedItens() por uma chamada à API
   que já traga a atividade de quem você segue de verdade. */
function feedItens(){
  const me=SOC.me().h,keys=Object.keys(S.meta);
  let itens=[];
  keys.forEach(k=>{SOC.list(k).forEach(rv=>{if(rv.u===me||SOC.isFriend(rv.u))itens.push(rv)})});
  itens.sort((a,b)=>b.d.localeCompare(a.d));
  return itens.slice(0,40);
}
function feedCard(rv){
  const me=SOC.me().h,eu=rv.u===me,[c1,c2]=cores(rv.u),av=eu?SOC.me().av:rv.av,lk=SOC.liked(rv);
  const m=S.meta[rv.k]||{t:"Album",a:""},cv=coverDe(rv.k),[ca,cb]=cores(rv.k);
  return `<div class="rv"><div class="rv-av" style="background:linear-gradient(145deg,${c1},${c2})">${av?`<img src="${esc(av)}" alt="">`:esc(ini(rv.n))}</div><div class="rv-b">
    <a href="#album-${rv.k}" class="feed-alb"><div class="cover" style="width:34px;height:34px;border-radius:8px;flex-shrink:0;font-size:12px;background:linear-gradient(145deg,${ca},${cb})">${cv?`<img src="${cv}" alt="" loading="lazy" onerror="this.remove()">`:`<span>${esc(ini(m.t))}</span>`}</div><span class="feed-alb-t">${esc(m.t)}${m.a?" · "+esc(m.a):""}</span></a>
    <div class="rv-h"><b>${esc(eu?"You":rv.n)}</b><span class="mut sm">@${esc(rv.u)}</span>${rv.r?estrelas(rv.r):""}<span class="mut sm">${esc(fmtData(rv.d))}</span>${rv.demo?`<i class="rv-demo">Demo</i>`:""}</div>
    ${rv.txt?`<p class="rv-t">${esc(rv.txt)}</p>`:""}
    <div class="rv-f"><button class="rv-l ${lk?"on":""}" data-feedlike="${rv.id}" aria-label="Like review">${ico("heart",14,lk)} ${SOC.likes(rv)}</button></div></div></div>`;
}
function feedHTML(){
  const itens=feedItens(),me=SOC.me().h;
  const vazio=SOC.s().amigos.length?`Nothing from you or your friends yet. Publish a review or rate an album to see it here.`:`You haven't added friends yet. <a href="#@${encodeURIComponent(me)}" data-gofriends>Add them on your Profile</a>, or publish a review of your own.`;
  return `<h1>Feed</h1><div id="feedlist">${itens.length?itens.map(feedCard).join(""):`<div class="empty">${vazio}</div>`}</div><p class="rvnote">The feed shows your own published reviews and your friends' activity. Reviews are stored only in this browser for now — when the database is connected, this will include real activity from everyone you follow.</p>`;
}
function renderFeed(){const el=document.getElementById("feedlist");if(!el)return;const itens=feedItens();el.innerHTML=itens.length?itens.map(feedCard).join(""):el.innerHTML}
function socStats(k){
  const me=SOC.me().h,lista=SOC.list(k).filter(x=>x.r),rs=lista.map(x=>x.r);
  const myr=(S.u[k]||{}).r;
  if(myr&&!lista.some(x=>x.u===me))rs.push(myr);
  const n=rs.length,avg=n?rs.reduce((a,b)=>a+b,0)/n:0;
  const hist=[.5,1,1.5,2,2.5,3,3.5,4,4.5,5].map(v=>rs.filter(r=>r===v).length);
  const fr=lista.filter(x=>SOC.isFriend(x.u)),fa=fr.length?fr.reduce((a,b)=>a+b.r,0)/fr.length:0;
  return {n,avg,pct:Math.round(avg/5*100),hist,fn:fr.length,fpct:Math.round(fa/5*100)};
}
function ringSVG(p,w,vazio){
  const R=w/2-5,C=2*Math.PI*R,c=w/2;
  return `<svg class="ring" width="${w}" height="${w}" viewBox="0 0 ${w} ${w}" aria-hidden="true"><circle cx="${c}" cy="${c}" r="${R}" fill="none" stroke="rgba(255,255,255,.14)" stroke-width="5"/>${vazio?"":`<circle cx="${c}" cy="${c}" r="${R}" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C*(1-p/100)}" transform="rotate(-90 ${c} ${c})"/>`}<text x="50%" y="50%" text-anchor="middle" dominant-baseline="central" fill="#fff" font-size="${Math.round(w*.27)}" font-weight="700" font-family="Inter,Helvetica,Arial,sans-serif">${vazio?"—":p+"%"}</text></svg>`;
}
function scoreHero(k){
  const s=socStats(k);
  return `<div class="scorebox">${ringSVG(s.pct,58,!s.n)}<div><div class="sc-t">${s.n?s.pct+"% community score":"No score yet"}</div><div class="sc-s">${s.n?`${s.avg.toFixed(1)} avg · ${s.n} rating${s.n>1?"s":""}`:"Rate or publish a review to start"}</div></div></div>`;
}
function rvCard(rv){
  const me=SOC.me().h,eu=rv.u===me,[c1,c2]=cores(rv.u),av=eu?SOC.me().av:rv.av,lk=SOC.liked(rv);
  return `<div class="rv"><div class="rv-av" style="background:linear-gradient(145deg,${c1},${c2})">${av?`<img src="${esc(av)}" alt="">`:esc(ini(rv.n))}</div><div class="rv-b">
    <div class="rv-h"><b>${esc(eu?"You":rv.n)}</b><span class="mut sm">@${esc(rv.u)}</span>${rv.r?estrelas(rv.r):""}<span class="mut sm">${esc(fmtData(rv.d))}</span>${rv.demo?`<i class="rv-demo">Demo</i>`:""}</div>
    ${rv.txt?`<p class="rv-t">${esc(rv.txt)}</p>`:""}
    <div class="rv-f"><button class="rv-l ${lk?"on":""}" data-soc="like" data-id="${rv.id}" aria-label="Like review">${ico("heart",14,lk)} ${SOC.likes(rv)}</button>${eu?`<button class="rv-l" data-soc="unpub" data-id="${rv.id}">Remove</button>`:""}</div></div></div>`;
}
function socHTML(k){
  const s=socStats(k),tab=window.__socTab||"friends",me=SOC.me().h;
  const all=SOC.list(k).sort((a,b)=>b.d.localeCompare(a.d));
  const sets={friends:all.filter(x=>SOC.isFriend(x.u)&&x.u!==me),all:all,you:all.filter(x=>x.u===me)};
  const lab={friends:"Friends",all:"Everyone",you:"You"};
  const mx=Math.max(1,...s.hist),lbl=["½","1","","2","","3","","4","","5"];
  const bars=s.hist.map((c,i)=>`<div class="mb" title="${(i+1)/2} stars: ${c} rating${c===1?"":"s"}${s.n?" ("+Math.round(c/s.n*100)+"%)":""}"><b>${c||""}</b><i style="height:${Math.max(c?6:2,Math.round(c/mx*60))}px;${c?"":"opacity:.25"}"></i><span>${lbl[i]}</span></div>`).join("");
  const lista=sets[tab];
  const vazio=tab==="friends"?(SOC.s().amigos.length?`None of your friends reviewed this yet.`:`You haven't added friends yet. <a href="#@${encodeURIComponent(me)}" data-gofriends>Add them on your Profile</a>.`):tab==="you"?`You haven't published a review for this album.`:`No reviews yet. Be the first to publish one.`;
  return `<div class="socbox"><div class="sb-l">${ringSVG(s.pct,92,!s.n)}<small>Community score</small></div>
    <div><div class="mbars">${bars}</div><div class="sb-fr"><span><strong>${s.n}</strong> rating${s.n===1?"":"s"}</span>${s.n?`<span><strong>${s.avg.toFixed(2)}</strong> / 5 avg</span>`:""}${s.fn?`<span>Friends: <strong>${s.fpct}%</strong> (${s.fn})</span>`:""}</div></div></div>
  <div class="rvtabs">${["friends","all","you"].map(t=>`<button class="${tab===t?"on":""}" data-soc="tab" data-t="${t}">${lab[t]} · ${sets[t].length}</button>`).join("")}</div>
  ${lista.length?`<div>${lista.map(rvCard).join("")}</div>`:`<div class="rvempty">${vazio}</div>`}
  <p class="rvnote">Reviews are stored only in this browser for now. When the database is connected, friends' reviews will show up here for real.</p>`;
}
function renderSoc(k){const el=document.getElementById("socrev");if(el)el.innerHTML=socHTML(k)}
function amigosHTML(){
  const s=SOC.s();
  const rows=s.amigos.map(a=>{const [c1,c2]=cores(a.h);return `<div class="row"><div class="rv-av" style="width:40px;height:40px;background:linear-gradient(145deg,${c1},${c2})">${esc(ini(a.n))}</div><div class="grow"><div class="ttl">${esc(a.n)}${DEMOF.some(d=>d[0]===a.h)&&s.demo?` <i class="rv-demo">Demo</i>`:""}</div><div class="sm mut">@${esc(a.h)}</div></div><button class="mv" data-soc="friend-rm" data-h="${esc(a.h)}" aria-label="Remove friend">×</button></div>`}).join("");
  return `<div id="friends"></div><h2>Friends</h2><div class="mlist">${rows||`<div class="empty" style="border-radius:0">No friends yet.</div>`}<div class="row" style="gap:10px"><input class="field" id="friendin" placeholder="Friend's username" autocomplete="off"><button class="fab" data-soc="friend-add">Add</button></div></div>
  <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px"><button class="btn ${s.demo?"on":""}" data-soc="demo">${s.demo?"Remove demo friends":"Load demo friends"}</button></div>
  <p class="rvnote">Demo friends are made-up sample reviews so you can see how the feed and the percentage look. They disappear when you remove them.</p>`;
}
const _extraPerfil0=extraPerfil;
extraPerfil=function(){return _extraPerfil0()+(aba==="perfil"?amigosHTML():"")};

document.addEventListener("click",e=>{
  const b=e.target.closest("[data-soc]");
  if(!b)return;
  const a=b.dataset.soc,k=NAV.hash.slice(7);
  if(a==="pub"){
    const d=dd(k),txt=((document.getElementById("rev")||{}).value||d.rev||"").trim(),dv=(document.getElementById("revd")||{}).value;
    if(!d.r&&!txt){flash("Add a rating or write a review first");return}
    d.rev=txt;d.d=dv||d.d||hoje();
    const novo=!SOC.mine(k);SOC.publish(k,d.r||0,txt,d.d);
    flash(novo?"Review published":"Review updated");rota();return;
  }
  if(a==="unpub"){SOC.unpublish(b.dataset.id);flash("Review removed");rota();return}
  if(a==="like"){SOC.like(b.dataset.id);renderSoc(k);return}
  if(a==="tab"){window.__socTab=b.dataset.t;renderSoc(k);return}
  if(a==="friend-add"){
    const inp=document.getElementById("friendin"),r=SOC.addFriend(inp&&inp.value);
    flash({ok:"Friend added",dup:"Already your friend",self:"That's you",empty:"Type a username"}[r]);
    if(r==="ok")rota();return;
  }
  if(a==="friend-rm"){SOC.rmFriend(b.dataset.h);flash("Friend removed");rota();return}
  if(a==="demo"){SOC.toggleDemo();flash(SOC.s().demo?"Demo friends loaded":"Demo friends removed");rota();return}
});
document.addEventListener("click",e=>{
  if(e.target.closest("[data-gofriends]")){aba="perfil";setTimeout(()=>{const f=document.getElementById("friends");if(f)f.scrollIntoView({behavior:"smooth"})},150)}
});
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-feedlike]");
  if(!b)return;
  SOC.like(b.dataset.feedlike);renderFeed();
});

;/* ---------- bloco 14 ---------- */
/* ===== v5: ícones extras ===== */
Object.assign(ICP,{
  shuffle:'<path d="M16 4h4v4M4 20L20 4M20 16v4h-4M15 15l5 5M4 4l5 5"/>',
  trend:'<path d="M3 17l6-6 4 4 8-8M15 7h6v6"/>',
  x:'<path d="M6 6l12 12M18 6L6 18"/>'
});
const hl=(t,q)=>{t=String(t||"");q=String(q||"").trim();const i=q?t.toLowerCase().indexOf(q.toLowerCase()):-1;return i<0?esc(t):esc(t.slice(0,i))+"<mark>"+esc(t.slice(i,i+q.length))+"</mark>"+esc(t.slice(i+q.length))};
const TRENDS_FIXO=["Radiohead","Kendrick Lamar","Tame Impala","Frank Ocean","Beyoncé","Daft Punk","Billie Eilish","Tyler, The Creator"];
function saveRecent(q){q=String(q||"").trim();if(q.length<2)return;S.recent=[q,...(S.recent||[]).filter(x=>x.toLowerCase()!==q.toLowerCase())].slice(0,8);salvar()}
function trendList(n){const ch=[...new Set((window.__chart||[]).map(x=>x.artist&&x.artist.name).filter(Boolean))].slice(0,n);return ch.length>=4?ch:TRENDS_FIXO.slice(0,n)}
const queueKeys=()=>Object.entries(S.u).filter(([k,v])=>v.w&&S.meta[k]).map(([k])=>k);

/* ===== v5: seguir / seguir de volta ===== */
SOC.following=function(){return this.s().amigos};
SOC.followers=function(){return this.s().demo?[0,2,4,5].map(i=>({h:DEMOF[i][0],n:DEMOF[i][1]})):[]};
SOC.followsMe=function(h){return this.followers().some(x=>x.h===h)};
SOC.buscar=function(q){
  const nq=norm(q),me=this.me().h.toLowerCase(),s=this.s(),pool=new Map();
  [...s.amigos,...this.followers(),...(s.demo?DEMOF.map(([h,n])=>({h,n})):[])].forEach(a=>{if(a.h!==me&&!pool.has(a.h))pool.set(a.h,a)});
  const out=[...pool.values()].filter(a=>norm(a.h).includes(nq)||norm(a.n).includes(nq));
  const raw=String(q).trim();
  if(raw[0]==="@"){const h=raw.slice(1).toLowerCase();if(/^[a-z0-9._]{3,30}$/.test(h)&&h!==me&&!pool.has(h))out.push({h,n:h})}
  return out.slice(0,20);
};
function fbtnHTML(h,n){
  const on=SOC.isFriend(h),fm=SOC.followsMe(h);
  return `<button class="fbtn${on?" on":""}" data-fo="${esc(h)}" data-fn="${esc(n)}">${on?`<span class="a">${ico("check",13)} Following</span><span class="b">Unfollow</span>`:(fm?"Follow back":"Follow")}</button>`;
}
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-fo]");if(!b)return;
  e.preventDefault();
  const h=b.dataset.fo,n=b.dataset.fn||h;
  if(SOC.isFriend(h)){SOC.rmFriend(h);flash("Unfollowed @"+h)}
  else{const s=SOC.s();s.amigos.push({h,n});salvar();flash(SOC.followsMe(h)?"Following back @"+h:"Following @"+h)}
  if(document.querySelector(".pf")){rota();return}
  document.querySelectorAll(`[data-fo="${CSS.escape(h)}"]`).forEach(x=>{x.outerHTML=fbtnHTML(h,n)});
  hdrSync();
});
document.addEventListener("click",e=>{const b=e.target.closest("[data-pp]");if(b)window.__pp=b.dataset.pp},true);
document.addEventListener("click",e=>{const b=e.target.closest("[data-ppt]");if(b){window.__pp=b.dataset.ppt;rota()}});
document.addEventListener("keydown",e=>{if(e.key==="Enter"&&e.target.id==="friendin"){e.preventDefault();const b=document.querySelector('[data-soc="friend-add"]');if(b)b.click()}});

function pfPerson(a){
  const [c1,c2]=cores(a.h),fm=SOC.followsMe(a.h);
  return `<div class="row"><div class="pf-av" style="background:linear-gradient(145deg,${c1},${c2})">${esc(ini(a.n))}</div><div class="grow"><div class="ttl">${esc(a.n)}</div><div class="sm mut">@${esc(a.h)}${fm?`<i class="pp-tag">Follows you</i>`:""}</div></div>${fbtnHTML(a.h,a.n)}</div>`;
}
function pfPessoas(){
  const s=SOC.s(),sub=window.__pp||"seguindo",fo=SOC.following(),fr=SOC.followers();
  const lista=sub==="seguidores"?fr:fo;
  const vazio=sub==="seguidores"?`Nobody follows you yet. Share your profile so people can find you.`:`You're not following anyone yet. Search a username below or in the Search tab (use @username).`;
  const sug=s.demo?DEMOF.map(([h,n])=>({h,n})).filter(a=>!SOC.isFriend(a.h)&&!SOC.followsMe(a.h)):[];
  const back=sub==="seguindo"?[]:fr.filter(a=>!SOC.isFriend(a.h));
  return `<div id="friends"></div>
  <div class="rvtabs" style="margin-top:26px"><button class="${sub==="seguindo"?"on":""}" data-ppt="seguindo">Following · ${fo.length}</button><button class="${sub==="seguidores"?"on":""}" data-ppt="seguidores">Followers · ${fr.length}</button></div>
  ${back.length?`<p class="rvnote" style="margin:0 2px 10px">${back.length} follower${back.length>1?"s":""} you don't follow back yet.</p>`:""}
  <div class="mlist">${lista.length?lista.map(pfPerson).join(""):`<div class="empty" style="border-radius:0;border:0">${vazio}</div>`}
    <div class="pp-find"><input id="friendin" placeholder="Follow by username (e.g. marina.sol)" autocomplete="off" autocapitalize="none" spellcheck="false"><button class="fbtn" data-soc="friend-add">Follow</button></div></div>
  ${sug.length?`<h2>Suggested</h2><div class="mlist">${sug.map(pfPerson).join("")}</div>`:""}
  <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px"><button class="btn ${s.demo?"on":""}" data-soc="demo">${s.demo?"Remove demo people":"Load demo people"}</button></div>
  <p class="rvnote">There is no server yet, so people are stored only in this browser. Demo people are made-up samples: some follow you, so you can try "Follow back". When the database is connected, this will use real accounts.</p>`;
}
function pfOverview(){
  const p=P(),fav=p.fav||[],av=Object.entries(S.u).filter(([k,v])=>v.r&&S.meta[k]);
  const slot=i=>fav[i]?`<a class="fitem" href="#album-${fav[i]}">${capaAlbum(fav[i],(S.meta[fav[i]]||{}).t,null)}<div class="ttl" style="margin-top:8px">${esc((S.meta[fav[i]]||{}).t||"")}</div></a>`:`<div class="fvazio">Empty</div>`;
  const nPag=Math.max(1,Math.ceil(fav.length/4));
  const slots=`<div class="favpages" id="favpages">${Array.from({length:nPag},(_,pg)=>`<div class="favpage">${[0,1,2,3].map(j=>slot(pg*4+j)).join("")}</div>`).join("")}</div>${nPag>1?`<div class="favdots">${Array.from({length:nPag},(_,n)=>`<button class="${n===0?"on":""}" data-favpg="${n}" aria-label="Group ${n+1}"></button>`).join("")}</div>`:""}`;
  const mus=p.musicas.length?`<div class="mlist">${p.musicas.map((m,i)=>`<div class="row"><span class="num">${String(i+1).padStart(2,"0")}</span><div class="ttl grow">${esc(m)}</div></div>`).join("")}</div>`:`<div class="empty">Add favorite songs in Edit.</div>`;
  const recs=av.slice(-5).reverse();
  const rec=recs.length?`<div class="mlist">${recs.map(([k,v])=>{const m=S.meta[k];return `<a class="row" href="#album-${k}">${capaAlbum(k,m.t,46)}<div class="grow"><div class="ttl">${esc(m.t)}</div><div class="sm mut">${esc(m.a)}</div></div>${estrelas(v.r)}</a>`}).join("")}</div>`:`<div class="empty">No ratings yet.</div>`;
  const dist=[.5,1,1.5,2,2.5,3,3.5,4,4.5,5].map(n=>{const c=av.filter(([,v])=>v.r===n).length;return `<div class="hrow"><span>${String(n)}</span><div class="hbar"><i style="width:${av.length?c/av.length*100:0}%"></i></div><span class="mut">${c}</span></div>`}).join("");
  const cont={};av.forEach(([k])=>{const a=S.meta[k].a;cont[a]=(cont[a]||0)+1});
  const topA=Object.entries(cont).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const segA=(S.seguindo||[]);
  return `<div class="pgrid"><div><h3 class="sec">Favorite albums${fav.length>4?` <span style="text-transform:none;letter-spacing:0;font-weight:600">· ${fav.length}</span>`:""}</h3>${slots}<h3 class="sec" style="margin-top:34px">Favorite songs</h3>${mus}</div><aside><h3 class="sec">Recent ratings</h3>${rec}</aside></div>
  ${segA.length?`<h2>Artists you follow</h2><div class="pf-arl">${segA.map(s=>`<a class="pf-a" href="#artist-${s.k}">${capaFoto((S.artists[s.k]||{}).foto||"",s.n,64,true)}<span>${esc(s.n)}</span></a>`).join("")}</div>`:""}
  ${topA.length?`<h2>Top artists</h2><div class="mlist">${topA.map(([n,c],i)=>`<a class="row" href="#artist-${artistKey(n)}"><span class="num">${i+1}</span><div class="grow"><div class="ttl">${esc(n)}</div><div class="sm mut">${c} album${c>1?"s":""} rated</div></div><span class="mut">${ico("chev",16)}</span></a>`).join("")}</div>`:""}
  ${av.length?`<h2>Rating distribution</h2><div class="hist2">${dist}</div>`:""}
  ${backupHTML()}`;
}
function pfRatings(){
  const av=Object.entries(S.u).filter(([,v])=>v.r);
  const faixas=Object.entries(S.tracks||{}).filter(([k])=>S.u[k]&&S.u[k].r).sort((a,b)=>S.u[b[0]].r-S.u[a[0]].r).slice(0,20);
  const alb=av.filter(([k])=>S.meta[k]).length?`<div class="mlist" style="margin-top:24px">${[...av].filter(([k])=>S.meta[k]).reverse().map(([k,v])=>{const m=S.meta[k];return `<a class="row" href="#album-${k}" style="display:block"><div style="display:flex;align-items:center;gap:14px">${capaAlbum(k,m.t,46)}<div class="grow"><div class="ttl">${esc(m.t)}</div><div class="sm mut">${esc(m.a)}</div></div>${estrelas(v.r)}</div>${v.rev?`<div style="font-weight:500;padding:10px 0 0 60px;line-height:1.45">${esc(v.rev)}</div>`:""}</a>`}).join("")}</div>`:`<div class="empty" style="margin-top:24px">You haven't rated any album yet.</div>`;
  return alb+(faixas.length?`<h2>Rated songs</h2><div class="mlist">${faixas.map(([k,v])=>`<div class="row"><div class="grow"><div class="ttl">${esc(v.t)}</div><div class="sm mut">${esc(v.a)}</div></div>${estrelas(S.u[k].r)}</div>`).join("")}</div>`:"");
}
function pfListas(){
  return `<div class="mlist" style="margin-top:24px">${S.listas.map((l,i)=>`<a class="row" href="#lista-${i}"><div class="grow"><div class="ttl">${esc(l.nome)}</div><div class="sm mut">${l.ids.length} album${l.ids.length===1?"":"s"}</div></div><span class="mut">${ico("chev",16)}</span></a>`).join("")||`<div class="empty" style="border-radius:0;border:0">No lists yet.</div>`}<div class="row" style="gap:10px"><input class="field" id="nlNew" placeholder="New list name"><button class="fab" data-lst="nova">Create</button></div></div>`;
}
perfilView=function(){
  const p=P(),fav=p.fav||[];
  const av=Object.entries(S.u).filter(([,v])=>v.r);
  const ouv=Object.values(S.u).filter(v=>v.d).length;
  const media=av.length?av.reduce((s,[,v])=>s+v.r,0)/av.length:0;
  const [c1,c2]=fav[0]?cores(fav[0]):cores(p.handle||"trackly");
  const banner=p.banner?`<div class="pban"><div class="art img" style="background-image:url(${p.banner})"></div></div>`:`<div class="pban"><div class="art" style="background:linear-gradient(135deg,${c1},${c2})"></div></div>`;
  const avatar=p.avatar?`<img src="${p.avatar}" alt="">`:`<div style="width:100%;height:100%;background:linear-gradient(145deg,${c1},${c2});display:grid;place-items:center">${esc(ini(p.nome))}</div>`;
  const cell=(n,l,t,pp)=>`<button class="pf-st" data-aba="${t}"${pp?` data-pp="${pp}"`:""}><strong>${n}</strong><span>${l}</span></button>`;
  const stats=[cell(ouv,"Listened","diario"),cell(av.length,"Ratings","avaliacoes"),cell(media?media.toFixed(1):"—","Average","stats"),cell(S.listas.length,"Lists","listas"),cell(SOC.following().length,"Following","pessoas","seguindo"),cell(SOC.followers().length,"Followers","pessoas","seguidores")].join("");
  const tabs=[["perfil","Overview"],["avaliacoes","Ratings"],["diario","Diary"],["fila","Queue"],["stats","Stats"],["listas","Lists"],["pessoas","People"]];
  let corpo="";
  if(aba==="perfil")corpo=pfOverview();
  else if(aba==="avaliacoes")corpo=pfRatings();
  else if(aba==="diario")corpo=`<div style="margin-top:24px">${diaryList()}</div>`;
  else if(aba==="fila")corpo=filaView();
  else if(aba==="stats")corpo=statsView();
  else if(aba==="pessoas")corpo=pfPessoas();
  else corpo=pfListas();
  return `<div class="pf">${banner}<div class="pf-head"><div class="pav">${avatar}</div>
    <div class="pf-id"><h1>${esc(p.nome)}</h1><div class="phandle">@${esc(p.handle)}${p.local?" · "+esc(p.local):""}</div></div>
    <div class="pf-act"><button class="btn p" data-pact="editar">Edit profile</button><button class="btn" data-pact="cartao">Story</button><button class="shbtn" data-pact="compartilhar" aria-label="Share" title="Share">${ico("share",17)}</button></div></div>
  ${p.bio?`<p class="pbio pf-bio">${esc(p.bio)}</p>`:""}
  <div class="pf-stats">${stats}</div>
  <nav class="ptabs">${tabs.map(([k,l])=>`<button class="${aba===k?"on":""}" data-aba="${k}">${l}</button>`).join("")}</nav>
  <div class="pf-body">${corpo}</div></div>`;
};

;/* ---------- bloco 15 ---------- */
/* ===== v5: busca profissional (página) ===== */
let SQ_SORT="rel",SQ_TYPE="all";
const SQ_LBL={tudo:"All",albuns:"Albums & EPs",musicas:"Songs",artistas:"Artists",pessoas:"People"};
const SQ_ICON='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg>';
searchView=function(){
  return `<h1>Search</h1>
  <div class="sp-bar${busca.q?" has":""}" id="spbar">${SQ_ICON}<input class="sp-in" id="q" type="text" enterkeyhint="search" placeholder="Artists, albums, songs, people" autocomplete="off" autocapitalize="none" spellcheck="false" value="${esc(busca.q)}"><button class="sp-x" data-sqx aria-label="Clear">${ico("x",15)}</button></div>
  <div class="chips sp-chips">${Object.entries(SQ_LBL).map(([k,l])=>`<button class="chip ${busca.f===k?"on":""}" data-fl="${k}">${l}</button>`).join("")}</div>
  <div id="res" style="margin-top:20px"></div>`;
};
function sqData(q,coleta){
  const albuns=unirAlbuns(coleta.alb);albuns.forEach(guardarAlbum);
  const artistas=unirArtistas(coleta.art);artistas.forEach(guardarArtista);
  return {albuns,artistas,musicas:dedupMusicas(coleta.mus).slice(0,30),pessoas:SOC.buscar(q)};
}
function sqSong(m,i,q){
  const k=albumKey(m.album.t,m.album.a);
  return `<div class="row"><a class="sq-l" href="#album-${k}">${capaAlbum(k,m.album.t,46)}<span><span class="ttl">${hl(m.titulo,q)}</span><span class="sq-s">${esc(m.artista)} · ${esc(m.album.t)}</span></span></a><span class="mut sm tdur">${tempo(m.ms)}</span><button class="ib" data-sqplay="${i}" aria-label="Preview, video and links" title="Preview, video and links">${ico("play",12)}</button></div>`;
}
function sqPessoa(p){
  const [c1,c2]=cores(p.h),fm=SOC.followsMe(p.h);
  return `<div class="row"><div class="pf-av" style="background:linear-gradient(145deg,${c1},${c2})">${esc(ini(p.n))}</div><div class="grow"><div class="ttl">${hl(p.n,busca.q)}</div><div class="sm mut">@${esc(p.h)}${fm?`<i class="pp-tag">Follows you</i>`:""}</div></div>${fbtnHTML(p.h,p.n)}</div>`;
}
function sqTop(it,q){
  if(it.tipo==="artista"){const a=it.a;return `<a class="sq-top" href="#artist-${a.key}">${capaFoto(a.foto,a.n,104,true)}<div class="grow"><span class="pill">Artist</span><div class="sq-tt">${hl(a.n,q)}</div><div class="sq-ts">${esc([a.genre,a.fas?fmtFas(a.fas)+" fans":""].filter(Boolean).join(" · ")||"Artist")}</div></div><span class="mut">${ico("chev",20)}</span></a>`}
  if(it.tipo==="album"){const u=it.u;return `<a class="sq-top" href="#album-${u.key}">${capaAlbum(u.key,u.t,104)}<div class="grow"><span class="pill">${tipoLabel(u.tipo)}</span><div class="sq-tt">${hl(u.t,q)}</div><div class="sq-ts">${esc(u.a)}${u.y?" · "+u.y:""}</div></div><span class="mut">${ico("chev",20)}</span></a>`}
  const m=it.m,k=albumKey(m.album.t,m.album.a);
  return `<a class="sq-top" href="#album-${k}">${capaAlbum(k,m.album.t,104)}<div class="grow"><span class="pill">Song</span><div class="sq-tt">${hl(m.titulo,q)}</div><div class="sq-ts">${esc(m.artista)} · ${esc(m.album.t)}</div></div><span class="mut">${ico("chev",20)}</span></a>`;
}
function sqSortAlb(list,q){
  const nq=norm(q),y=u=>u.y||"";
  if(SQ_SORT==="new")return [...list].sort((a,b)=>y(b).localeCompare(y(a)));
  if(SQ_SORT==="old")return [...list].sort((a,b)=>y(a).localeCompare(y(b)));
  if(SQ_SORT==="az")return [...list].sort((a,b)=>String(a.t).localeCompare(String(b.t)));
  return [...list].sort((a,b)=>((norm(b.t)===nq)-(norm(a.t)===nq))||(b.fontes.length-a.fontes.length));
}
montarBusca=function(q,coleta,f){
  window.__sq={q,coleta};
  const D=sqData(q,coleta),nq=norm(q);
  window.__sqSongs=D.musicas;
  window.__sqCnt={albuns:D.albuns.length,musicas:D.musicas.length,artistas:D.artistas.length,pessoas:D.pessoas.length};
  const total=D.albuns.length+D.musicas.length+D.artistas.length+D.pessoas.length;
  if(!total)return `<div class="empty">Nothing found for “${esc(q)}”.<br><span class="sm">Check the spelling or try fewer words.</span></div>`;
  const none=t=>`<div class="empty">No ${t} found for “${esc(q)}”.</div>`;
  if(f==="albuns"){
    const tipos=[["all","All types"],["album","Albums"],["ep","EPs"],["single","Singles"]];
    const l=sqSortAlb(D.albuns.filter(u=>SQ_TYPE==="all"||(u.tipo||"album").toLowerCase()===SQ_TYPE),q);
    return `<div class="tbar">${xsel("sqtype",tipos,SQ_TYPE)}${xsel("sqsort",[["rel","Relevance"],["new","Newest"],["old","Oldest"],["az","Title A–Z"]],SQ_SORT)}<span class="mut sm" style="margin-left:auto">${l.length} result${l.length===1?"":"s"}</span></div>${l.length?`<div class="grid">${l.map(u=>cardAlbum(u)).join("")}</div>`:none("albums")}`;
  }
  if(f==="musicas")return D.musicas.length?`<div class="mlist">${D.musicas.map((m,i)=>sqSong(m,i,q)).join("")}</div>`:none("songs");
  if(f==="artistas")return D.artistas.length?`<div class="grid">${D.artistas.map(cardArtista).join("")}</div>`:none("artists");
  if(f==="pessoas")return D.pessoas.length?`<div class="mlist">${D.pessoas.map(sqPessoa).join("")}</div>`:none("people")+`<p class="rvnote">Tip: type <b>@username</b> to follow someone by their exact username.</p>`;
  const sc=(n,b)=>(norm(n)===nq?60:0)+(norm(n).startsWith(nq)?20:0)+(norm(n).includes(nq)?8:0)+b;
  const cand=[];
  D.albuns.slice(0,6).forEach(u=>cand.push({tipo:"album",u,s:sc(u.t,u.fontes.length*10)}));
  D.artistas.slice(0,6).forEach(a=>cand.push({tipo:"artista",a,s:sc(a.n,a.fontes.length*10+6)}));
  D.musicas.slice(0,6).forEach(m=>cand.push({tipo:"musica",m,s:sc(m.titulo,4)}));
  cand.sort((x,y)=>y.s-x.s);
  const songs=D.musicas.slice(0,4);
  return `<div class="sq-two">${cand[0]?`<div><h3 class="sec">Top result</h3>${sqTop(cand[0],q)}</div>`:"<div></div>"}
    ${songs.length?`<div><h3 class="sec">Songs</h3><div class="mlist">${songs.map((m,i)=>sqSong(m,i,q)).join("")}</div>${D.musicas.length>4?`<button class="lnk" data-sqgo="musicas">See all ${D.musicas.length} songs</button>`:""}</div>`:""}</div>
  ${D.artistas.length?`<div class="sec-h"><h2>Artists</h2><button class="lnk" data-sqgo="artistas">See all</button></div><div class="carrossel" data-keep>${D.artistas.slice(0,12).map(cardArtista).join("")}</div>`:""}
  ${D.albuns.length?`<div class="sec-h"><h2>Albums & EPs</h2><button class="lnk" data-sqgo="albuns">See all</button></div><div class="carrossel" data-keep>${D.albuns.slice(0,14).map(u=>cardAlbum(u)).join("")}</div>`:""}
  ${D.pessoas.length?`<div class="sec-h"><h2>People</h2><button class="lnk" data-sqgo="pessoas">See all</button></div><div class="mlist">${D.pessoas.slice(0,3).map(sqPessoa).join("")}</div>`:""}`;
}
function sqEmpty(){
  const rec=S.recent||[],trend=trendList(10);
  const diario=Object.entries(S.u).filter(([k,v])=>v.d&&S.meta[k]).sort((a,b)=>b[1].d.localeCompare(a[1].d)).slice(0,10);
  return `${rec.length?`<div class="sec-h" style="margin-top:6px"><h2>Recent</h2><button class="lnk" data-sqclr>Clear</button></div><div class="sq-chips">${rec.map((t,i)=>`<span class="sq-c"><button data-sq="${esc(t)}">${ico("clock",14)} ${esc(t)}</button><button class="x" data-sqrm="${i}" aria-label="Remove">${ico("x",12)}</button></span>`).join("")}</div>`:""}
  <div class="sec-h"><h2>Trending searches</h2></div><div class="sq-chips">${trend.map(t=>`<span class="sq-c"><button data-sq="${esc(t)}">${ico("trend",14)} ${esc(t)}</button></span>`).join("")}</div>
  ${diario.length?`<div class="sec-h"><h2>Jump back in</h2></div><div class="carrossel" data-keep>${diario.map(([k])=>cardMeta(k)).join("")}</div>`:""}`;
}
function sqChips(){
  const c=window.__sqCnt;
  document.querySelectorAll("#app .sp-chips [data-fl]").forEach(b=>{const k=b.dataset.fl,n=c&&k!=="tudo"?c[k]:null;b.innerHTML=esc(SQ_LBL[k])+(n!=null?` <span class="cn">${n}</span>`:"")});
}
function sqSyncUI(){
  const bar=document.getElementById("spbar");if(bar)bar.classList.toggle("has",!!(busca.q||"").length);
  document.querySelectorAll("#app [data-fl]").forEach(c=>c.classList.toggle("on",c.dataset.fl===busca.f));
  const hi=document.getElementById("hq3");if(hi&&document.activeElement!==hi)hi.value=busca.q||"";
}
function redesenharBusca(){
  const res=document.getElementById("res");
  if(res&&window.__sq){res.innerHTML=montarBusca(window.__sq.q,window.__sq.coleta,busca.f);sqChips();sqSyncUI()}
}
runSearch=async function(){
  const q=(busca.q||"").trim(),res=document.getElementById("res");
  if(!res)return;
  const qi=document.getElementById("q");if(qi&&qi.value!==busca.q)qi.value=busca.q;
  window.__sq=null;window.__sqCnt=null;sqSyncUI();
  if(q.length<2){buscaTok++;res.innerHTML=sqEmpty();sqChips();if(qi&&matchMedia("(hover:hover)").matches)qi.focus();return}
  const tok=++buscaTok,f=busca.f,e=encodeURIComponent(q),coleta={alb:[],mus:[],art:[]};
  const desenhar=()=>{if(tok===buscaTok){res.innerHTML=montarBusca(q,coleta,busca.f);window.__sq.done=true;sqChips();sqSyncUI()}};
  res.innerHTML=`<div class="load"></div><div class="load"></div><div class="load"></div>`;
  const rapido=await Promise.allSettled([fontes.albunsDZ(e),fontes.albunsIT(e),fontes.musicasDZ(e),fontes.musicasIT(e),fontes.artistasDZ(e),fontes.artistasIT(e),fontes.albunsSP(e),fontes.musicasSP(e),fontes.artistasSP(e)]);
  if(tok!==buscaTok)return;
  const ok=i=>rapido[i].status==="fulfilled"?rapido[i].value:[];
  coleta.alb.push(...ok(0),...ok(1),...ok(6));
  coleta.mus.push(...ok(2),...ok(3),...ok(7));
  coleta.mus.forEach(m=>coleta.alb.push(m.album));
  coleta.art.push(...ok(4),...ok(5),...ok(8));
  desenhar();
  Promise.allSettled([fontes.albunsMB(e),fontes.artistasMB(e)]).then(r=>{
    if(tok!==buscaTok)return;
    if(r[0].status==="fulfilled")coleta.alb.push(...r[0].value);
    if(r[1].status==="fulfilled")coleta.art.push(...r[1].value);
    desenhar();
  });
};
/* filtros instantâneos (sem buscar de novo) */
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-fl]");
  if(b&&window.__sq&&window.__sq.done&&window.__sq.q===(busca.q||"").trim()){
    e.stopPropagation();busca.f=b.dataset.fl;redesenharBusca();return;
  }
},true);
document.addEventListener("click",e=>{
  const t=e.target;
  const go=t.closest("[data-sqgo]");if(go){busca.f=go.dataset.sqgo;redesenharBusca();window.scrollTo({top:0,behavior:"smooth"});return}
  if(t.closest("[data-sqx]")){busca.q="";const qi=document.getElementById("q");if(qi){qi.value="";qi.focus()}runSearch();return}
  const sq=t.closest("[data-sq]");if(sq){busca.q=sq.dataset.sq;saveRecent(busca.q);runSearch();return}
  const rm=t.closest("[data-sqrm]");if(rm){(S.recent=S.recent||[]).splice(+rm.dataset.sqrm,1);salvar();const r=document.getElementById("res");if(r)r.innerHTML=sqEmpty();return}
  if(t.closest("[data-sqclr]")){S.recent=[];salvar();const r=document.getElementById("res");if(r)r.innerHTML=sqEmpty();return}
  const pl=t.closest("[data-sqplay]");
  if(pl){const m=(window.__sqSongs||[])[+pl.dataset.sqplay];if(m){const k=albumKey(m.album.t,m.album.a);abrirFaixa(m.titulo,m.artista,m.album.t,coverDe(k)||m.album.cover||"")}return}
  if(t.closest("#res a[href]"))saveRecent(busca.q);
});
document.addEventListener("input",e=>{if(e.target.id==="q")sqSyncUI()});
document.addEventListener("keydown",e=>{if(e.key==="Enter"&&e.target.id==="q"){clearTimeout(hqT);saveRecent(e.target.value);busca.q=e.target.value;runSearch();e.target.blur()}});
document.addEventListener("xselchange",e=>{
  const id=e.target.id;
  if(id==="sqsort"){SQ_SORT=e.detail;redesenharBusca()}
  if(id==="sqtype"){SQ_TYPE=e.detail;redesenharBusca()}
});

;/* ---------- bloco 16 ---------- */
/* ===== v5: topo do PC (busca com sugestões, atalhos, menu da conta) ===== */
function goPerfil(t){aba=t;const h="#@"+encodeURIComponent(P().handle);if(NAV.hash===h)rota();else NAV.go(h)}
async function surprise(){
  const ch=window.__chart||[];
  if(ch.length){const x=ch[Math.floor(Math.random()*ch.length)],key=albumKey(x.title,(x.artist||{}).name||"");if(S.meta[key]){NAV.go("album-"+key);return}}
  const q=queueKeys();if(q.length){NAV.go("album-"+q[Math.floor(Math.random()*q.length)]);return}
  try{const r=await tendencias(),l=r.lista.filter(temCapa);if(l.length){const u=l[Math.floor(Math.random()*l.length)];guardarAlbum(u);salvar();NAV.go("album-"+u.key);return}}catch(e){}
  flash("Couldn't find anything right now");
}
function hdrSync(){
  const p=P(),av=document.getElementById("hbAv");
  if(av){const [c1,c2]=cores(p.handle||"trackly");av.style.background=p.avatar?"#222":`linear-gradient(145deg,${c1},${c2})`;av.innerHTML=p.avatar?`<img src="${esc(p.avatar)}" alt="">`:esc(ini(p.nome))}
  const n=queueKeys().length,b=document.getElementById("hbN");
  if(b){b.hidden=!n;b.textContent=n>99?"99+":n}
  sqSyncUI();
}
(function(){
  const hdr=document.querySelector("header");
  const old=document.querySelector(".hsearch");if(old)old.remove();
  const r=document.createElement("div");r.className="hright";
  r.innerHTML=`<div class="hs" id="hs"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg><input id="hq3" type="text" placeholder="Search" autocomplete="off" autocapitalize="none" spellcheck="false" aria-label="Search"><kbd class="hs-k">/</kbd><div class="sg" id="sg" hidden></div></div>
  <button class="hb" id="hbRnd" title="Surprise me" aria-label="Surprise me">${ico("shuffle",18)}</button>
  <button class="hb" id="hbQ" title="Queue" aria-label="Queue">${ico("queue",18)}<i class="hb-n" id="hbN" hidden>0</i></button>
  <div class="hmw"><button class="hav" id="hbAv" aria-label="Account menu"></button><div class="hm" id="hm" hidden></div></div>`;
  hdr.appendChild(r);
  const hs=document.getElementById("hs"),inp=document.getElementById("hq3"),sg=document.getElementById("sg"),hm=document.getElementById("hm");
  const cache=new Map();let tm=null,tok=0;
  const sgClose=()=>{sg.hidden=true;hs.classList.remove("open")};
  const hmClose=()=>{hm.hidden=true};
  const items=()=>[...sg.querySelectorAll(".sg-i")];
  const setAct=i=>{const l=items();l.forEach(x=>x.classList.remove("act"));if(i>=0&&l[i]){l[i].classList.add("act");l[i].scrollIntoView({block:"nearest"})}};
  const curAct=()=>items().findIndex(x=>x.classList.contains("act"));
  const sgEmptyHTML=()=>{
    const rec=(S.recent||[]).slice(0,5),tr=trendList(5);
    return `${rec.length?`<div class="sg-lb">Recent</div>${rec.map(t=>`<button class="sg-i" data-sgq="${esc(t)}">${ico("clock",16)}<span class="sg-t"><b>${esc(t)}</b></span></button>`).join("")}`:""}<div class="sg-lb">Trending</div>${tr.map(t=>`<button class="sg-i" data-sgq="${esc(t)}">${ico("trend",16)}<span class="sg-t"><b>${esc(t)}</b></span></button>`).join("")}`;
  };
  const show=html=>{sg.innerHTML=html;sg.hidden=false;hs.classList.add("open")};
  const render=(q,D)=>{
    const it=(href,img,t,s,k)=>`<a class="sg-i" href="${href}">${img}<span class="sg-t"><b>${hl(t,q)}</b><small>${esc(s)}</small></span><i class="sg-k">${k}</i></a>`;
    let h="";
    if(D.art.length)h+=`<div class="sg-lb">Artists</div>`+D.art.map(a=>it("#artist-"+a.key,capaFoto(a.foto,a.n,38,true),a.n,a.genre||(a.fas?fmtFas(a.fas)+" fans":"Artist"),"Artist")).join("");
    if(D.alb.length)h+=`<div class="sg-lb">Albums</div>`+D.alb.map(u=>it("#album-"+u.key,capaAlbum(u.key,u.t,38),u.t,u.a+(u.y?" · "+u.y:""),tipoLabel(u.tipo))).join("");
    if(D.mus.length)h+=`<div class="sg-lb">Songs</div>`+D.mus.map(m=>{const k=albumKey(m.album.t,m.album.a);return it("#album-"+k,capaAlbum(k,m.album.t,38),m.titulo,m.artista+" · "+m.album.t,"Song")}).join("");
    if(!h)h=`<div class="sg-lb">No quick matches</div>`;
    h+=`<button class="sg-all" data-sgall>${ico("search",15)} See all results for “${esc(q)}”<kbd>↵</kbd></button>`;
    show(h);
  };
  const run=async q=>{
    const key=q.toLowerCase();
    if(cache.has(key)){render(q,cache.get(key));return}
    const my=++tok;show(`<div class="load"></div><div class="load"></div>`);
    const e=encodeURIComponent(q);
    const r=await Promise.allSettled([fontes.artistasDZ(e),fontes.albunsDZ(e),fontes.musicasDZ(e)]);
    if(my!==tok||document.activeElement!==inp&&sg.hidden)return;
    const ok=i=>r[i].status==="fulfilled"?r[i].value:[];
    const D={art:unirArtistas(ok(0)).slice(0,3),alb:unirAlbuns(ok(1)).slice(0,4),mus:dedupMusicas(ok(2)).slice(0,3)};
    D.art.forEach(guardarArtista);D.alb.forEach(guardarAlbum);D.mus.forEach(m=>{const u=unirAlbuns([m.album])[0];if(u)guardarAlbum(u)});
    cache.set(key,D);
    if(inp.value.trim().toLowerCase()===key)render(q,D);
  };
  const go=q=>{
    q=q.trim();saveRecent(q);busca.q=q;sgClose();inp.blur();
    if(NAV.hash==="#search")runSearch();else NAV.go("search");
  };
  inp.addEventListener("focus",()=>{hmClose();const q=inp.value.trim();if(q.length>=2)run(q);else show(sgEmptyHTML())});
  inp.addEventListener("input",()=>{
    clearTimeout(tm);const q=inp.value.trim();
    if(q.length<2){tok++;show(sgEmptyHTML());return}
    tm=setTimeout(()=>run(q),220);
  });
  inp.addEventListener("keydown",e=>{
    if(e.key==="ArrowDown"){e.preventDefault();const l=items();if(l.length)setAct((curAct()+1)%l.length)}
    else if(e.key==="ArrowUp"){e.preventDefault();const l=items();if(l.length)setAct((curAct()-1+l.length)%l.length)}
    else if(e.key==="Enter"){
      e.preventDefault();const a=items()[curAct()];
      if(a){saveRecent(inp.value);if(a.tagName==="A")NAV.go(NAV.hrefOf(a));else if(a.dataset.sgq){inp.value=a.dataset.sgq;go(a.dataset.sgq);return}sgClose();inp.blur()}
      else go(inp.value);
    }
    else if(e.key==="Escape"){sgClose();inp.blur()}
  });
  sg.addEventListener("click",e=>{
    const q=e.target.closest("[data-sgq]");
    if(q){inp.value=q.dataset.sgq;go(q.dataset.sgq);return}
    if(e.target.closest("[data-sgall]")){go(inp.value);return}
    if(e.target.closest("a.sg-i")){saveRecent(inp.value);sgClose()}
  });
  document.getElementById("hbRnd").onclick=surprise;
  document.getElementById("hbQ").onclick=()=>goPerfil("fila");
  const menu=()=>{
    const p=P(),fo=SOC.following().length,fr=SOC.followers().length,nq=queueKeys().length,[c1,c2]=cores(p.handle||"trackly");
    const av=p.avatar?`<img src="${esc(p.avatar)}" alt="">`:esc(ini(p.nome));
    const i=(a,ic,l,em)=>`<button class="hm-i" data-hm="${a}">${ico(ic,17)}${l}${em!=null?`<em>${em}</em>`:""}</button>`;
    return `<div class="hm-h"><div class="pf-av" style="background:${p.avatar?"#222":`linear-gradient(145deg,${c1},${c2})`}">${av}</div><div style="min-width:0"><b>${esc(p.nome)}</b><small>@${esc(p.handle)}</small>${isCreator(p.handle)?cbadge():""}</div></div>
    ${i("perfil","user","Profile")}${i("diario","diary","Diary")}${i("fila","queue","Queue",nq)}${i("listas","list","Lists",S.listas.length)}${i("pessoas","people","People",fo+" · "+fr)}${i("appearance","palette","Appearance")}<hr>${i("feed","home","Feed")}${i("share","share","Share profile")}${i("story","share","Share to Story")}${i("backup","external","Export backup")}${i("criador","info","Creator badge",p.criador!==false?"On":"Off")}${window.tkMenuHTML?tkMenuHTML(i):""}`;
  };
  document.getElementById("hbAv").onclick=e=>{e.stopPropagation();sgClose();if(hm.hidden){hm.innerHTML=menu();hm.hidden=false}else hmClose()};
  hm.addEventListener("click",e=>{
    const b=e.target.closest("[data-hm]");if(!b)return;
    const a=b.dataset.hm;hmClose();if(a==="tklogin"||a==="tklogout"||a==="tkaccount"){window.tkMenuAct&&tkMenuAct(a);return}
    if(a==="feed")NAV.go("feed");
    else if(a==="share")compartilhar();
    else if(a==="story")gerarStoryPerfil();
    else if(a==="backup")exportar();else if(a==="appearance")NAV.go("settings-appearance");else if(a==="criador"){const pp=P();pp.criador=pp.criador===false;salvar();flash(pp.criador===false?"Creator badge off":"Creator badge on");rota()}
    else{if(a==="pessoas")window.__pp="seguindo";goPerfil(a==="perfil"?"perfil":a)}
  });
  document.addEventListener("click",e=>{
    if(!e.target.closest("#hs"))sgClose();
    if(!e.target.closest(".hmw"))hmClose();
  });
  window.addEventListener("navchange",()=>{sgClose();hmClose();hdrSync()});
  document.addEventListener("keydown",e=>{
    const tag=(document.activeElement||{}).tagName||"";
    if(e.key==="Escape"){hmClose()}
    const typing=/INPUT|TEXTAREA|SELECT/.test(tag)||(document.activeElement||{}).isContentEditable;
    const busy=document.getElementById("ed")||document.getElementById("stv")||document.getElementById("trk");
    if(busy)return;
    if((e.key==="/"&&!typing)||((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k")){
      e.preventDefault();
      if(hs.offsetParent!==null)inp.focus();
      else{const qi=document.getElementById("q");if(qi)qi.focus();else NAV.go("search")}
    }
  });
  let raf=0;
  new MutationObserver(()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(hdrSync)}).observe(document.getElementById("app"),{childList:true});
  hdrSync();
})();

;/* ---------- bloco 17 ---------- */
/* ===== v6: selo de criador =====
   Para dar o selo a outro perfil, coloque o @username dele em CREATORS. No seu próprio perfil
   o selo fica ligado por padrão (dá para desligar no menu da conta, no canto superior direito). */
const CREATORS=[];
const SEAL='<svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true"><path fill="currentColor" d="M12 1.8l2.4 1.6 2.9-.2 1.2 2.6 2.6 1.2-.2 2.9L22.5 12l-1.6 2.4.2 2.9-2.6 1.2-1.2 2.6-2.9-.2L12 22.2l-2.4-1.6-2.9.2-1.2-2.6-2.6-1.2.2-2.9L1.5 12l1.6-2.4-.2-2.9 2.6-1.2 1.2-2.6 2.9.2z"/><path d="M8.2 12.3l2.6 2.6 5-5.3" fill="none" stroke="#000" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const isCreator=h=>{const p=P();return (h===p.handle&&p.criador!==false)||CREATORS.includes(h)};
const cbadge=lg=>`<span class="cbadge${lg?" lg":""}" title="Creator of Trackly">${SEAL}<b>Creator</b></span>`;
(function(){
  const pv=perfilView;
  perfilView=function(){
    let h=pv();const p=P();
    if(isCreator(p.handle))h=h.replace(`<h1>${esc(p.nome)}</h1>`,`<div class="pf-nm"><h1>${esc(p.nome)}</h1>${cbadge(1)}</div>`);
    return h;
  };
  const wrap=fn=>rv=>{let h=fn(rv);return isCreator(rv.u)?h.replace('</b><span class="mut sm">@','</b>'+cbadge()+'<span class="mut sm">@'):h};
  const a=rvCard,b=feedCard;
  rvCard=wrap(a);feedCard=wrap(b);
})();

/* ===== v6: várias reviews por álbum (publicar, editar, escrever outra) ===== */
SOC.mineAll=function(k){const h=this.me().h;return this.s().rev.filter(x=>x.k===k&&x.u===h)};
SOC.post=function(k,r,txt,d,id){
  const me=this.me(),s=this.s();
  id=id||"m"+hash(k+me.h+Date.now()+Math.random());
  const i=s.rev.findIndex(x=>x.id===id),rv={id,k,u:me.h,n:me.n,av:me.av,r:r||0,txt,d};
  if(i>=0)s.rev[i]=rv;else s.rev.push(rv);
  salvar();
};
/* nota da comunidade conta só a avaliação mais recente de cada pessoa */
socStats=function(k){
  const me=SOC.me().h,by=new Map();
  SOC.list(k).filter(x=>x.r).sort((a,b)=>String(a.d).localeCompare(String(b.d))).forEach(x=>by.set(x.u,x));
  const lista=[...by.values()],rs=lista.map(x=>x.r),myr=(S.u[k]||{}).r;
  if(myr&&!by.has(me))rs.push(myr);
  const n=rs.length,avg=n?rs.reduce((a,b)=>a+b,0)/n:0;
  const hist=[.5,1,1.5,2,2.5,3,3.5,4,4.5,5].map(v=>rs.filter(r=>r===v).length);
  const fr=lista.filter(x=>SOC.isFriend(x.u)),fa=fr.length?fr.reduce((a,b)=>a+b.r,0)/fr.length:0;
  return {n,avg,pct:Math.round(avg/5*100),hist,fn:fr.length,fpct:Math.round(fa/5*100)};
};
function postedCard(rv,m){
  const lk=SOC.liked(rv);
  return `<div class="rvpost"><div class="rvp-h">${capaAlbum(rv.k,m.t,64)}<div class="rvp-i"><div class="rvp-ok">${ico("check",12)} Posted</div><div class="lbx-t">${esc(m.t)}</div><div class="lbx-s">${esc(m.a)}${m.y?" · "+m.y:""}</div></div></div>
  <div class="rvp-m">${rv.r?estrelas(rv.r):""}<span class="mut sm">Listened ${esc(fmtData(rv.d))}</span><span class="mut sm">${ico("heart",13,lk)} ${SOC.likes(rv)}</span></div>
  ${rv.txt?`<p class="rv-t">${esc(rv.txt)}</p>`:`<p class="rv-t mut">Rating only, no written review.</p>`}
  <div class="rvp-b"><button class="btn" data-rv="edit" data-id="${rv.id}">Edit</button><button class="btn" data-story="album">${ico("share",14)} Share to Story</button><button class="btn" data-soc="unpub" data-id="${rv.id}">Remove</button></div></div>`;
}
function revSection(k){
  const m=S.meta[k],x=dd(k);
  const mine=SOC.mineAll(k).sort((a,b)=>String(b.d).localeCompare(String(a.d)));
  const ed=(window.__revEdit&&mine.find(r=>r.id===window.__revEdit))||null;
  const nw=window.__revNew===k,box=!mine.length||!!ed||nw;
  const cards=mine.filter(r=>!ed||r.id!==ed.id);
  let h=`<div id="revsec">`;
  if(cards.length)h+=`<h2>Your review${cards.length>1?"s":""}</h2>`+cards.map(r=>postedCard(r,m)).join("");
  if(mine.length&&!box)h+=`<div style="margin-top:4px"><button class="btn" data-rv="new">${ico("plus",14)} Write another review</button></div>`;
  if(box){
    const val=ed?ed.txt:(nw?"":(x.rev||"")),dt=ed?ed.d:(nw?hoje():(x.d||hoje()));
    h+=`<h2>${ed?"Edit review":(mine.length?"New review":"Review")}</h2>
    <div class="lbx">
      <div class="lbx-h">${capaAlbum(k,m.t,64)}<div style="min-width:0"><div class="lbx-t">${esc(m.t)}</div><div class="lbx-s">${esc(m.a)}${m.y?` · ${m.y}`:""}</div></div></div>
      <label class="lbx-d"><span>Listened on</span><input type="date" id="revd" value="${esc(dt)}" max="${hoje()}"></label>
      <textarea class="field" id="rev" placeholder="Add a review…">${esc(val)}</textarea>
      <div class="lbx-f">
        <div class="lbx-r"><span class="mut sm">Rating</span><div style="display:flex" id="rate2">${rateHTML(x.r)}</div></div>
        <button class="ab ${x.l?"on":""}" data-act="revlike">${likeInner(!!x.l)}</button>
      </div>
      <div class="lbx-b">${ed?"":`<button class="btn" data-act="rev">Save draft</button>`}<button class="fab" data-soc="pub">${ed?"Update review":"Publish review"}</button><button class="btn" data-story="album">${ico("share",14)} Share to Story</button>${mine.length?`<button class="btn" data-rv="cancel">Cancel</button>`:""}</div>
    </div>`;
  }
  return h+`</div>`;
}
(function(){
  const av=albumView;
  albumView=async function(k){
    let html=await av(k);
    if(!S.meta[k])return html;
    const a=html.indexOf("<h2>Review</h2>"),b=html.indexOf("<h2>Reviews</h2>");
    if(a<0||b<a)return html;
    return html.slice(0,a)+revSection(k)+html.slice(b);
  };
})();
const goRev=()=>whenEl("#revsec",el=>el.scrollIntoView({behavior:"smooth",block:"start"}));
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-rv]");if(!b)return;
  const a=b.dataset.rv,k=NAV.hash.slice(7);
  if(a==="new"){window.__revNew=k;window.__revEdit=null}
  else if(a==="edit"){window.__revEdit=b.dataset.id;window.__revNew=null}
  else{window.__revNew=null;window.__revEdit=null}
  rota();goRev();
});
/* publicar: captura antes do handler antigo (que só sabia de uma review por álbum) */
document.addEventListener("click",e=>{
  const b=e.target.closest('[data-soc="pub"]');if(!b)return;
  e.stopPropagation();
  const k=NAV.hash.slice(7),d=dd(k);
  const txt=((document.getElementById("rev")||{}).value||"").trim(),dv=(document.getElementById("revd")||{}).value;
  if(!d.r&&!txt){flash("Add a rating or write a review first");return}
  const id=window.__revEdit||null;
  d.rev=txt;d.d=dv||d.d||hoje();
  SOC.post(k,d.r||0,txt,dv||d.d,id);
  window.__revEdit=null;window.__revNew=null;
  flash(id?"Review updated":"Review published");rota();goRev();
},true);
document.addEventListener("click",e=>{
  if(!e.target.closest("[data-gofriends]"))return;
  e.stopPropagation();aba="pessoas";window.__pp="seguindo";
},true);

/* ===== v6: Feed estilo Letterboxd (You · Friends · Following · Incoming) ===== */
const FT_LBL={you:"You",friends:"Friends",following:"Following",incoming:"Incoming"};
function feedItens2(tab){
  const me=SOC.me().h,out=[];
  Object.keys(S.meta).forEach(k=>SOC.list(k).forEach(rv=>{
    const u=rv.u;
    const ok=tab==="you"?u===me:tab==="friends"?(u!==me&&SOC.isFriend(u)&&SOC.followsMe(u)):tab==="following"?(u!==me&&SOC.isFriend(u)):false;
    if(ok)out.push(rv);
  }));
  return out.sort((a,b)=>String(b.d).localeCompare(String(a.d))).slice(0,60);
}
function feedIncoming(){
  const me=SOC.me().h,s=SOC.s(),fol=SOC.followers(),likes=[];
  s.rev.filter(x=>x.u===me).forEach(rv=>{
    const who=(s.likes[rv.id]||[]).filter(h=>h!==me).map(h=>({h,n:(DEMOF.find(d=>d[0]===h)||[h,h])[1]}));
    if(s.demo)fol.forEach(a=>{if(parseInt(hash(rv.id+a.h),36)%3===0&&!who.some(w=>w.h===a.h))who.push(a)});
    who.forEach(a=>likes.push({a,rv}));
  });
  likes.sort((x,y)=>String(y.rv.d).localeCompare(String(x.rv.d)));
  return {fol,likes};
}
function feedBody(tab){
  const me=SOC.me().h;
  if(tab==="incoming"){
    const D=feedIncoming();
    if(!D.fol.length&&!D.likes.length)return `<div class="empty">Nothing yet. New followers and likes on your reviews will show up here.</div>`;
    const av=a=>{const [c1,c2]=cores(a.h);return `<div class="pf-av" style="background:linear-gradient(145deg,${c1},${c2})">${esc(ini(a.n))}</div>`};
    return (D.fol.length?`<h3 class="sec" style="margin:6px 4px 10px">New followers</h3><div class="mlist">${D.fol.map(a=>`<div class="row">${av(a)}<div class="grow"><div class="ttl">${esc(a.n)}</div><div class="sm mut">@${esc(a.h)} started following you</div></div>${fbtnHTML(a.h,a.n)}</div>`).join("")}</div>`:"")
      +(D.likes.length?`<h3 class="sec" style="margin:26px 4px 10px">Likes on your reviews</h3><div class="mlist">${D.likes.map(({a,rv})=>{const m=S.meta[rv.k]||{t:"Album"};return `<a class="row" href="#album-${rv.k}">${av(a)}<div class="grow"><div class="ttl">${esc(a.n)} liked your review</div><div class="sm mut">${esc(m.t)} · ${esc(fmtData(rv.d))}</div></div>${capaAlbum(rv.k,m.t,40)}</a>`}).join("")}</div>`:"");
  }
  const itens=feedItens2(tab);
  if(itens.length)return itens.map(feedCard).join("");
  const msg={
    you:`You haven't posted any reviews yet. Open an album and publish one.`,
    friends:`No friends yet. When you follow someone and they follow you back, they show up here.`,
    following:`You're not following anyone yet. <a href="#@${encodeURIComponent(me)}" data-gofriends>Find people</a> in Search (type @username) or on your Profile.`
  }[tab];
  return `<div class="empty">${msg}</div>`;
}
feedHTML=function(){
  const tab=window.__ft||"friends",inc=feedIncoming(),
    cnt={you:feedItens2("you").length,friends:feedItens2("friends").length,following:feedItens2("following").length,incoming:inc.fol.length+inc.likes.length};
  return `<h1>Feed</h1>
  <div class="rvtabs">${Object.keys(FT_LBL).map(t=>`<button class="${tab===t?"on":""}" data-ft="${t}">${FT_LBL[t]}${cnt[t]?` · ${cnt[t]}`:""}</button>`).join("")}</div>
  <div id="feedlist">${feedBody(tab)}</div>
  <p class="rvnote">Reviews are stored only in this browser for now. When the database is connected, this feed will show real activity from the people you follow.</p>`;
};
renderFeed=function(){const el=document.getElementById("feedlist");if(el)el.innerHTML=feedBody(window.__ft||"friends")};
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-ft]");if(!b)return;
  window.__ft=b.dataset.ft;rota();
});

;/* ---------- bloco 18 ---------- */
/* ===== v7: ícones extras ===== */
Object.assign(ICP,{
  link:'<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  left:'<path d="M15 5l-7 7 7 7"/>',up:'<path d="M5 15l7-7 7 7"/>',down:'<path d="M5 9l7 7 7-7"/>',
  lk_ig:'<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.3 6.8h.01"/>',
  lk_x:'<path d="M4.5 4.5l15 15M19.5 4.5l-15 15"/>',
  lk_tt:'<path d="M14 4v10.5a3.5 3.5 0 1 1-3.5-3.5M14 4c.4 2.4 1.9 3.9 4.5 4.2"/>',
  lk_sp:'<circle cx="12" cy="12" r="9"/><path d="M7 9.5c3.3-1 7-.7 10 1M7.8 13c2.7-.8 5.4-.5 7.8.9M8.6 16.2c2-.5 4-.3 5.7.7"/>',
  lk_yt:'<rect x="3" y="6" width="18" height="12" rx="4"/><path d="M10.5 9.6v4.8l4.1-2.4z"/>',
  lk_lb:'<circle cx="7.3" cy="12" r="3.3"/><circle cx="12" cy="12" r="3.3"/><circle cx="16.7" cy="12" r="3.3"/>',
  lk_fm:'<circle cx="12" cy="12" r="9"/><path d="M8 8v8M8 12c0-1.6 1.2-2.6 2.5-2.6s2.2.9 2.6 2.6.9 2.6 2.4 2.6"/>'
});

/* ===== v7: links (como no Letterboxd) ===== */
const LKS=[
  ["site","Website","globe","yourwebsite.com"],
  ["instagram","Instagram","lk_ig","username"],
  ["x","X / Twitter","lk_x","username"],
  ["tiktok","TikTok","lk_tt","username"],
  ["youtube","YouTube","lk_yt","@channel or link"],
  ["spotify","Spotify","lk_sp","profile link"],
  ["letterboxd","Letterboxd","lk_lb","username"],
  ["lastfm","Last.fm","lk_fm","username"]
];
const LKBASE={instagram:"https://instagram.com/",x:"https://x.com/",tiktok:"https://tiktok.com/@",youtube:"https://youtube.com/@",spotify:"https://open.spotify.com/user/",letterboxd:"https://letterboxd.com/",lastfm:"https://last.fm/user/"};
function linkURL(k,v){
  v=String(v||"").trim();if(!v||/\s/.test(v)&&!/^https?:\/\//i.test(v))return"";
  let u="";
  if(/^https?:\/\//i.test(v))u=v;
  else if(/\./.test(v)&&(k==="site"||/\//.test(v)))u="https://"+v;
  else if(k==="site")return"";
  else u=LKBASE[k]+encodeURIComponent(v.replace(/^@/,""));
  try{const x=new URL(u);return (/^https?:$/.test(x.protocol)&&x.hostname.includes("."))?x.href:""}catch(e){return""}
}
const hostOf=u=>{try{return new URL(u).hostname.replace(/^www\./,"")}catch(e){return u}};
function linksOf(p){
  const L=p.links||{},out=[];
  LKS.forEach(([k,n,ic])=>{const u=linkURL(k,L[k]);if(u)out.push({ic,t:k==="site"?hostOf(u):n,u,web:k==="site"})});
  (p.custom||[]).forEach(c=>{const u=linkURL("site",c.u),l=String(c.l||"").trim();if(u)out.push({ic:"link",t:l||hostOf(u),u,web:true})});
  return out;
}
const linkChips=p=>{const l=linksOf(p);return l.length?`<div class="pf-links">${l.map(x=>`<a class="pf-lk" href="${esc(x.u)}" target="_blank" rel="noopener noreferrer me">${ico(x.ic,15)}<span>${esc(x.t)}</span></a>`).join("")}</div>`:""};
(function(){
  const pv=perfilView;
  perfilView=function(){
    let h=pv();const p=P();
    const old=`<div class="phandle">@${esc(p.handle)}${p.local?" · "+esc(p.local):""}</div>`;
    h=h.replace(old,`<div class="phandle">@${esc(p.handle)}${p.local?" · "+esc(p.local):""}${p.pron?`<span class="pf-pron">${esc(p.pron)}</span>`:""}</div>`);
    return h.replace('<div class="pf-stats">',linkChips(p)+'<div class="pf-stats">');
  };
})();

/* ===== v7: página de configurações ===== */
const STABS=[["profile","Profile","user"],["favorites","Favorites","star"],["appearance","Appearance","palette"],["account","Account","info"]];
let SETD=null,SETO="",STAB="profile",SFQ="",SFM="albuns",SFRES=[],sfTok=0,sfT=null;
const dirty=()=>!!SETD&&JSON.stringify(SETD)!==SETO;
const stHash=t=>t==="profile"?"settings":"settings-"+t;
function stGo(t){const h=stHash(t);if(NAV.hash==="#"+h)renderSettings();else NAV.go(h)}

(function(){
  const _rota=rota;
  window.removeEventListener("navchange",_rota);
  rota=function(){
    const h=decodeURIComponent(NAV.hash.slice(1)),on=h==="settings"||h.startsWith("settings-");
    document.body.classList.toggle("settings",on);
    const g=document.querySelector(".gear");if(g)g.classList.toggle("on",on);
    if(!on){SETD=null;return _rota()}
    rotaTok++;resetAmb();
    document.documentElement.style.removeProperty("--bg");
    document.body.classList.remove("perfil");
    document.querySelectorAll(".nav a").forEach(a=>a.classList.remove("on"));
    const t=h.split("-")[1];STAB=STABS.some(x=>x[0]===t)?t:"profile";
    renderSettings(true);
  };
  window.addEventListener("navchange",()=>rota());
})();

function renderSettings(top){
  const y=window.scrollY;
  $("#app").innerHTML=settingsView();
  window.scrollTo(0,top?0:y);
  stSync();
}
function stInit(){
  if(SETD)return;
  const p=P();
  SETD=JSON.parse(JSON.stringify(p));
  SETD.fav=SETD.fav||[];SETD.musicas=SETD.musicas||[];SETD.mcov=SETD.mcov||{};SETD.links=SETD.links||{};SETD.custom=SETD.custom||[];
  SETD.pron=SETD.pron||"";SETD.bio=SETD.bio||"";SETD.local=SETD.local||"";SETD.criador=p.criador!==false;
  SETO=JSON.stringify(SETD);
}
function settingsView(){
  stInit();
  const body={profile:stProfile,favorites:stFav,links:stLinks,appearance:stAppearance,account:stAccount}[STAB]();
  return `<div class="stg"><div class="stg-head"><h1>Settings</h1><span>@${esc(P().handle)}</span></div>
  <div class="stg-grid">
    <nav class="stg-nav">${STABS.map(([k,l,ic])=>`<a class="stg-n ${STAB===k?"on":""}" href="#${stHash(k)}">${ico(ic,18)}${l}</a>`).join("")}</nav>
    <div class="stg-main">${body}</div>
    <aside class="stg-prev"><div class="stg-lbl">Preview</div><div id="stpvin"></div></aside>
  </div>
  <div class="stg-bar" id="stbar"><span>Unsaved changes</span><button class="btn" data-s="discard">Discard</button><button class="fab" data-s="save">Save changes</button></div></div>`;
}
function stProfile(){
  const e=SETD,[c1,c2]=cores(e.handle||"trackly");
  return `<section><h2>Profile</h2><p class="stg-sub">This is how people see you on Trackly.</p>
  <div class="sx-cov"><div class="sx-ban" style="${e.banner?`background-image:url('${esc(e.banner)}')`:`background:linear-gradient(135deg,${c1},${c2})`}"></div>
    <div class="sx-bacts"><label class="sx-chip">${ico("plus",13)} Banner<input id="sbanner" type="file" accept="image/*" hidden></label>${e.banner?`<button class="sx-chip" data-s="banner-rm">Remove</button>`:""}</div>
    <div class="sx-avrow"><div class="sx-av" style="background:${e.avatar?"#222":`linear-gradient(145deg,${c1},${c2})`}">${e.avatar?`<img src="${esc(e.avatar)}" alt="">`:esc(ini(e.nome))}</div>
      <div class="sx-aacts"><label class="sx-chip">Change photo<input id="sfoto" type="file" accept="image/*" hidden></label>${e.avatar?`<button class="sx-chip" data-s="foto-rm">Remove</button>`:""}</div></div></div></section>
  <section><div class="gr">
    <div class="gr-row"><span class="gr-lbl">Name</span><input class="gr-in" data-sf="nome" maxlength="40" value="${esc(e.nome)}" placeholder="Your name"></div>
    <div class="gr-row"><span class="gr-lbl">Username</span><span class="sx-at">@</span><input class="gr-in" data-sf="handle" maxlength="30" value="${esc(e.handle)}" placeholder="username" autocapitalize="none" autocorrect="off" spellcheck="false"></div>
    <div class="gr-row"><span class="gr-lbl">Pronouns</span><input class="gr-in" data-sf="pron" maxlength="24" value="${esc(e.pron)}" placeholder="Optional"></div>
    <div class="gr-row"><span class="gr-lbl">Location</span><input class="gr-in" data-sf="local" maxlength="40" value="${esc(e.local)}" placeholder="City, country"></div>
    <div class="gr-row gr-alto"><span class="gr-lbl">Bio</span><textarea class="gr-in" data-sf="bio" maxlength="240" rows="3" placeholder="Tell people what you listen to">${esc(e.bio)}</textarea></div>
  </div>
  <p class="sx-hint" id="shandle"></p>
  <div class="sx-sug">${["she/her","he/him","they/them"].map(v=>`<button data-s="pron" data-v="${v}">${v}</button>`).join("")}</div>
  <p class="sx-hint" id="sbioc"></p></section>`;
}
function favAlbHTML(){
  const f=SETD.fav;
  if(!f.length)return `<div class="sx-empty">No favorite albums yet. Search below and tap Add.</div>`;
  return `<div class="sx-fgrid">${f.map((k,i)=>{const m=S.meta[k]||{};return `<div class="sx-fi"><span class="sx-n">${i+1}</span>${capaAlbum(k,m.t,null)}<div class="sx-fcap">${esc(m.t||"")}</div><div class="sx-fa"><button class="ib" data-s="fav-l" data-i="${i}" aria-label="Move earlier" ${i?"":"disabled style='opacity:.3'"}>${ico("left",13)}</button><button class="ib" data-s="fav-r" data-i="${i}" aria-label="Move later" ${i<f.length-1?"":"disabled style='opacity:.3'"}>${ico("chev",13)}</button><button class="ib" data-s="fav-x" data-i="${i}" aria-label="Remove">${ico("x",12)}</button></div></div>`}).join("")}</div>`;
}
function favMusHTML(){
  const m=SETD.musicas;
  if(!m.length)return `<div class="sx-empty">No favorite songs yet.</div>`;
  return `<div class="mlist">${m.map((t,i)=>`<div class="row"><span class="num">${String(i+1).padStart(2,"0")}</span><div class="ttl grow">${esc(t)}</div><button class="ib" data-s="mus-u" data-i="${i}" aria-label="Move up" ${i?"":"disabled style='opacity:.3'"}>${ico("up",13)}</button><button class="ib" data-s="mus-d" data-i="${i}" aria-label="Move down" ${i<m.length-1?"":"disabled style='opacity:.3'"}>${ico("down",13)}</button><button class="ib" data-s="mus-x" data-i="${i}" aria-label="Remove">${ico("x",12)}</button></div>`).join("")}</div>`;
}
function stFav(){
  return `<section><h2>Favorites</h2><p class="stg-sub">Pick up to 10 albums and 10 songs. The first four albums are the ones shown first on your profile.</p>
  <div class="gr-tit">Favorite albums <span>${SETD.fav.length}/10</span></div><div id="sffa" style="margin-top:10px">${favAlbHTML()}</div></section>
  <section><div class="gr-tit">Favorite songs <span>${SETD.musicas.length}/10</span></div><div id="sffm" style="margin-top:10px">${favMusHTML()}</div></section>
  <section><div class="gr-tit">Add</div>
  <div class="sp-bar sm" style="margin-top:10px">${SQ_ICON}<input class="sp-in" id="sfq" type="text" placeholder="Search an album or a song" autocomplete="off" autocapitalize="none" spellcheck="false" value="${esc(SFQ)}"></div>
  <div class="chips">${[["albuns","Albums"],["musicas","Songs"]].map(([k,l])=>`<button class="chip ${SFM===k?"on":""}" data-sfm="${k}">${l}</button>`).join("")}</div>
  <div id="sfres" style="margin-top:12px"></div></section>`;
}
function stLinks(){
  const L=SETD.links;
  const row=([k,n,ic,ph])=>{const u=linkURL(k,L[k]),bad=!!(L[k]||"").trim()&&!u;
    return `<div class="gr-row${bad?" bad":""}" data-lrow="${k}"><span class="gr-lbl lk">${ico(ic,17)}${n}</span><input class="gr-in" data-sl="${k}" value="${esc(L[k]||"")}" placeholder="${ph}" autocapitalize="none" autocorrect="off" spellcheck="false" inputmode="${k==="site"?"url":"text"}"><span class="sx-lp" data-lp="${k}">${u?esc(hostOf(u)+new URL(u).pathname.replace(/\/$/,"")):""}</span></div>`};
  return `<section><h2>Links</h2><p class="stg-sub">Show your website and social profiles on your profile. Type a username or paste the full link.</p>
  <div class="gr">${LKS.map(row).join("")}</div></section>
  <section><div class="gr-tit">Custom links <span>${SETD.custom.length}/4</span></div><div style="margin-top:10px">
  ${SETD.custom.length?`<div class="gr">${SETD.custom.map((c,i)=>{const bad=!!(c.u||"").trim()&&!linkURL("site",c.u);return `<div class="gr-row${bad?" bad":""}"><span class="gr-lbl lk">${ico("link",17)}</span><input class="gr-in" style="flex:.8" data-sc="l" data-i="${i}" value="${esc(c.l)}" placeholder="Label (optional)" maxlength="24"><input class="gr-in" data-sc="u" data-i="${i}" value="${esc(c.u)}" placeholder="https://" autocapitalize="none" spellcheck="false" inputmode="url"><button class="ib" data-s="cus-x" data-i="${i}" aria-label="Remove">${ico("x",12)}</button></div>`}).join("")}</div>`:""}
  ${SETD.custom.length<4?`<button class="btn" style="margin-top:12px" data-s="cus-add">${ico("plus",14)} Add link</button>`:""}</div></section>`;
}
function stAccount(){
  const on=!!SETD.criador;
  return `<section><h2>Account</h2><p class="stg-sub">Preferences and your data.</p>
  <div class="gr"><div class="sx-row"><div class="t"><b>Creator badge</b><small>Show the Creator seal next to your name on your profile, reviews and feed.</small></div><button class="sx-sw ${on?"on":""}" data-s="criador" role="switch" aria-checked="${on}" aria-label="Creator badge"></button></div></div></section>
  <section><div class="gr-tit">Your data</div><p class="stg-sub" style="margin-top:8px">Everything is saved only in this browser. Back up from time to time.</p>
  <div class="gr"><div class="sx-btns"><button class="btn" data-bk="exp">Export backup</button><label class="btn" style="cursor:pointer">Import backup<input id="impf" type="file" accept="application/json,.json" hidden></label><button class="btn" data-s="clr-recent">Clear search history</button></div></div></section>`;
}
function stPreview(){
  const e=SETD,[c1,c2]=cores(e.handle||"trackly"),favs=(e.fav||[]).slice(0,4),links=linksOf(e);
  const badge=e.criador||CREATORS.includes(e.handle);
  return `<div class="sx-pv"><div class="sx-pvb" style="${e.banner?`background-image:url('${esc(e.banner)}')`:`background:linear-gradient(135deg,${c1},${c2})`}"></div>
  <div class="sx-pva" style="background:${e.avatar?"#222":`linear-gradient(145deg,${c1},${c2})`}">${e.avatar?`<img src="${esc(e.avatar)}" alt="">`:esc(ini(e.nome))}</div>
  <div class="sx-pvt"><div class="sx-pvn">${esc(e.nome||"Your name")}${badge?cbadge():""}</div>
  <div class="sx-pvh">@${esc(e.handle||"username")}${e.local?" · "+esc(e.local):""}${e.pron?" · "+esc(e.pron):""}</div>
  ${e.bio?`<div class="sx-pvbio">${esc(e.bio)}</div>`:""}
  ${links.length?`<div class="sx-pvl">${links.map(x=>`<span class="pf-lk">${ico(x.ic,13)}<span>${esc(x.t)}</span></span>`).join("")}</div>`:""}</div>
  <div class="sx-pvf">${[0,1,2,3].map(i=>favs[i]?capaAlbum(favs[i],(S.meta[favs[i]]||{}).t,null):"<i></i>").join("")}</div></div>`;
}
function stHandleErr(){
  const h=(SETD.handle||"").trim(),old=P().handle;
  if(!h)return"Choose a username.";
  if(!/^[a-z0-9._]{3,30}$/.test(h))return"Use 3 to 30 letters, numbers, dots or underscores.";
  if(h!==old&&DEMOF.some(d=>d[0]===h))return"That username is taken.";
  return"";
}
function stSync(){
  if(!SETD)return;
  const bar=document.getElementById("stbar");if(bar)bar.classList.toggle("show",dirty());
  const pv=document.getElementById("stpvin");if(pv)pv.innerHTML=stPreview();
  const hh=document.getElementById("shandle");
  if(hh){const er=stHandleErr();hh.className="sx-hint "+(er?"err":"ok");hh.textContent=er||`Your profile: @${SETD.handle}`}
  const bc=document.getElementById("sbioc");if(bc)bc.textContent=`${(SETD.bio||"").length}/240`;
}
function stSave(){
  const e=SETD,old=P();
  const nome=(e.nome||"").trim(),h=(e.handle||"").trim();
  if(!nome){flash("Add a display name");stGo("profile");return}
  const er=stHandleErr();if(er){flash(er);stGo("profile");return}
  const links={};let badLink=false;
  LKS.forEach(([k])=>{const v=(e.links[k]||"").trim();if(v){if(!linkURL(k,v))badLink=true;links[k]=v}});
  const custom=(e.custom||[]).map(c=>({l:(c.l||"").trim(),u:(c.u||"").trim()})).filter(c=>c.l||c.u);
  custom.forEach(c=>{if(!linkURL("site",c.u))badLink=true});
  if(badLink){flash("Check your links: some are not valid");stGo("links");return}
  const next={...old,...e,nome,handle:h,bio:(e.bio||"").trim(),local:(e.local||"").trim(),pron:(e.pron||"").trim(),links,custom,criador:!!e.criador,musicas:(e.musicas||[]).slice(0,10),fav:(e.fav||[]).slice(0,10)};
  const s=SOC.s();
  if(h!==old.handle){
    s.rev.forEach(r=>{if(r.u===old.handle)r.u=h});
    Object.keys(s.likes).forEach(id=>{s.likes[id]=s.likes[id].map(x=>x===old.handle?h:x)});
  }
  s.rev.forEach(r=>{if(r.u===h){r.n=nome;r.av=next.avatar||""}});
  S.perfil=next;salvar();SETD=null;aba="perfil";
  flash("Profile saved");
  NAV.go("profile");
}

/* busca para favoritos */
async function runSf(){
  const q=SFQ.trim(),res=document.getElementById("sfres");if(!res)return;
  if(q.length<2){res.innerHTML="";return}
  const e=encodeURIComponent(q),tok=++sfTok;res.innerHTML=`<div class="load"></div>`;
  if(SFM==="albuns"){
    const r=await Promise.allSettled([fontes.albunsDZ(e),fontes.albunsIT(e)]);if(tok!==sfTok)return;
    const l=unirAlbuns(r.flatMap(x=>x.status==="fulfilled"?x.value:[])).slice(0,20);l.forEach(guardarAlbum);salvar();
    res.innerHTML=l.length?`<div class="mlist">${l.map(u=>`<div class="row">${capaAlbum(u.key,u.t,46)}<div class="grow"><div class="ttl">${hl(u.t,q)}</div><div class="sm mut">${esc(u.a)}${u.y?" · "+u.y:""}</div></div><button class="sx-add" data-s="pick-alb" data-k="${u.key}"></button></div>`).join("")}</div>`:`<div class="empty">Nothing found.</div>`;
  }else{
    const r=await Promise.allSettled([fontes.musicasDZ(e),fontes.musicasIT(e)]);if(tok!==sfTok)return;
    SFRES=dedupMusicas(r.flatMap(x=>x.status==="fulfilled"?x.value:[])).slice(0,25);
    res.innerHTML=SFRES.length?`<div class="mlist">${SFRES.map((m,i)=>`<div class="row"><div class="grow"><div class="ttl">${hl(m.titulo,q)}</div><div class="sm mut">${esc(m.artista)} · ${esc(m.album.t)}</div></div><button class="sx-add" data-s="pick-mus" data-i="${i}"></button></div>`).join("")}</div>`:`<div class="empty">Nothing found.</div>`;
  }
  markPicks();
}
function markPicks(){
  document.querySelectorAll('#sfres [data-s="pick-alb"]').forEach(b=>{const on=SETD.fav.includes(b.dataset.k);b.classList.toggle("on",on);b.textContent=on?"Added":"Add"});
  document.querySelectorAll('#sfres [data-s="pick-mus"]').forEach(b=>{const m=SFRES[+b.dataset.i],on=!!m&&SETD.musicas.includes(`${m.titulo} — ${m.artista}`);b.classList.toggle("on",on);b.textContent=on?"Added":"Add"});
}
function favRefresh(){
  const a=document.getElementById("sffa"),m=document.getElementById("sffm");
  if(a)a.innerHTML=favAlbHTML();if(m)m.innerHTML=favMusHTML();
  document.querySelectorAll(".stg-main .gr-tit span").forEach((s,i)=>{s.textContent=(i?SETD.musicas.length:SETD.fav.length)+"/10"});
  markPicks();stSync();
}
const mv=(arr,i,d)=>{const j=i+d;if(j<0||j>=arr.length)return;[arr[i],arr[j]]=[arr[j],arr[i]]};

document.addEventListener("click",e=>{
  const g=e.target.closest('[data-pact="editar"]');
  if(g){e.stopPropagation();e.preventDefault();NAV.go("settings")}
},true);
document.addEventListener("click",e=>{
  if(!SETD||!dirty())return;
  const a=e.target.closest('a[href^="#"],a[data-h]');
  if(a&&!/^#settings/.test(NAV.hrefOf(a))&&!confirm("Discard unsaved changes?")){e.preventDefault();e.stopPropagation()}
},true);
document.addEventListener("click",e=>{
  const sm=e.target.closest("[data-sfm]");
  if(sm&&SETD){SFM=sm.dataset.sfm;document.querySelectorAll("[data-sfm]").forEach(c=>c.classList.toggle("on",c===sm));runSf();return}
  const b=e.target.closest("[data-s]");if(!b||!SETD)return;
  const a=b.dataset.s,i=+b.dataset.i;
  switch(a){
    case"banner-rm":SETD.banner="";renderSettings();break;
    case"foto-rm":SETD.avatar="";renderSettings();break;
    case"pron":{SETD.pron=b.dataset.v;const inp=document.querySelector('[data-sf="pron"]');if(inp)inp.value=b.dataset.v;stSync();break}
    case"fav-l":mv(SETD.fav,i,-1);favRefresh();break;
    case"fav-r":mv(SETD.fav,i,1);favRefresh();break;
    case"fav-x":SETD.fav.splice(i,1);favRefresh();break;
    case"mus-u":mv(SETD.musicas,i,-1);favRefresh();break;
    case"mus-d":mv(SETD.musicas,i,1);favRefresh();break;
    case"mus-x":SETD.musicas.splice(i,1);favRefresh();break;
    case"pick-alb":{
      const k=b.dataset.k,j=SETD.fav.indexOf(k);
      if(j>=0)SETD.fav.splice(j,1);else if(SETD.fav.length<10)SETD.fav.push(k);else{flash("Up to 10 favorite albums");break}
      favRefresh();break}
    case"pick-mus":{
      const m=SFRES[i];if(!m)break;const l=`${m.titulo} — ${m.artista}`,j=SETD.musicas.indexOf(l);
      if(j>=0)SETD.musicas.splice(j,1);else if(SETD.musicas.length<10)SETD.musicas.push(l);else{flash("Up to 10 songs");break}
      favRefresh();break}
    case"cus-add":if(SETD.custom.length<4){SETD.custom.push({l:"",u:""});renderSettings()}break;
    case"cus-x":SETD.custom.splice(i,1);renderSettings();break;
    case"criador":SETD.criador=!SETD.criador;b.classList.toggle("on",SETD.criador);b.setAttribute("aria-checked",SETD.criador);stSync();break;
    case"clr-recent":S.recent=[];salvar();flash("Search history cleared");break;
    case"discard":if(!dirty()||confirm("Discard your changes?")){SETD=null;NAV.go("profile")}break;
    case"save":stSave();break;
  }
});
document.addEventListener("input",e=>{
  const t=e.target;if(!SETD)return;
  if(t.dataset.sf){
    let v=t.value;const f=t.dataset.sf;
    if(f==="handle"){v=v.toLowerCase().replace(/[^a-z0-9._]/g,"");if(v!==t.value)t.value=v}
    SETD[f]=v;stSync();return;
  }
  if(t.dataset.sl){
    const k=t.dataset.sl;SETD.links[k]=t.value;
    const u=linkURL(k,t.value),row=t.closest(".gr-row"),lp=document.querySelector(`[data-lp="${k}"]`);
    if(row)row.classList.toggle("bad",!!t.value.trim()&&!u);
    if(lp)lp.textContent=u?hostOf(u)+new URL(u).pathname.replace(/\/$/,""):"";
    stSync();return;
  }
  if(t.dataset.sc){
    const c=SETD.custom[+t.dataset.i];if(!c)return;c[t.dataset.sc]=t.value;
    const row=t.closest(".gr-row");if(row)row.classList.toggle("bad",!!(c.u||"").trim()&&!linkURL("site",c.u));
    stSync();return;
  }
  if(t.id==="sfq"){SFQ=t.value;clearTimeout(sfT);sfT=setTimeout(runSf,300)}
});
document.addEventListener("change",e=>{
  const t=e.target;if(!SETD||!t.files||!t.files[0])return;
  if(t.id==="sfoto")lerImg(t.files[0],256,true,u=>{SETD.avatar=u;renderSettings()});
  if(t.id==="sbanner")lerImg(t.files[0],1400,false,u=>{SETD.banner=u;renderSettings()});
});
document.addEventListener("keydown",e=>{
  if(SETD&&(e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="s"){e.preventDefault();if(dirty())stSave()}
});
window.addEventListener("beforeunload",e=>{if(dirty()){e.preventDefault();e.returnValue=""}});
/* se o app abriu direto em #settings, desenha agora */
if(/^#settings/.test(NAV.hash))setTimeout(()=>rota(),0);

;/* ---------- bloco 19 ---------- */
Object.assign(ICP,{story:'<circle cx="12" cy="12" r="8.5" stroke-dasharray="3.2 2.6"/><path d="M12 8.5v7M8.5 12h7"/>'});
const hojeLocal=()=>{const d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")};

/* data em que a review foi POSTADA (campo p); reviews antigas usam a data da escuta como reserva */
SOC.post=function(k,r,txt,d,id){
  const me=this.me(),s=this.s();
  id=id||"m"+hash(k+me.h+Date.now()+Math.random());
  const i=s.rev.findIndex(x=>x.id===id),old=i>=0?s.rev[i]:null;
  const rv={id,k,u:me.h,n:me.n,av:me.av,r:r||0,txt,d,p:(old&&old.p)||hojeLocal()};
  if(i>=0)s.rev[i]=rv;else s.rev.push(rv);
  salvar();
};
const postedOn=k=>{const l=SOC.mineAll(k).map(r=>r.p||r.d).filter(Boolean).sort();return l.length?l[l.length-1]:((S.u[k]||{}).d||"")};

/* postedCard: mostra "Posted <dia>" */
(function(){
  const pc=postedCard;
  postedCard=function(rv,m){
    return pc(rv,m).replace(`<span class="mut sm">Listened `,`<span class="mut sm">Posted ${esc(fmtData(rv.p||rv.d))}</span><span class="mut sm">Listened `);
  };
})();

/* aba Ratings: data de postagem em cada linha */
pfRatings=function(){
  const av=Object.entries(S.u).filter(([k,v])=>v.r&&S.meta[k]);
  const ord=av.map(([k,v])=>[k,v,postedOn(k)]).sort((a,b)=>String(b[2]).localeCompare(String(a[2])));
  const faixas=Object.entries(S.tracks||{}).filter(([k])=>S.u[k]&&S.u[k].r).sort((a,b)=>S.u[b[0]].r-S.u[a[0]].r).slice(0,20);
  const alb=ord.length?`<div class="mlist" style="margin-top:24px">${ord.map(([k,v,p])=>{const m=S.meta[k];
    const last=SOC.mineAll(k).sort((a,b)=>String(b.p||b.d).localeCompare(String(a.p||a.d)))[0],txt=(last&&last.txt)||v.rev||"";
    return `<a class="row" href="#album-${k}" style="display:block"><div style="display:flex;align-items:center;gap:14px">${capaAlbum(k,m.t,46)}<div class="grow"><div class="ttl">${esc(m.t)}</div><div class="sm mut">${esc(m.a)}${p?` · <span class="rdate">${esc(fmtData(p))}</span>`:""}</div></div>${estrelas(v.r)}</div>${txt?`<div style="font-weight:500;padding:10px 0 0 60px;line-height:1.45">${esc(txt)}</div>`:""}</a>`}).join("")}</div>`:`<div class="empty" style="margin-top:24px">You haven't rated any album yet.</div>`;
  return alb+(faixas.length?`<h2>Rated songs</h2><div class="mlist">${faixas.map(([k,v])=>`<div class="row"><div class="grow"><div class="ttl">${esc(v.t)}</div><div class="sm mut">${esc(v.a)}</div></div>${estrelas(S.u[k].r)}</div>`).join("")}</div>`:"");
};

/* perfil: números em linha (sem cards), story vira ícone pequeno junto dos links */
(function(){
  const pv=perfilView;
  perfilView=function(){
    let h=pv();const p=P();
    const av=Object.values(S.u).filter(v=>v.r),ouv=Object.values(S.u).filter(v=>v.d).length;
    const media=av.length?av.reduce((s,v)=>s+v.r,0)/av.length:0;
    const st=(n,l,pp)=>pp?`<button class="pf-sx" data-aba="pessoas" data-pp="${pp}"><strong>${n}</strong><span>${l}</span></button>`:`<span class="pf-sx"><strong>${n}</strong><span>${l}</span></span>`;
    const strip=`<div class="pf-stats">${st(ouv,"Listened")}${st(av.length,"Ratings")}${st(media?media.toFixed(1):"—","Avg")}${st(SOC.following().length,"Following","seguindo")}${st(SOC.followers().length,"Followers","seguidores")}</div>`;
    h=h.replace(/<div class="pf-stats">[\s\S]*?<\/div>(?=\s*<nav class="ptabs">)/,"@@STATS@@");
    h=h.replace(/<div class="pf-links">[\s\S]*?<\/div>/,m=>m.replace(/<\/div>$/,""));
    const story=`<button class="pf-ib end" data-pact="cartao" aria-label="Share to Story" title="Share to Story">${ico("story",17)}</button>`;
    if(/<div class="pf-links">/.test(h))h=h.replace("@@STATS@@",story+"</div>"+strip);
    else h=h.replace("@@STATS@@",`<div class="pf-links">${story}</div>`+strip);
    h=h.replace(/<button class="btn" data-pact="cartao">Story<\/button>/,"");
    return h;
  };
})();

;/* ---------- bloco 20 ---------- */
/* Overview enxuto: só o que é do perfil (favoritos, últimas ratings, artistas seguidos).
   Números e gráficos ficam na aba Stats; backup fica em Settings. */
pfOverview=function(){
  const p=P(),fav=p.fav||[],av=Object.entries(S.u).filter(([k,v])=>v.r&&S.meta[k]);
  const slot=i=>fav[i]?`<a class="fitem" href="#album-${fav[i]}">${capaAlbum(fav[i],(S.meta[fav[i]]||{}).t,null)}<div class="ttl" style="margin-top:8px">${esc((S.meta[fav[i]]||{}).t||"")}</div></a>`:`<div class="fvazio">Empty</div>`;
  const nPag=Math.max(1,Math.ceil(fav.length/4));
  const slots=`<div class="favpages" id="favpages">${Array.from({length:nPag},(_,pg)=>`<div class="favpage">${[0,1,2,3].map(j=>slot(pg*4+j)).join("")}</div>`).join("")}</div>${nPag>1?`<div class="favdots">${Array.from({length:nPag},(_,n)=>`<button class="${n===0?"on":""}" data-favpg="${n}" aria-label="Group ${n+1}"></button>`).join("")}</div>`:""}`;
  const mus=favSongsHTML(p);
  const recs=[...av].sort((a,b)=>String(postedOn(b[0])).localeCompare(String(postedOn(a[0])))).slice(0,5);
  const rec=recs.length?`<div class="mlist">${recs.map(([k,v])=>{const m=S.meta[k];return `<a class="row" href="#album-${k}">${capaAlbum(k,m.t,46)}<div class="grow"><div class="ttl">${esc(m.t)}</div><div class="sm mut">${esc(m.a)}</div></div>${estrelas(v.r)}</a>`}).join("")}</div>`:`<div class="empty">No ratings yet.</div>`;
  const segA=(S.seguindo||[]);
  return `<div class="pgrid"><div><h3 class="sec">Favorite albums</h3>${slots}<h3 class="sec" style="margin-top:34px">Favorite songs</h3>${mus}</div><aside><h3 class="sec">Recent ratings</h3>${rec}</aside></div>
  ${segA.length?`<h2>Artists you follow</h2><div class="pf-arl">${segA.map(s=>`<a class="pf-a" href="#artist-${s.k}">${capaFoto((S.artists[s.k]||{}).foto||"",s.n,64,true)}<span>${esc(s.n)}</span></a>`).join("")}</div>`:""}`;
};

perfilView=function(){
  const p=P(),fav=p.fav||[];
  const [c1,c2]=fav[0]?cores(fav[0]):cores(p.handle||"trackly");
  const banner=p.banner?`<div class="pban"><div class="art img" style="background-image:url(${p.banner})"></div></div>`:`<div class="pban"><div class="art" style="background:linear-gradient(135deg,${c1},${c2})"></div></div>`;
  const avatar=p.avatar?`<img src="${p.avatar}" alt="">`:`<div style="width:100%;height:100%;background:linear-gradient(145deg,${c1},${c2});display:grid;place-items:center">${esc(ini(p.nome))}</div>`;
  const tabs=[["perfil","Overview"],["avaliacoes","Ratings"],["diario","Diary"],["fila","Queue"],["stats","Stats"],["listas","Lists"],["pessoas","People"]];
  let corpo="";
  if(aba==="perfil")corpo=pfOverview();
  else if(aba==="avaliacoes")corpo=pfRatings();
  else if(aba==="diario")corpo=`<div style="margin-top:24px">${diaryList()}</div>`;
  else if(aba==="fila")corpo=filaView();
  else if(aba==="stats")corpo=statsView();
  else if(aba==="pessoas")corpo=pfPessoas();
  else corpo=pfListas();
  const ouv=Object.values(S.u).filter(v=>v.d).length,av=Object.values(S.u).filter(v=>v.r);
  const media=av.length?av.reduce((s,v)=>s+v.r,0)/av.length:0;
  const cell=(n,l,t,pp)=>`<button class="pw-c" data-aba="${t}"${pp?` data-pp="${pp}"`:""}><strong>${n}</strong><span>${l}</span></button>`;
  const stats=cell(ouv,"Listened","diario")+cell(av.length,"Ratings","avaliacoes")+cell(media?media.toFixed(1):"—","Avg","stats")+cell(SOC.following().length,"Following","pessoas","seguindo")+cell(SOC.followers().length,"Followers","pessoas","seguidores");
  const sub=["@"+esc(p.handle),p.local?esc(p.local):"",p.pron?esc(p.pron):""].filter(Boolean).join(" · ");
  const lk=linksOf(p),webs=lk.filter(x=>x.web).map(x=>`<a href="${esc(x.u)}" target="_blank" rel="noopener noreferrer me" title="${esc(x.u)}">${ico("ptr",14)}<span>${esc(x.t)}</span></a>`).join(""),lks=lk.filter(x=>!x.web).map(x=>`<a class="pw-lk" href="${esc(x.u)}" target="_blank" rel="noopener noreferrer me" aria-label="${esc(x.t)}" title="${esc(x.t)}">${ico(x.ic,19)}</a>`).join("");
  return `<div class="pf">${banner}<div class="pw">
    <div class="pw-av">${avatar}</div>
    <div class="pw-id"><div class="pw-ns"><div class="pw-nm"><h1>${esc(p.nome)}</h1>${isCreator(p.handle)?cbadge(1):""}</div><div class="pw-sub">${sub}</div></div>
      ${p.bio?`<p class="pw-bio">${esc(p.bio)}</p>`:""}
      ${webs?`<div class="pw-web">${webs}</div>`:""}
      <div class="pw-row"><button class="btn p" data-pact="editar">Edit profile</button><button class="pf-ib" data-pact="compartilhar" aria-label="Share profile" title="Share profile">${ico("share",17)}</button><button class="pf-ib" data-pact="cartao" aria-label="Share to Story" title="Share to Story">${ico("story",17)}</button>${lks?`<span class="pw-sep"></span>${lks}`:""}</div></div>
    <div class="pw-st">${stats}</div></div>
  <nav class="ptabs">${tabs.map(([k,l])=>`<button class="${aba===k?"on":""}" data-aba="${k}">${l}</button>`).join("")}</nav>
  <div class="pf-body">${corpo}</div></div>`;
};

;/* ---------- bloco 21 ---------- */
const faList=()=>(S.seguindo||[]).map(s=>({k:s.k,n:s.n,foto:(S.artists[s.k]||{}).foto||""})).sort((a,b)=>String(a.n).localeCompare(String(b.n)));
function faGrid(q){
  const nq=norm(q||""),l=faList().filter(a=>!nq||norm(a.n).includes(nq));
  if(!l.length)return `<div class="empty" style="margin-top:22px">${(S.seguindo||[]).length?`No artists match “${esc(q)}”.`:"You aren't following any artists yet. Open an artist page and tap Follow."}</div>`;
  return `<div class="fa-grid">${l.map(a=>`<a class="fa-i" href="#artist-${a.k}">${capaFoto(a.foto,a.n,104,true)}<b>${hl(a.n,q)}</b></a>`).join("")}</div>`;
}
function faView(){
  const n=(S.seguindo||[]).length;
  return `<a class="fa-back" href="#profile">${ico("left",15)} ${esc(P().nome)}</a>
  <div class="fa-top"><h1>Artists you follow</h1><span>${n}</span></div>
  <div class="sp-bar sm">${SQ_ICON}<input class="sp-in" id="faq" type="text" placeholder="Search your artists" autocomplete="off" autocapitalize="none" spellcheck="false"></div>
  <div id="falist">${faGrid("")}</div>`;
}
(function(){
  const prev=rota;
  rota=function(){
    const h=decodeURIComponent(NAV.hash.slice(1));
    if(h!=="following-artists")return prev();
    rotaTok++;resetAmb();
    document.documentElement.style.removeProperty("--bg");
    document.body.classList.remove("perfil","settings");
    document.querySelectorAll(".nav a").forEach(a=>a.classList.toggle("on",a.dataset.tab==="profile"));
    $("#app").innerHTML=faView();window.scrollTo(0,0);
  };
})();
document.addEventListener("input",e=>{if(e.target.id==="faq"){const l=document.getElementById("falist");if(l)l.innerHTML=faGrid(e.target.value)}});
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&e.target.id==="faq"){e.target.value="";document.getElementById("falist").innerHTML=faGrid("")}});

/* Overview: prateleira curta + "See all" */
(function(){
  const po=pfOverview;
  pfOverview=function(){
    let h=po();const segA=faList();
    h=h.replace(/<h2>Artists you follow<\/h2><div class="pf-arl">[\s\S]*<\/div>\s*$/,"");
    if(!segA.length)return h;
    const rec=[...(S.seguindo||[])].reverse().slice(0,12).map(s=>({k:s.k,n:s.n,foto:(S.artists[s.k]||{}).foto||""}));
    return h+`<div class="pf-sh"><h2>Artists you follow</h2><em>${segA.length}</em><a class="lnk" href="#following-artists">See all</a></div><div class="pf-arl">${rec.map(a=>`<a class="pf-a" href="#artist-${a.k}">${capaFoto(a.foto,a.n,64,true)}<span>${esc(a.n)}</span></a>`).join("")}</div>`;
  };
})();

;/* ---------- bloco 22 ---------- */
Object.assign(ICP,{ptr:'<path d="M5 3l14 7-6 2-2 6z"/>'});

;/* ---------- bloco 23 ---------- */
Object.assign(ICP,{palette:'<path d="M12 3a9 9 0 1 0 0 18c1.2 0 1.8-.8 1.8-1.7 0-1.3-1.2-1.6-1.2-2.8 0-.9.7-1.5 1.6-1.5H17a4 4 0 0 0 4-4c0-4.4-4-8-9-8z"/><path d="M7.5 11h.01M10 7.5h.01M14.5 7.5h.01"/>'});
const THEMES=[
  ["graphite","Graphite","#1c1c1e","#2c2c2e","#1c1c1e",""],
  ["charcoal","Charcoal","#2c2c2e","#3a3a3c","#2c2c2e",""],
  ["black","Black","#000","#111","#000000",""]
];
function applyTheme(id){
  const t=THEMES.find(x=>x[0]===id)||THEMES[0]; /* padrão: Graphite */
  document.documentElement.setAttribute("data-theme",t[0]);
  const m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute("content",t[4]);
}
function themeGrid(){
  const cur=THEMES.some(t=>t[0]===S.theme)?S.theme:"graphite";
  return `<div class="stg-th">${THEMES.map(([id,n,bg,sf,,glow])=>`<button class="th ${cur===id?"on":""}" data-th="${id}"><div class="th-pv" style="background:${bg};--s:${sf};${glow?`--glow:${glow}`:""}"><i></i><i></i></div><div class="th-n">${n}${cur===id?ico("check",16):""}</div></button>`).join("")}</div>`;
}
function stAppearance(){
  return `<section><h2>Appearance</h2><p class="stg-sub">Choose the background color of Trackly. It is saved on this device and applies instantly.</p>${themeGrid()}</section>`;
}
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-th]");if(!b)return;
  S.theme=b.dataset.th;salvar();applyTheme(S.theme);
  const g=document.querySelector(".stg-th");if(g)g.outerHTML=themeGrid();
  flash("Theme: "+THEMES.find(t=>t[0]===S.theme)[1]);
});
applyTheme(S.theme);

;/* ---------- bloco 24 ---------- */
function hfCard(rv){
  const [c1,c2]=cores(rv.u),m=S.meta[rv.k]||{t:"Album",a:""};
  const eu=rv.u===SOC.me().h,av=eu?SOC.me().av:rv.av;
  return `<a class="hf-c" href="#album-${rv.k}"><div class="hf-h"><div class="pf-av" style="background:linear-gradient(145deg,${c1},${c2})">${av?`<img src="${esc(av)}" alt="">`:esc(ini(rv.n))}</div><b>${esc(rv.n)}</b>${rv.r?estrelas(rv.r):""}</div>
    <div class="hf-b">${capaAlbum(rv.k,m.t,56)}<div class="grow"><div class="hf-t">${esc(m.t)}</div><div class="hf-s">${esc(m.a)}${m.y?" · "+m.y:""}</div></div></div>
    ${rv.txt?`<div class="hf-x">${esc(rv.txt)}</div>`:""}
    <div class="hf-f">${ico("heart",13,SOC.liked(rv))} ${SOC.likes(rv)} <span style="margin-left:auto;font-weight:500">${esc(fmtData(rv.p||rv.d))}</span></div></a>`;
}
function hfSection(){
  const fo=SOC.following().length,items=feedItens2("following").slice(0,10);
  const head=`<div class="sec-h"><h2>Reviews from friends</h2>${items.length?`<button class="lnk" data-hfall>See all</button>`:""}</div>`;
  if(items.length)return head+`<div class="hf-row">${items.map(hfCard).join("")}</div>`;
  const me=SOC.me().h;
  return head+(fo?`<div class="hf-empty"><div><b>No reviews yet</b><span>The people you follow haven't published a review. New ones will show up here.</span></div></div>`
    :`<div class="hf-empty"><div><b>Follow people to see their reviews</b><span>Like Letterboxd: follow friends and their latest reviews appear here.</span></div><a class="btn p" href="#@${encodeURIComponent(me)}" data-gofriends>Find people</a></div>`);
}
(function(){
  const hv=homeView;
  homeView=async function(){
    let h=await hv();
    const mark='<div class="sec-h"><h2>Trending</h2>';
    return h.includes(mark)?h.replace(mark,hfSection()+mark):h+hfSection();
  };
})();
document.addEventListener("click",e=>{
  if(!e.target.closest("[data-hfall]"))return;
  window.__ft="following";NAV.go("feed");
});

;/* ---------- bloco 25 ---------- */
/* a cor do fundo das páginas de álbum passa a depender do tema (--tint) */
apBg=function(c){document.documentElement.style.setProperty("--bg",`color-mix(in srgb,${c} var(--tint,14%),var(--base))`)};
THEMES.push(["music","Apple Music","linear-gradient(180deg,#5a4650,#1c1c1e)","rgba(255,255,255,.12)","#1c1c1e",""]);

;/* ---------- bloco 26 ---------- */
applyTheme(S.theme);

;/* ---------- bloco 27 ---------- */
const splitSong=l=>{const i=String(l).lastIndexOf(" — ");return i<0?{t:String(l),a:""}:{t:l.slice(0,i),a:l.slice(i+3)}};
function songCover(l,mc,size){
  const x=(mc||{})[l]||{},sp=splitSong(l),[c1,c2]=cores(l);
  return `<div class="fs-cv" style="${size?`width:${size}px;height:${size}px;`:""}background:linear-gradient(145deg,${c1},${c2})"><span>${esc(ini(sp.t))}</span>${x.c?`<img src="${esc(x.c)}" alt="" loading="lazy" onerror="this.remove()">`:""}</div>`;
}
function favSongsHTML(p){
  const m=p.musicas||[];
  if(!m.length)return `<div class="empty">Add favorite songs in Settings.</div>`;
  return `<div class="fs-grid">${m.map((l,i)=>{const sp=splitSong(l);
    return `<button class="fs-c" data-fs="${i}" aria-label="Play preview: ${esc(sp.t)}">${(()=>{const c=songCover(l,p.mcov);return c.replace("</div>",`<span class="fs-pl">${ico("play",16)}</span></div>`)})()}<div class="fs-t"><b>${esc(sp.t)}</b><small>${esc(sp.a)}</small></div></button>`}).join("")}</div>`;
}
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-fs]");if(!b)return;
  const p=P(),l=(p.musicas||[])[+b.dataset.fs];if(!l)return;
  const sp=splitSong(l),x=(p.mcov||{})[l]||{};
  abrirFaixa(sp.t,sp.a,x.al||"",x.c||"");
});
/* músicas antigas (sem capa): busca a capa em segundo plano e guarda */
let fsBusy=false;
async function fsBackfill(){
  if(fsBusy)return;const p=P();p.mcov=p.mcov||{};
  const falta=(p.musicas||[]).filter(l=>!(p.mcov[l]&&p.mcov[l].c)&&!(p.mcov[l]&&p.mcov[l].tried));
  if(!falta.length)return;fsBusy=true;
  for(const l of falta){
    const sp=splitSong(l);let ok=null;
    try{
      const r=await fontes.musicasDZ(encodeURIComponent(sp.t+" "+sp.a));
      const hit=(r||[]).find(m=>norm(m.titulo)===norm(sp.t)&&norm(m.artista)===norm(sp.a))||(r||[]).find(m=>norm(m.artista)===norm(sp.a));
      if(hit){const c=coverDe(albumKey(hit.album.t,hit.album.a))||hit.album.cover||"";if(c)ok={c,al:hit.album.t}}
    }catch(e){}
    p.mcov[l]=ok||{tried:1};
  }
  fsBusy=false;salvar();
  const g=document.querySelector(".fs-grid");if(g&&document.querySelector(".pf"))g.outerHTML=favSongsHTML(P());
}
(function(){
  const po=pfOverview;
  pfOverview=function(){const h=po();setTimeout(fsBackfill,50);return h};
})();
/* tela de edição: lista com capas e guarda a capa ao adicionar */
favMusHTML=function(){
  const m=SETD.musicas;
  if(!m.length)return `<div class="sx-empty">No favorite songs yet.</div>`;
  return `<div class="mlist">${m.map((l,i)=>{const sp=splitSong(l);return `<div class="fs-ed">${songCover(l,SETD.mcov)}<div class="fs-t"><b>${esc(sp.t)}</b><small>${esc(sp.a)}</small></div><button class="ib" data-s="mus-u" data-i="${i}" aria-label="Move up" ${i?"":"disabled style='opacity:.3'"}>${ico("up",13)}</button><button class="ib" data-s="mus-d" data-i="${i}" aria-label="Move down" ${i<m.length-1?"":"disabled style='opacity:.3'"}>${ico("down",13)}</button><button class="ib" data-s="mus-x" data-i="${i}" aria-label="Remove">${ico("x",12)}</button></div>`}).join("")}</div>`;
};
document.addEventListener("click",e=>{
  const b=e.target.closest('[data-s="pick-mus"]');if(!b||typeof SETD==="undefined"||!SETD)return;
  const m=SFRES[+b.dataset.i];if(!m)return;
  const l=`${m.titulo} — ${m.artista}`;
  SETD.mcov=SETD.mcov||{};
  SETD.mcov[l]={c:coverDe(albumKey(m.album.t,m.album.a))||m.album.cover||"",al:m.album.t};
},true);

;/* ---------- bloco 28 ---------- */
Object.assign(ICP,{camera:'<path d="M4 8.5A2.5 2.5 0 0 1 6.5 6H8l1.2-1.8h5.6L16 6h1.5A2.5 2.5 0 0 1 20 8.5v8A2.5 2.5 0 0 1 17.5 19h-11A2.5 2.5 0 0 1 4 16.5z"/><circle cx="12" cy="12.5" r="3.4"/>'});
let LKO=null,LKM=false;
const lkInit=()=>{if(!LKO)LKO=LKS.map(x=>x[0]).filter(k=>(SETD.links[k]||"").trim())};
(function(){const si=stInit;stInit=function(){const fresh=!SETD;si();if(fresh){LKO=null;LKM=false}}})();
(function(){const ss=stSync;stSync=function(){ss();const h=document.getElementById("shandle");if(h&&h.classList.contains("ok"))h.textContent=""}})();

stProfile=function(){
  const e=SETD,[c1,c2]=cores(e.handle||"trackly");
  const avBg=e.avatar?"#222":`linear-gradient(145deg,${c1},${c2})`;
  return `<section><div class="sx-cov"><div class="sx-ban" style="${e.banner?`background-image:url('${esc(e.banner)}')`:`background:linear-gradient(135deg,${c1},${c2})`}"></div>
    <div class="sx-bacts"><label class="sx-ic" title="Change banner" aria-label="Change banner">${ico("camera",16)}<input id="sbanner" type="file" accept="image/*" hidden></label>${e.banner?`<button class="sx-ic" data-s="banner-rm" title="Remove banner" aria-label="Remove banner">${ico("x",14)}</button>`:""}</div>
    <div class="sx-avrow"><div class="sx-avw"><label class="sx-av sx-avl" style="background:${avBg}" title="Change photo" aria-label="Change photo">${e.avatar?`<img src="${esc(e.avatar)}" alt="">`:esc(ini(e.nome))}<span class="sx-avo">${ico("camera",22)}</span><input id="sfoto" type="file" accept="image/*" hidden></label>${e.avatar?`<button class="sx-avx" data-s="foto-rm" title="Remove photo" aria-label="Remove photo">${ico("x",12)}</button>`:""}</div></div></div></section>
  <section><div class="gr">
    <div class="gr-row"><span class="gr-lbl">Name</span><input class="gr-in" data-sf="nome" maxlength="40" value="${esc(e.nome)}" placeholder="Your name"></div>
    <div class="gr-row"><span class="gr-lbl">Username</span><span class="sx-at">@</span><input class="gr-in" data-sf="handle" maxlength="30" value="${esc(e.handle)}" placeholder="username" autocapitalize="none" autocorrect="off" spellcheck="false"></div>
    <div class="gr-row"><span class="gr-lbl">Pronouns</span><input class="gr-in" data-sf="pron" maxlength="24" value="${esc(e.pron)}" placeholder="Optional"></div>
    <div class="gr-row"><span class="gr-lbl">Location</span><input class="gr-in" data-sf="local" maxlength="40" value="${esc(e.local)}" placeholder="City, country"></div>
    <div class="gr-row gr-alto"><span class="gr-lbl">Bio</span><div class="gr-bio"><textarea class="gr-in" data-sf="bio" maxlength="240" rows="3" placeholder="Tell people what you listen to">${esc(e.bio)}</textarea><span class="bio-c" id="sbioc">${(e.bio||"").length}/240</span></div></div>
  </div><p class="sx-hint" id="shandle"></p></section>${stLinks()}`;
};
stLinks=function(){
  lkInit();const L=SETD.links;
  const rows=LKO.map(k=>{const d=LKS.find(x=>x[0]===k),[,n,ic,ph]=d,u=linkURL(k,L[k]),bad=!!(L[k]||"").trim()&&!u;
    return `<div class="gr-row${bad?" bad":""}"><span class="gr-lbl lk">${ico(ic,17)}${n}</span><input class="gr-in" data-sl="${k}" value="${esc(L[k]||"")}" placeholder="${ph}" autocapitalize="none" autocorrect="off" spellcheck="false" inputmode="${k==="site"?"url":"text"}"><span class="sx-lp" data-lp="${k}">${u?esc(hostOf(u)+new URL(u).pathname.replace(/\/$/,"")):""}</span><button class="ib" data-lk="rm" data-k="${k}" aria-label="Remove">${ico("x",12)}</button></div>`}).join("");
  const cus=SETD.custom.map((c,i)=>{const bad=!!(c.u||"").trim()&&!linkURL("site",c.u);
    return `<div class="gr-row${bad?" bad":""}"><span class="gr-lbl lk">${ico("link",17)}</span><input class="gr-in" style="flex:.7" data-sc="l" data-i="${i}" value="${esc(c.l)}" placeholder="Label (optional)" maxlength="24"><input class="gr-in" data-sc="u" data-i="${i}" value="${esc(c.u)}" placeholder="https://" autocapitalize="none" spellcheck="false" inputmode="url"><button class="ib" data-lk="crm" data-i="${i}" aria-label="Remove">${ico("x",12)}</button></div>`}).join("");
  const rest=LKS.filter(x=>!LKO.includes(x[0])),canCus=SETD.custom.length<4;
  const menu=LKM?`<div class="lk-menu">${rest.map(([k,n,ic])=>`<button data-lk="pick" data-k="${k}">${ico(ic,15)}${n}</button>`).join("")}${canCus?`<button data-lk="other">${ico("link",15)}Other link</button>`:""}</div>`:"";
  const any=!!(rows||cus);
  return `<section><h2>Links</h2>${any?`<div class="gr">${rows}${cus}</div>`:""}${(rest.length||canCus)?`<button class="btn lk-add" data-lk="menu">${ico("plus",14)} Add link</button>`:""}${menu}</section>`;
};
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-lk]");if(!b||!SETD)return;
  const a=b.dataset.lk,k=b.dataset.k,i=+b.dataset.i;
  if(a==="menu")LKM=!LKM;
  else if(a==="pick"){LKO.push(k);LKM=false}
  else if(a==="other"){SETD.custom.push({l:"",u:""});LKM=false}
  else if(a==="rm"){LKO=LKO.filter(x=>x!==k);SETD.links[k]=""}
  else if(a==="crm")SETD.custom.splice(i,1);
  renderSettings();
  if(a==="pick"){const inp=document.querySelector(`[data-sl="${k}"]`);if(inp)inp.focus()}
  if(a==="other"){const l=document.querySelectorAll('[data-sc="l"]');if(l.length)l[l.length-1].focus()}
});

;/* ---------- bloco 29 ---------- */
let RT_F="all";
function ratingsItems(){
  const out=[];let n=0;
  Object.entries(S.u).forEach(([k,v])=>{n++;if(v.r&&S.meta[k])out.push({t:"album",k,v,d:postedOn(k)||"",n})});
  Object.entries(S.tracks||{}).forEach(([k,tr])=>{n++;const v=S.u[k];if(v&&v.r)out.push({t:"song",k,v,tr,d:tr.p||"",n})});
  return out.sort((a,b)=>String(b.d).localeCompare(String(a.d))||(b.n-a.n));
}
const monthLbl=d=>{if(!d)return"Earlier";const [y,m]=d.split("-").map(Number);return new Date(y,m-1,1).toLocaleDateString("en-US",{month:"long",year:"numeric"})};
function ratingRow(it){
  if(it.t==="album"){
    const m=S.meta[it.k],last=SOC.mineAll(it.k).sort((a,b)=>String(b.p||b.d).localeCompare(String(a.p||a.d)))[0],txt=(last&&last.txt)||it.v.rev||"";
    return `<a class="row" href="#album-${it.k}" style="display:block"><div style="display:flex;align-items:center;gap:14px">${capaAlbum(it.k,m.t,46)}<div class="grow"><div class="ttl">${esc(m.t)}</div><div class="sm mut">${esc(m.a)}${it.d?` · ${esc(fmtData(it.d))}`:""}</div></div>${estrelas(it.v.r)}</div>${txt?`<div style="font-weight:500;padding:10px 0 0 60px;line-height:1.45">${esc(txt)}</div>`:""}</a>`;
  }
  const t=it.tr,l=`${t.t} — ${t.a}`;
  return `<button class="row rs-song" data-rs="${it.k}"><div style="display:flex;align-items:center;gap:14px">${songCover(l,{[l]:{c:t.c}})}<div class="grow"><div class="ttl">${esc(t.t)}<i class="rt-tag">Song</i></div><div class="sm mut">${esc(t.a)}${it.d?` · ${esc(fmtData(it.d))}`:""}</div></div>${estrelas(it.v.r)}</div></button>`;
}
function ratingsListHTML(){
  const all=ratingsItems(),l=all.filter(x=>RT_F==="all"||(RT_F==="albums"?x.t==="album":x.t==="song"));
  if(!l.length)return `<div class="empty" style="margin-top:20px">${all.length?"Nothing here yet.":"You haven't rated anything yet."}</div>`;
  const groups=[];l.forEach(it=>{const g=monthLbl(it.d),last=groups[groups.length-1];if(last&&last.g===g)last.items.push(it);else groups.push({g,items:[it]})});
  return groups.map(g=>`<h3 class="sec rt-m">${esc(g.g)}</h3><div class="mlist">${g.items.map(ratingRow).join("")}</div>`).join("");
}
pfRatings=function(){
  const all=ratingsItems(),na=all.filter(x=>x.t==="album").length,ns=all.length-na;
  setTimeout(rtBackfill,60);
  return `<div class="rt-top"><div class="chips">${[["all","All",all.length],["albums","Albums",na],["songs","Songs",ns]].map(([k,lb,n])=>`<button class="chip ${RT_F===k?"on":""}" data-rtf="${k}">${lb} <span class="cn" style="opacity:.55;font-weight:700;font-size:11.5px">${n}</span></button>`).join("")}</div></div><div id="rtlist">${ratingsListHTML()}</div>`;
};
document.addEventListener("click",e=>{
  const f=e.target.closest("[data-rtf]");
  if(f){RT_F=f.dataset.rtf;document.querySelectorAll("[data-rtf]").forEach(c=>c.classList.toggle("on",c===f));const el=document.getElementById("rtlist");if(el)el.innerHTML=ratingsListHTML();return}
  const s=e.target.closest("[data-rs]");
  if(s){const t=(S.tracks||{})[s.dataset.rs];if(t)abrirFaixa(t.t,t.a,"",t.c||"")}
});
/* capa das músicas avaliadas (busca em segundo plano, uma vez) */
let rtBusy=false;
async function rtBackfill(){
  if(rtBusy)return;
  const falta=Object.entries(S.tracks||{}).filter(([k,t])=>S.u[k]&&S.u[k].r&&!t.c&&!t.tried);
  if(!falta.length)return;rtBusy=true;
  for(const [k,t] of falta){
    try{
      const r=await fontes.musicasDZ(encodeURIComponent(t.t+" "+t.a));
      const hit=(r||[]).find(m=>norm(m.titulo)===norm(t.t)&&norm(m.artista)===norm(t.a))||(r||[]).find(m=>norm(m.artista)===norm(t.a));
      const c=hit?(coverDe(albumKey(hit.album.t,hit.album.a))||hit.album.cover||""):"";
      if(c)t.c=c;else t.tried=1;
    }catch(e){t.tried=1}
  }
  rtBusy=false;salvar();
  const el=document.getElementById("rtlist");if(el&&document.querySelector("[data-rtf]"))el.innerHTML=ratingsListHTML();
}

;/* ---------- bloco 30 ---------- */
const CHEV='<svg width="9" height="14" viewBox="0 0 9 14" fill="none" aria-hidden="true"><path d="M1.6 1.6L7 7l-5.4 5.4" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const secGo=(h,attrs,tag)=>`<${tag||"button"} class="sec-go" ${attrs}><h2>${h}</h2>${CHEV}</${tag||"button"}>`;
/* Home: "Reviews from friends" leva ao Feed (Following) */
hfSection=function(){
  const fo=SOC.following().length,items=feedItens2("following").slice(0,10);
  const head=items.length?`<div class="sec-h">${secGo("Reviews from friends","data-hfall")}</div>`:`<div class="sec-h"><h2>Reviews from friends</h2></div>`;
  if(items.length)return head+`<div class="hf-row">${items.map(hfCard).join("")}</div>`;
  const me=SOC.me().h;
  return head+(fo?`<div class="hf-empty"><div><b>No reviews yet</b><span>The people you follow haven't published a review. New ones will show up here.</span></div></div>`
    :`<div class="hf-empty"><div><b>Follow people to see their reviews</b><span>Like Letterboxd: follow friends and their latest reviews appear here.</span></div><a class="btn p" href="#@${encodeURIComponent(me)}" data-gofriends>Find people</a></div>`);
};
/* Perfil: "Artists you follow" leva à página de artistas */
(function(){
  const po=pfOverview;
  pfOverview=function(){
    return po().replace(/<div class="pf-sh"><h2>Artists you follow<\/h2>(<em>\d+<\/em>)<a class="lnk" href="#following-artists">See all<\/a><\/div>/,
      (m,em)=>`<div class="pf-sh">${secGo("Artists you follow",'href="#following-artists"',"a")}${em}</div>`);
  };
})();
/* Busca: os títulos Artists / Albums & EPs / People trocam o "See all" pelo chevron */
(function(){
  const mb=montarBusca;
  montarBusca=function(q,coleta,f){
    return mb(q,coleta,f).replace(/<div class="sec-h"><h2>([^<]+)<\/h2><button class="lnk" data-sqgo="(\w+)">See all<\/button><\/div>/g,
      (m,t,g)=>`<div class="sec-h">${secGo(t,`data-sqgo="${g}"`)}</div>`);
  };
})();

;/* ---------- bloco 31 ---------- */
let DY_Q="",RT_Q="";
const ltBar=(id,ph,val)=>`<div class="sp-bar sm lt-bar${val?" has":""}" id="${id}bar">${SQ_ICON}<input class="sp-in" id="${id}q" type="text" enterkeyhint="search" placeholder="${ph}" autocomplete="off" autocapitalize="none" spellcheck="false" value="${esc(val)}"><button class="sp-x" data-ltx="${id}" aria-label="Clear">${ico("x",15)}</button></div>`;
const noRes=q=>`<div class="empty" style="margin-top:20px">No results for “${esc(q)}”.</div>`;

/* ---- Diary ---- */
function diaryBody(){
  const q=norm(DY_Q);
  const e=Object.entries(S.u).filter(([k,v])=>v.d&&(!q||(S.meta[k]&&(norm(S.meta[k].t).includes(q)||norm(S.meta[k].a).includes(q))))).sort((a,b)=>b[1].d.localeCompare(a[1].d));
  if(!e.length)return DY_Q?noRes(DY_Q):`<div class="empty">You haven't marked any album as listened yet.</div>`;
  const MESES=["January","February","March","April","May","June","July","August","September","October","November","December"];
  let atual="",html="";
  e.forEach(([k,v])=>{
    const mk=v.d.slice(0,7);
    if(mk!==atual){
      if(atual)html+=`</div>`;
      atual=mk;const [y,mm]=mk.split("-"),n=e.filter(x=>x[1].d.slice(0,7)===mk).length;
      html+=`<h3 class="sec" style="margin:22px 4px 10px">${MESES[+mm-1]} ${y} · ${n}</h3><div class="mlist">`;
    }
    const m=S.meta[k]||{t:"Album",a:""};
    html+=`<a class="row" href="#album-${k}">${capaAlbum(k,m.t,50)}<div class="grow"><div class="ttl">${hl(m.t,DY_Q)}</div><div class="sm mut" style="font-weight:700">${hl(m.a,DY_Q)} · ${v.d.slice(8,10)}/${v.d.slice(5,7)}</div></div>${v.r?estrelas(v.r):""}</a>`;
  });
  return html+(atual?`</div>`:"");
}
diaryList=function(){
  DY_Q="";
  const has=Object.values(S.u).some(v=>v.d);
  return (has?ltBar("dy","Search your diary",""):"")+`<div id="dylist">${diaryBody()}</div>`;
};

/* ---- Ratings ---- */
ratingsListHTML=function(){
  const q=norm(RT_Q),all=ratingsItems();
  const l=all.filter(x=>RT_F==="all"||(RT_F==="albums"?x.t==="album":x.t==="song")).filter(it=>{
    if(!q)return true;
    if(it.t==="album"){const m=S.meta[it.k],last=SOC.mineAll(it.k).map(r=>r.txt).join(" ")+" "+(it.v.rev||"");return norm(m.t).includes(q)||norm(m.a).includes(q)||norm(last).includes(q)}
    return norm(it.tr.t).includes(q)||norm(it.tr.a).includes(q);
  });
  if(!l.length)return RT_Q?noRes(RT_Q):`<div class="empty" style="margin-top:20px">${all.length?"Nothing here yet.":"You haven't rated anything yet."}</div>`;
  const groups=[];l.forEach(it=>{const g=monthLbl(it.d),last=groups[groups.length-1];if(last&&last.g===g)last.items.push(it);else groups.push({g,items:[it]})});
  return groups.map(g=>`<h3 class="sec rt-m">${esc(g.g)}</h3><div class="mlist">${g.items.map(ratingRow).join("")}</div>`).join("");
};
(function(){
  const pr=pfRatings;
  pfRatings=function(){
    RT_Q="";
    const h=pr();
    const has=Object.values(S.u).some(v=>v.r);
    return (has?ltBar("rt","Search your ratings",""):"")+h;
  };
})();

/* ---- eventos ---- */
function ltRender(id){
  const el=document.getElementById(id==="dy"?"dylist":"rtlist");
  if(el)el.innerHTML=id==="dy"?diaryBody():ratingsListHTML();
  const bar=document.getElementById(id+"bar");if(bar)bar.classList.toggle("has",!!(id==="dy"?DY_Q:RT_Q));
}
document.addEventListener("input",e=>{
  const id=e.target.id;
  if(id==="dyq"){DY_Q=e.target.value.trim();ltRender("dy")}
  else if(id==="rtq"){RT_Q=e.target.value.trim();ltRender("rt")}
});
document.addEventListener("click",e=>{
  const x=e.target.closest("[data-ltx]");if(!x)return;
  const id=x.dataset.ltx,inp=document.getElementById(id+"q");
  if(inp){inp.value="";inp.focus()}
  if(id==="dy")DY_Q="";else RT_Q="";
  ltRender(id);
});
document.addEventListener("keydown",e=>{
  if(e.key==="Escape"&&(e.target.id==="dyq"||e.target.id==="rtq")){e.target.value="";const id=e.target.id.slice(0,2);if(id==="dy")DY_Q="";else RT_Q="";ltRender(id)}
});
